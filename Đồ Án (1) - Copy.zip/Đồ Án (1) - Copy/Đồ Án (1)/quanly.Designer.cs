﻿namespace Đồ_Án__1_
{
    partial class quanly
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.tpQuanLyHoatDong = new System.Windows.Forms.TabPage();
            this.panel19 = new System.Windows.Forms.Panel();
            this.txbHoatDongHomNay = new System.Windows.Forms.TextBox();
            this.txbTongSoHoatDong = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.listViewHoatDong = new System.Windows.Forms.ListView();
            this.panel17 = new System.Windows.Forms.Panel();
            this.txbTimKiemHoatDong = new System.Windows.Forms.TextBox();
            this.cmbTimKiemHoatDong = new System.Windows.Forms.ComboBox();
            this.btnTimKiemHoatDong = new System.Windows.Forms.Button();
            this.btnlammoi = new System.Windows.Forms.Button();
            this.dtpkFromdayHoatDong = new System.Windows.Forms.DateTimePicker();
            this.dtpkTodayHoatDong = new System.Windows.Forms.DateTimePicker();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.tpquanlynhanvien = new System.Windows.Forms.TabPage();
            this.panel16 = new System.Windows.Forms.Panel();
            this.dtpkTodaynhanvien = new System.Windows.Forms.DateTimePicker();
            this.dtpkFromdaynhanvien = new System.Windows.Forms.DateTimePicker();
            this.panel13 = new System.Windows.Forms.Panel();
            this.gbThongKeNhanVien = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.drgvnhanvien = new System.Windows.Forms.DataGridView();
            this.panel27 = new System.Windows.Forms.Panel();
            this.bntThoat = new System.Windows.Forms.Button();
            this.btnxemTk = new System.Windows.Forms.Button();
            this.btnSuaTK = new System.Windows.Forms.Button();
            this.btnXoaTk = new System.Windows.Forms.Button();
            this.btnThemTK = new System.Windows.Forms.Button();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.txbtrangthainhanvien = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnlammoitk = new System.Windows.Forms.Button();
            this.panel29 = new System.Windows.Forms.Panel();
            this.txbmktk = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.txbtenhienthitk = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.txbtentk = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tpQuanLyThucDon = new System.Windows.Forms.TabPage();
            this.btnQuanLyFile = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txbtimFoodName = new System.Windows.Forms.TextBox();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnShowFood = new System.Windows.Forms.Button();
            this.btnsuafood = new System.Windows.Forms.Button();
            this.btnxoafood = new System.Windows.Forms.Button();
            this.btnaddfood = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.txbSoLuong = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txbFoodPrice = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txbDanhMucFood = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txbfoodname = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txbFoodID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dgvQuanLyThucdon = new System.Windows.Forms.DataGridView();
            this.tpDoanhThu = new System.Windows.Forms.TabPage();
            this.panel12 = new System.Windows.Forms.Panel();
            this.chartDoanhThu = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel11 = new System.Windows.Forms.Panel();
            this.ListViewTopSanPhamBanChay = new System.Windows.Forms.ListView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnxuatexecl = new System.Windows.Forms.Button();
            this.btnxemdoanhthu = new System.Windows.Forms.Button();
            this.dtpkFromday = new System.Windows.Forms.DateTimePicker();
            this.dtpkToday = new System.Windows.Forms.DateTimePicker();
            this.panel1 = new System.Windows.Forms.Panel();
            this.listViewDoanhThu = new System.Windows.Forms.ListView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpQuanLyHoatDong.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel15.SuspendLayout();
            this.tpquanlynhanvien.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel28.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.drgvnhanvien)).BeginInit();
            this.panel27.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel26.SuspendLayout();
            this.tpQuanLyThucDon.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuanLyThucdon)).BeginInit();
            this.tpDoanhThu.SuspendLayout();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartDoanhThu)).BeginInit();
            this.panel11.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tpQuanLyHoatDong
            // 
            this.tpQuanLyHoatDong.Controls.Add(this.panel19);
            this.tpQuanLyHoatDong.Controls.Add(this.panel18);
            this.tpQuanLyHoatDong.Controls.Add(this.panel17);
            this.tpQuanLyHoatDong.Controls.Add(this.panel15);
            this.tpQuanLyHoatDong.Location = new System.Drawing.Point(4, 25);
            this.tpQuanLyHoatDong.Name = "tpQuanLyHoatDong";
            this.tpQuanLyHoatDong.Padding = new System.Windows.Forms.Padding(3);
            this.tpQuanLyHoatDong.Size = new System.Drawing.Size(1222, 430);
            this.tpQuanLyHoatDong.TabIndex = 5;
            this.tpQuanLyHoatDong.Text = "Quản Lý Hoạt Động";
            this.tpQuanLyHoatDong.UseVisualStyleBackColor = true;
            this.tpQuanLyHoatDong.Click += new System.EventHandler(this.tpQuanLyHoatDong_Click);
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.txbHoatDongHomNay);
            this.panel19.Controls.Add(this.txbTongSoHoatDong);
            this.panel19.Controls.Add(this.label9);
            this.panel19.Controls.Add(this.label8);
            this.panel19.Location = new System.Drawing.Point(3, 369);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(1213, 58);
            this.panel19.TabIndex = 4;
            this.panel19.Paint += new System.Windows.Forms.PaintEventHandler(this.panel19_Paint);
            // 
            // txbHoatDongHomNay
            // 
            this.txbHoatDongHomNay.Location = new System.Drawing.Point(991, 20);
            this.txbHoatDongHomNay.Name = "txbHoatDongHomNay";
            this.txbHoatDongHomNay.Size = new System.Drawing.Size(121, 22);
            this.txbHoatDongHomNay.TabIndex = 7;
            this.txbHoatDongHomNay.TextChanged += new System.EventHandler(this.txbHoatDongHomNay_TextChanged);
            // 
            // txbTongSoHoatDong
            // 
            this.txbTongSoHoatDong.Location = new System.Drawing.Point(76, 17);
            this.txbTongSoHoatDong.Name = "txbTongSoHoatDong";
            this.txbTongSoHoatDong.Size = new System.Drawing.Size(143, 22);
            this.txbTongSoHoatDong.TabIndex = 6;
            this.txbTongSoHoatDong.TextChanged += new System.EventHandler(this.txbTongSoHoatDong_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(907, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 16);
            this.label9.TabIndex = 1;
            this.label9.Text = "Hôm Nay:";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 16);
            this.label8.TabIndex = 0;
            this.label8.Text = "Tổng Số:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.listViewHoatDong);
            this.panel18.Location = new System.Drawing.Point(3, 96);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(1216, 234);
            this.panel18.TabIndex = 3;
            this.panel18.Paint += new System.Windows.Forms.PaintEventHandler(this.panel18_Paint);
            // 
            // listViewHoatDong
            // 
            this.listViewHoatDong.HideSelection = false;
            this.listViewHoatDong.Location = new System.Drawing.Point(3, 13);
            this.listViewHoatDong.Name = "listViewHoatDong";
            this.listViewHoatDong.Size = new System.Drawing.Size(1210, 218);
            this.listViewHoatDong.TabIndex = 0;
            this.listViewHoatDong.UseCompatibleStateImageBehavior = false;
            this.listViewHoatDong.SelectedIndexChanged += new System.EventHandler(this.listViewHoatDong_SelectedIndexChanged);
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.GreenYellow;
            this.panel17.Controls.Add(this.txbTimKiemHoatDong);
            this.panel17.Controls.Add(this.cmbTimKiemHoatDong);
            this.panel17.Controls.Add(this.btnTimKiemHoatDong);
            this.panel17.Controls.Add(this.btnlammoi);
            this.panel17.Controls.Add(this.dtpkFromdayHoatDong);
            this.panel17.Controls.Add(this.dtpkTodayHoatDong);
            this.panel17.Location = new System.Drawing.Point(6, 37);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(1213, 37);
            this.panel17.TabIndex = 2;
            this.panel17.Paint += new System.Windows.Forms.PaintEventHandler(this.panel17_Paint);
            // 
            // txbTimKiemHoatDong
            // 
            this.txbTimKiemHoatDong.Location = new System.Drawing.Point(771, 6);
            this.txbTimKiemHoatDong.Name = "txbTimKiemHoatDong";
            this.txbTimKiemHoatDong.Size = new System.Drawing.Size(338, 22);
            this.txbTimKiemHoatDong.TabIndex = 5;
            this.txbTimKiemHoatDong.TextChanged += new System.EventHandler(this.txbTimKiemHoatDong_TextChanged);
            // 
            // cmbTimKiemHoatDong
            // 
            this.cmbTimKiemHoatDong.FormattingEnabled = true;
            this.cmbTimKiemHoatDong.Location = new System.Drawing.Point(572, 4);
            this.cmbTimKiemHoatDong.Name = "cmbTimKiemHoatDong";
            this.cmbTimKiemHoatDong.Size = new System.Drawing.Size(181, 24);
            this.cmbTimKiemHoatDong.TabIndex = 4;
            this.cmbTimKiemHoatDong.SelectedIndexChanged += new System.EventHandler(this.cmbTimKiemHoatDong_SelectedIndexChanged);
            // 
            // btnTimKiemHoatDong
            // 
            this.btnTimKiemHoatDong.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnTimKiemHoatDong.Location = new System.Drawing.Point(1132, 3);
            this.btnTimKiemHoatDong.Name = "btnTimKiemHoatDong";
            this.btnTimKiemHoatDong.Size = new System.Drawing.Size(78, 31);
            this.btnTimKiemHoatDong.TabIndex = 3;
            this.btnTimKiemHoatDong.Text = "Tìm Kiếm";
            this.btnTimKiemHoatDong.UseVisualStyleBackColor = false;
            this.btnTimKiemHoatDong.Click += new System.EventHandler(this.btnTimKiemHoatDong_Click);
            // 
            // btnlammoi
            // 
            this.btnlammoi.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnlammoi.Location = new System.Drawing.Point(457, 2);
            this.btnlammoi.Name = "btnlammoi";
            this.btnlammoi.Size = new System.Drawing.Size(98, 30);
            this.btnlammoi.TabIndex = 2;
            this.btnlammoi.Text = "Làm Mới";
            this.btnlammoi.UseVisualStyleBackColor = false;
            this.btnlammoi.Click += new System.EventHandler(this.btnlammoi_Click);
            // 
            // dtpkFromdayHoatDong
            // 
            this.dtpkFromdayHoatDong.Location = new System.Drawing.Point(4, 7);
            this.dtpkFromdayHoatDong.Name = "dtpkFromdayHoatDong";
            this.dtpkFromdayHoatDong.Size = new System.Drawing.Size(200, 22);
            this.dtpkFromdayHoatDong.TabIndex = 1;
            this.dtpkFromdayHoatDong.ValueChanged += new System.EventHandler(this.dtpkFromdayHoatDong_ValueChanged);
            // 
            // dtpkTodayHoatDong
            // 
            this.dtpkTodayHoatDong.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.dtpkTodayHoatDong.CalendarTitleForeColor = System.Drawing.SystemColors.Info;
            this.dtpkTodayHoatDong.Location = new System.Drawing.Point(234, 7);
            this.dtpkTodayHoatDong.Name = "dtpkTodayHoatDong";
            this.dtpkTodayHoatDong.Size = new System.Drawing.Size(200, 22);
            this.dtpkTodayHoatDong.TabIndex = 0;
            this.dtpkTodayHoatDong.ValueChanged += new System.EventHandler(this.dtpkTodayHoatDong_ValueChanged);
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.label7);
            this.panel15.Location = new System.Drawing.Point(6, 3);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(1210, 28);
            this.panel15.TabIndex = 0;
            this.panel15.Paint += new System.Windows.Forms.PaintEventHandler(this.panel15_Paint);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(426, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(276, 23);
            this.label7.TabIndex = 0;
            this.label7.Text = "Nhật Ký Hoạt Động";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // tpquanlynhanvien
            // 
            this.tpquanlynhanvien.Controls.Add(this.panel16);
            this.tpquanlynhanvien.Controls.Add(this.panel13);
            this.tpquanlynhanvien.Controls.Add(this.label5);
            this.tpquanlynhanvien.Controls.Add(this.panel28);
            this.tpquanlynhanvien.Controls.Add(this.panel27);
            this.tpquanlynhanvien.Controls.Add(this.panel23);
            this.tpquanlynhanvien.Location = new System.Drawing.Point(4, 25);
            this.tpquanlynhanvien.Name = "tpquanlynhanvien";
            this.tpquanlynhanvien.Padding = new System.Windows.Forms.Padding(3);
            this.tpquanlynhanvien.Size = new System.Drawing.Size(1222, 430);
            this.tpquanlynhanvien.TabIndex = 4;
            this.tpquanlynhanvien.Text = "Quản Lý Nhân Viên";
            this.tpquanlynhanvien.UseVisualStyleBackColor = true;
            this.tpquanlynhanvien.Click += new System.EventHandler(this.tpquanlynhanvien_Click);
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.dtpkTodaynhanvien);
            this.panel16.Controls.Add(this.dtpkFromdaynhanvien);
            this.panel16.Location = new System.Drawing.Point(702, 6);
            this.panel16.Margin = new System.Windows.Forms.Padding(4);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(515, 47);
            this.panel16.TabIndex = 14;
            this.panel16.Paint += new System.Windows.Forms.PaintEventHandler(this.panel16_Paint);
            // 
            // dtpkTodaynhanvien
            // 
            this.dtpkTodaynhanvien.Location = new System.Drawing.Point(259, 12);
            this.dtpkTodaynhanvien.Margin = new System.Windows.Forms.Padding(4);
            this.dtpkTodaynhanvien.Name = "dtpkTodaynhanvien";
            this.dtpkTodaynhanvien.Size = new System.Drawing.Size(253, 22);
            this.dtpkTodaynhanvien.TabIndex = 1;
            this.dtpkTodaynhanvien.ValueChanged += new System.EventHandler(this.dtpkTodaynhanvien_ValueChanged);
            // 
            // dtpkFromdaynhanvien
            // 
            this.dtpkFromdaynhanvien.Location = new System.Drawing.Point(4, 12);
            this.dtpkFromdaynhanvien.Margin = new System.Windows.Forms.Padding(4);
            this.dtpkFromdaynhanvien.Name = "dtpkFromdaynhanvien";
            this.dtpkFromdaynhanvien.Size = new System.Drawing.Size(247, 22);
            this.dtpkFromdaynhanvien.TabIndex = 0;
            this.dtpkFromdaynhanvien.ValueChanged += new System.EventHandler(this.dtpkFromdaynhanvien_ValueChanged);
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.gbThongKeNhanVien);
            this.panel13.Location = new System.Drawing.Point(787, 62);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(427, 362);
            this.panel13.TabIndex = 12;
            this.panel13.Paint += new System.Windows.Forms.PaintEventHandler(this.panel13_Paint);
            // 
            // gbThongKeNhanVien
            // 
            this.gbThongKeNhanVien.Location = new System.Drawing.Point(4, 4);
            this.gbThongKeNhanVien.Margin = new System.Windows.Forms.Padding(4);
            this.gbThongKeNhanVien.Name = "gbThongKeNhanVien";
            this.gbThongKeNhanVien.Padding = new System.Windows.Forms.Padding(4);
            this.gbThongKeNhanVien.Size = new System.Drawing.Size(419, 354);
            this.gbThongKeNhanVien.TabIndex = 1;
            this.gbThongKeNhanVien.TabStop = false;
            this.gbThongKeNhanVien.Text = "Thống Kê";
            this.gbThongKeNhanVien.Enter += new System.EventHandler(this.gbThongKeNhanVien_Enter);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(6, 12);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(263, 32);
            this.label5.TabIndex = 11;
            this.label5.Text = "QUẢN LÝ NHÂN VIÊN:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.drgvnhanvien);
            this.panel28.Location = new System.Drawing.Point(6, 65);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(409, 355);
            this.panel28.TabIndex = 10;
            this.panel28.Paint += new System.Windows.Forms.PaintEventHandler(this.panel28_Paint);
            // 
            // drgvnhanvien
            // 
            this.drgvnhanvien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.drgvnhanvien.Location = new System.Drawing.Point(3, 9);
            this.drgvnhanvien.Name = "drgvnhanvien";
            this.drgvnhanvien.RowHeadersWidth = 51;
            this.drgvnhanvien.RowTemplate.Height = 24;
            this.drgvnhanvien.Size = new System.Drawing.Size(403, 343);
            this.drgvnhanvien.TabIndex = 0;
            this.drgvnhanvien.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.drgvnhanvien_CellContentClick);
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.bntThoat);
            this.panel27.Controls.Add(this.btnxemTk);
            this.panel27.Controls.Add(this.btnSuaTK);
            this.panel27.Controls.Add(this.btnXoaTk);
            this.panel27.Controls.Add(this.btnThemTK);
            this.panel27.Location = new System.Drawing.Point(275, 6);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(420, 50);
            this.panel27.TabIndex = 9;
            this.panel27.Paint += new System.Windows.Forms.PaintEventHandler(this.panel27_Paint);
            // 
            // bntThoat
            // 
            this.bntThoat.BackColor = System.Drawing.Color.LightGray;
            this.bntThoat.Location = new System.Drawing.Point(343, 3);
            this.bntThoat.Name = "bntThoat";
            this.bntThoat.Size = new System.Drawing.Size(75, 44);
            this.bntThoat.TabIndex = 4;
            this.bntThoat.Text = "Thoát";
            this.bntThoat.UseVisualStyleBackColor = false;
            this.bntThoat.Click += new System.EventHandler(this.bntThoat_Click);
            // 
            // btnxemTk
            // 
            this.btnxemTk.BackColor = System.Drawing.Color.LightGray;
            this.btnxemTk.Location = new System.Drawing.Point(248, 3);
            this.btnxemTk.Name = "btnxemTk";
            this.btnxemTk.Size = new System.Drawing.Size(75, 44);
            this.btnxemTk.TabIndex = 3;
            this.btnxemTk.Text = "Xem";
            this.btnxemTk.UseVisualStyleBackColor = false;
            this.btnxemTk.Click += new System.EventHandler(this.btnxemTk_Click);
            // 
            // btnSuaTK
            // 
            this.btnSuaTK.BackColor = System.Drawing.Color.LightGray;
            this.btnSuaTK.Location = new System.Drawing.Point(166, 3);
            this.btnSuaTK.Name = "btnSuaTK";
            this.btnSuaTK.Size = new System.Drawing.Size(75, 44);
            this.btnSuaTK.TabIndex = 2;
            this.btnSuaTK.Text = "Sửa";
            this.btnSuaTK.UseVisualStyleBackColor = false;
            this.btnSuaTK.Click += new System.EventHandler(this.btnSuaTK_Click);
            // 
            // btnXoaTk
            // 
            this.btnXoaTk.BackColor = System.Drawing.Color.LightGray;
            this.btnXoaTk.Location = new System.Drawing.Point(85, 3);
            this.btnXoaTk.Name = "btnXoaTk";
            this.btnXoaTk.Size = new System.Drawing.Size(75, 44);
            this.btnXoaTk.TabIndex = 1;
            this.btnXoaTk.Text = "xóa";
            this.btnXoaTk.UseVisualStyleBackColor = false;
            this.btnXoaTk.Click += new System.EventHandler(this.btnXoaTk_Click);
            // 
            // btnThemTK
            // 
            this.btnThemTK.BackColor = System.Drawing.Color.LightGray;
            this.btnThemTK.Location = new System.Drawing.Point(4, 3);
            this.btnThemTK.Name = "btnThemTK";
            this.btnThemTK.Size = new System.Drawing.Size(75, 44);
            this.btnThemTK.TabIndex = 0;
            this.btnThemTK.Text = "Thêm";
            this.btnThemTK.UseVisualStyleBackColor = false;
            this.btnThemTK.Click += new System.EventHandler(this.btnThemTK_Click);
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.panel24);
            this.panel23.Controls.Add(this.btnlammoitk);
            this.panel23.Controls.Add(this.panel29);
            this.panel23.Controls.Add(this.panel25);
            this.panel23.Controls.Add(this.panel26);
            this.panel23.Location = new System.Drawing.Point(421, 62);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(360, 346);
            this.panel23.TabIndex = 7;
            this.panel23.Paint += new System.Windows.Forms.PaintEventHandler(this.panel23_Paint);
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.txbtrangthainhanvien);
            this.panel24.Controls.Add(this.label10);
            this.panel24.Location = new System.Drawing.Point(9, 153);
            this.panel24.Margin = new System.Windows.Forms.Padding(4);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(339, 47);
            this.panel24.TabIndex = 5;
            this.panel24.Paint += new System.Windows.Forms.PaintEventHandler(this.panel24_Paint);
            // 
            // txbtrangthainhanvien
            // 
            this.txbtrangthainhanvien.Location = new System.Drawing.Point(104, 16);
            this.txbtrangthainhanvien.Margin = new System.Windows.Forms.Padding(4);
            this.txbtrangthainhanvien.Name = "txbtrangthainhanvien";
            this.txbtrangthainhanvien.ReadOnly = true;
            this.txbtrangthainhanvien.Size = new System.Drawing.Size(231, 22);
            this.txbtrangthainhanvien.TabIndex = 2;
            this.txbtrangthainhanvien.TextChanged += new System.EventHandler(this.txbtrangthainhanvien_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 22);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 16);
            this.label10.TabIndex = 0;
            this.label10.Text = "Trạng Thái:";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // btnlammoitk
            // 
            this.btnlammoitk.BackColor = System.Drawing.Color.LightGray;
            this.btnlammoitk.Location = new System.Drawing.Point(273, 299);
            this.btnlammoitk.Name = "btnlammoitk";
            this.btnlammoitk.Size = new System.Drawing.Size(75, 44);
            this.btnlammoitk.TabIndex = 4;
            this.btnlammoitk.Text = " Làm Mới";
            this.btnlammoitk.UseVisualStyleBackColor = false;
            this.btnlammoitk.Click += new System.EventHandler(this.btnlammoitk_Click);
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.txbmktk);
            this.panel29.Controls.Add(this.label13);
            this.panel29.Location = new System.Drawing.Point(9, 222);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(345, 47);
            this.panel29.TabIndex = 3;
            this.panel29.Paint += new System.Windows.Forms.PaintEventHandler(this.panel29_Paint);
            // 
            // txbmktk
            // 
            this.txbmktk.Location = new System.Drawing.Point(107, 15);
            this.txbmktk.Name = "txbmktk";
            this.txbmktk.ReadOnly = true;
            this.txbmktk.Size = new System.Drawing.Size(232, 22);
            this.txbmktk.TabIndex = 2;
            this.txbmktk.TextChanged += new System.EventHandler(this.txbmktk_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(9, 18);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 16);
            this.label13.TabIndex = 0;
            this.label13.Text = "Mật Khẩu:";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.txbtenhienthitk);
            this.panel25.Controls.Add(this.label11);
            this.panel25.Location = new System.Drawing.Point(6, 84);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(345, 47);
            this.panel25.TabIndex = 1;
            this.panel25.Paint += new System.Windows.Forms.PaintEventHandler(this.panel25_Paint);
            // 
            // txbtenhienthitk
            // 
            this.txbtenhienthitk.Location = new System.Drawing.Point(110, 15);
            this.txbtenhienthitk.Name = "txbtenhienthitk";
            this.txbtenhienthitk.ReadOnly = true;
            this.txbtenhienthitk.Size = new System.Drawing.Size(232, 22);
            this.txbtenhienthitk.TabIndex = 1;
            this.txbtenhienthitk.TextChanged += new System.EventHandler(this.txbtenhienthitk_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 18);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 16);
            this.label11.TabIndex = 0;
            this.label11.Text = "Tên Hiển Thị";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.txbtentk);
            this.panel26.Controls.Add(this.label12);
            this.panel26.Location = new System.Drawing.Point(3, 12);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(345, 47);
            this.panel26.TabIndex = 0;
            this.panel26.Paint += new System.Windows.Forms.PaintEventHandler(this.panel26_Paint);
            // 
            // txbtentk
            // 
            this.txbtentk.Location = new System.Drawing.Point(110, 15);
            this.txbtentk.Name = "txbtentk";
            this.txbtentk.ReadOnly = true;
            this.txbtentk.Size = new System.Drawing.Size(232, 22);
            this.txbtentk.TabIndex = 1;
            this.txbtentk.TextChanged += new System.EventHandler(this.txbtentk_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 18);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 16);
            this.label12.TabIndex = 0;
            this.label12.Text = "Tên tài khoản";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // tpQuanLyThucDon
            // 
            this.tpQuanLyThucDon.Controls.Add(this.btnQuanLyFile);
            this.tpQuanLyThucDon.Controls.Add(this.panel6);
            this.tpQuanLyThucDon.Controls.Add(this.panel5);
            this.tpQuanLyThucDon.Controls.Add(this.panel4);
            this.tpQuanLyThucDon.Controls.Add(this.panel3);
            this.tpQuanLyThucDon.Location = new System.Drawing.Point(4, 25);
            this.tpQuanLyThucDon.Name = "tpQuanLyThucDon";
            this.tpQuanLyThucDon.Padding = new System.Windows.Forms.Padding(3);
            this.tpQuanLyThucDon.Size = new System.Drawing.Size(1222, 430);
            this.tpQuanLyThucDon.TabIndex = 1;
            this.tpQuanLyThucDon.Text = "Quản Lý Thực Đơn";
            this.tpQuanLyThucDon.UseVisualStyleBackColor = true;
            this.tpQuanLyThucDon.Click += new System.EventHandler(this.tpQuanLyThucDon_Click);
            // 
            // btnQuanLyFile
            // 
            this.btnQuanLyFile.Location = new System.Drawing.Point(1028, 14);
            this.btnQuanLyFile.Name = "btnQuanLyFile";
            this.btnQuanLyFile.Size = new System.Drawing.Size(155, 41);
            this.btnQuanLyFile.TabIndex = 4;
            this.btnQuanLyFile.Text = "Quản Lý File Excel";
            this.btnQuanLyFile.UseVisualStyleBackColor = true;
            this.btnQuanLyFile.Click += new System.EventHandler(this.btnQuanLyFile_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.txbtimFoodName);
            this.panel6.Controls.Add(this.btnTimKiem);
            this.panel6.Location = new System.Drawing.Point(424, 9);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(360, 50);
            this.panel6.TabIndex = 3;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // txbtimFoodName
            // 
            this.txbtimFoodName.Location = new System.Drawing.Point(15, 15);
            this.txbtimFoodName.Name = "txbtimFoodName";
            this.txbtimFoodName.Size = new System.Drawing.Size(249, 22);
            this.txbtimFoodName.TabIndex = 1;
            this.txbtimFoodName.TextChanged += new System.EventHandler(this.txbtimFoodName_TextChanged);
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.BackColor = System.Drawing.Color.Gainsboro;
            this.btnTimKiem.Location = new System.Drawing.Point(282, 3);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(75, 44);
            this.btnTimKiem.TabIndex = 0;
            this.btnTimKiem.Text = "Tìm kiếm";
            this.btnTimKiem.UseVisualStyleBackColor = false;
            this.btnTimKiem.Click += new System.EventHandler(this.btnTimKiem_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnShowFood);
            this.panel5.Controls.Add(this.btnsuafood);
            this.panel5.Controls.Add(this.btnxoafood);
            this.panel5.Controls.Add(this.btnaddfood);
            this.panel5.Location = new System.Drawing.Point(6, 6);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(412, 50);
            this.panel5.TabIndex = 2;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // btnShowFood
            // 
            this.btnShowFood.BackColor = System.Drawing.Color.LightGray;
            this.btnShowFood.Location = new System.Drawing.Point(325, 3);
            this.btnShowFood.Name = "btnShowFood";
            this.btnShowFood.Size = new System.Drawing.Size(75, 44);
            this.btnShowFood.TabIndex = 3;
            this.btnShowFood.Text = "Xem";
            this.btnShowFood.UseVisualStyleBackColor = false;
            this.btnShowFood.Click += new System.EventHandler(this.btnShowFood_Click);
            // 
            // btnsuafood
            // 
            this.btnsuafood.BackColor = System.Drawing.Color.LightGray;
            this.btnsuafood.Location = new System.Drawing.Point(222, 3);
            this.btnsuafood.Name = "btnsuafood";
            this.btnsuafood.Size = new System.Drawing.Size(75, 44);
            this.btnsuafood.TabIndex = 2;
            this.btnsuafood.Text = "Sửa";
            this.btnsuafood.UseVisualStyleBackColor = false;
            this.btnsuafood.Click += new System.EventHandler(this.btnsuafood_Click);
            // 
            // btnxoafood
            // 
            this.btnxoafood.BackColor = System.Drawing.Color.LightGray;
            this.btnxoafood.Location = new System.Drawing.Point(113, 3);
            this.btnxoafood.Name = "btnxoafood";
            this.btnxoafood.Size = new System.Drawing.Size(75, 44);
            this.btnxoafood.TabIndex = 1;
            this.btnxoafood.Text = "xóa";
            this.btnxoafood.UseVisualStyleBackColor = false;
            this.btnxoafood.Click += new System.EventHandler(this.btnxoafood_Click);
            // 
            // btnaddfood
            // 
            this.btnaddfood.BackColor = System.Drawing.Color.LightGray;
            this.btnaddfood.Location = new System.Drawing.Point(4, 3);
            this.btnaddfood.Name = "btnaddfood";
            this.btnaddfood.Size = new System.Drawing.Size(75, 44);
            this.btnaddfood.TabIndex = 0;
            this.btnaddfood.Text = "Thêm";
            this.btnaddfood.UseVisualStyleBackColor = false;
            this.btnaddfood.Click += new System.EventHandler(this.btnaddfood_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel14);
            this.panel4.Controls.Add(this.panel10);
            this.panel4.Controls.Add(this.panel9);
            this.panel4.Controls.Add(this.panel8);
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Location = new System.Drawing.Point(838, 65);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(360, 359);
            this.panel4.TabIndex = 1;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.txbSoLuong);
            this.panel14.Controls.Add(this.label6);
            this.panel14.Location = new System.Drawing.Point(3, 235);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(345, 47);
            this.panel14.TabIndex = 4;
            this.panel14.Paint += new System.Windows.Forms.PaintEventHandler(this.panel14_Paint);
            // 
            // txbSoLuong
            // 
            this.txbSoLuong.Location = new System.Drawing.Point(78, 15);
            this.txbSoLuong.Name = "txbSoLuong";
            this.txbSoLuong.ReadOnly = true;
            this.txbSoLuong.Size = new System.Drawing.Size(264, 22);
            this.txbSoLuong.TabIndex = 1;
            this.txbSoLuong.TextChanged += new System.EventHandler(this.txbSoLuong_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(8, 21);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "Số Lượng";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.txbFoodPrice);
            this.panel10.Controls.Add(this.label4);
            this.panel10.Location = new System.Drawing.Point(3, 171);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(345, 47);
            this.panel10.TabIndex = 3;
            this.panel10.Paint += new System.Windows.Forms.PaintEventHandler(this.panel10_Paint);
            // 
            // txbFoodPrice
            // 
            this.txbFoodPrice.Location = new System.Drawing.Point(78, 11);
            this.txbFoodPrice.Name = "txbFoodPrice";
            this.txbFoodPrice.Size = new System.Drawing.Size(253, 22);
            this.txbFoodPrice.TabIndex = 1;
            this.txbFoodPrice.TextChanged += new System.EventHandler(this.txbFoodPrice_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Giá:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.txbDanhMucFood);
            this.panel9.Controls.Add(this.label3);
            this.panel9.Location = new System.Drawing.Point(3, 118);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(345, 47);
            this.panel9.TabIndex = 2;
            this.panel9.Paint += new System.Windows.Forms.PaintEventHandler(this.panel9_Paint);
            // 
            // txbDanhMucFood
            // 
            this.txbDanhMucFood.Location = new System.Drawing.Point(78, 15);
            this.txbDanhMucFood.Name = "txbDanhMucFood";
            this.txbDanhMucFood.Size = new System.Drawing.Size(253, 22);
            this.txbDanhMucFood.TabIndex = 1;
            this.txbDanhMucFood.TextChanged += new System.EventHandler(this.txbDanhMucFood_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Danh mục:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.txbfoodname);
            this.panel8.Controls.Add(this.label2);
            this.panel8.Location = new System.Drawing.Point(3, 65);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(345, 47);
            this.panel8.TabIndex = 1;
            this.panel8.Paint += new System.Windows.Forms.PaintEventHandler(this.panel8_Paint);
            // 
            // txbfoodname
            // 
            this.txbfoodname.Location = new System.Drawing.Point(78, 15);
            this.txbfoodname.Name = "txbfoodname";
            this.txbfoodname.ReadOnly = true;
            this.txbfoodname.Size = new System.Drawing.Size(264, 22);
            this.txbfoodname.TabIndex = 1;
            this.txbfoodname.TextChanged += new System.EventHandler(this.txbfoodname_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Tên món:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.txbFoodID);
            this.panel7.Controls.Add(this.label1);
            this.panel7.Location = new System.Drawing.Point(3, 12);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(345, 47);
            this.panel7.TabIndex = 0;
            this.panel7.Paint += new System.Windows.Forms.PaintEventHandler(this.panel7_Paint);
            // 
            // txbFoodID
            // 
            this.txbFoodID.Location = new System.Drawing.Point(78, 15);
            this.txbFoodID.Name = "txbFoodID";
            this.txbFoodID.ReadOnly = true;
            this.txbFoodID.Size = new System.Drawing.Size(253, 22);
            this.txbFoodID.TabIndex = 1;
            this.txbFoodID.TextChanged += new System.EventHandler(this.txbFoodID_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dgvQuanLyThucdon);
            this.panel3.Location = new System.Drawing.Point(6, 62);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(826, 362);
            this.panel3.TabIndex = 0;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // dgvQuanLyThucdon
            // 
            this.dgvQuanLyThucdon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvQuanLyThucdon.Location = new System.Drawing.Point(4, 3);
            this.dgvQuanLyThucdon.Name = "dgvQuanLyThucdon";
            this.dgvQuanLyThucdon.RowHeadersWidth = 51;
            this.dgvQuanLyThucdon.RowTemplate.Height = 24;
            this.dgvQuanLyThucdon.Size = new System.Drawing.Size(819, 356);
            this.dgvQuanLyThucdon.TabIndex = 0;
            this.dgvQuanLyThucdon.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvQuanLyThucdon_CellContentClick);
            // 
            // tpDoanhThu
            // 
            this.tpDoanhThu.Controls.Add(this.panel12);
            this.tpDoanhThu.Controls.Add(this.panel11);
            this.tpDoanhThu.Controls.Add(this.panel2);
            this.tpDoanhThu.Controls.Add(this.panel1);
            this.tpDoanhThu.Location = new System.Drawing.Point(4, 25);
            this.tpDoanhThu.Name = "tpDoanhThu";
            this.tpDoanhThu.Padding = new System.Windows.Forms.Padding(3);
            this.tpDoanhThu.Size = new System.Drawing.Size(1222, 430);
            this.tpDoanhThu.TabIndex = 0;
            this.tpDoanhThu.Text = "Doanh thu";
            this.tpDoanhThu.UseVisualStyleBackColor = true;
            this.tpDoanhThu.Click += new System.EventHandler(this.tpDoanhThu_Click);
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.chartDoanhThu);
            this.panel12.Location = new System.Drawing.Point(787, 6);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(434, 418);
            this.panel12.TabIndex = 3;
            this.panel12.Paint += new System.Windows.Forms.PaintEventHandler(this.panel12_Paint);
            // 
            // chartDoanhThu
            // 
            chartArea1.Name = "ChartArea1";
            this.chartDoanhThu.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chartDoanhThu.Legends.Add(legend1);
            this.chartDoanhThu.Location = new System.Drawing.Point(3, 3);
            this.chartDoanhThu.Name = "chartDoanhThu";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chartDoanhThu.Series.Add(series1);
            this.chartDoanhThu.Size = new System.Drawing.Size(426, 367);
            this.chartDoanhThu.TabIndex = 0;
            this.chartDoanhThu.Text = "chartDoanhThu";
            this.chartDoanhThu.Click += new System.EventHandler(this.chartDoanhThu_Click);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.ListViewTopSanPhamBanChay);
            this.panel11.Location = new System.Drawing.Point(414, 51);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(370, 376);
            this.panel11.TabIndex = 2;
            this.panel11.Paint += new System.Windows.Forms.PaintEventHandler(this.panel11_Paint);
            // 
            // ListViewTopSanPhamBanChay
            // 
            this.ListViewTopSanPhamBanChay.HideSelection = false;
            this.ListViewTopSanPhamBanChay.Location = new System.Drawing.Point(3, 3);
            this.ListViewTopSanPhamBanChay.Name = "ListViewTopSanPhamBanChay";
            this.ListViewTopSanPhamBanChay.Size = new System.Drawing.Size(364, 367);
            this.ListViewTopSanPhamBanChay.TabIndex = 0;
            this.ListViewTopSanPhamBanChay.UseCompatibleStateImageBehavior = false;
            this.ListViewTopSanPhamBanChay.SelectedIndexChanged += new System.EventHandler(this.ListViewTopSanPhamBanChay_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.GreenYellow;
            this.panel2.Controls.Add(this.btnxuatexecl);
            this.panel2.Controls.Add(this.btnxemdoanhthu);
            this.panel2.Controls.Add(this.dtpkFromday);
            this.panel2.Controls.Add(this.dtpkToday);
            this.panel2.Location = new System.Drawing.Point(6, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(775, 39);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // btnxuatexecl
            // 
            this.btnxuatexecl.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnxuatexecl.Location = new System.Drawing.Point(652, 2);
            this.btnxuatexecl.Name = "btnxuatexecl";
            this.btnxuatexecl.Size = new System.Drawing.Size(120, 31);
            this.btnxuatexecl.TabIndex = 3;
            this.btnxuatexecl.Text = "Xuất File Excel";
            this.btnxuatexecl.UseVisualStyleBackColor = false;
            this.btnxuatexecl.Click += new System.EventHandler(this.btnxuatexecl_Click);
            // 
            // btnxemdoanhthu
            // 
            this.btnxemdoanhthu.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnxemdoanhthu.Location = new System.Drawing.Point(571, 3);
            this.btnxemdoanhthu.Name = "btnxemdoanhthu";
            this.btnxemdoanhthu.Size = new System.Drawing.Size(75, 30);
            this.btnxemdoanhthu.TabIndex = 2;
            this.btnxemdoanhthu.Text = "Thống kê";
            this.btnxemdoanhthu.UseVisualStyleBackColor = false;
            this.btnxemdoanhthu.Click += new System.EventHandler(this.btnxemdoanhthu_Click);
            // 
            // dtpkFromday
            // 
            this.dtpkFromday.Location = new System.Drawing.Point(3, 4);
            this.dtpkFromday.Name = "dtpkFromday";
            this.dtpkFromday.Size = new System.Drawing.Size(200, 22);
            this.dtpkFromday.TabIndex = 1;
            this.dtpkFromday.ValueChanged += new System.EventHandler(this.dtpkFromday_ValueChanged);
            // 
            // dtpkToday
            // 
            this.dtpkToday.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.dtpkToday.CalendarTitleForeColor = System.Drawing.SystemColors.Info;
            this.dtpkToday.Location = new System.Drawing.Point(209, 5);
            this.dtpkToday.Name = "dtpkToday";
            this.dtpkToday.Size = new System.Drawing.Size(200, 22);
            this.dtpkToday.TabIndex = 0;
            this.dtpkToday.ValueChanged += new System.EventHandler(this.dtpkToday_ValueChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Khaki;
            this.panel1.Controls.Add(this.listViewDoanhThu);
            this.panel1.Location = new System.Drawing.Point(6, 51);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(402, 373);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // listViewDoanhThu
            // 
            this.listViewDoanhThu.HideSelection = false;
            this.listViewDoanhThu.Location = new System.Drawing.Point(4, 3);
            this.listViewDoanhThu.Name = "listViewDoanhThu";
            this.listViewDoanhThu.Size = new System.Drawing.Size(395, 367);
            this.listViewDoanhThu.TabIndex = 0;
            this.listViewDoanhThu.UseCompatibleStateImageBehavior = false;
            this.listViewDoanhThu.SelectedIndexChanged += new System.EventHandler(this.listViewDoanhThu_SelectedIndexChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpDoanhThu);
            this.tabControl1.Controls.Add(this.tpQuanLyThucDon);
            this.tabControl1.Controls.Add(this.tpquanlynhanvien);
            this.tabControl1.Controls.Add(this.tpQuanLyHoatDong);
            this.tabControl1.Location = new System.Drawing.Point(-2, 16);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1230, 459);
            this.tabControl1.TabIndex = 2;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // quanly
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1244, 491);
            this.Controls.Add(this.tabControl1);
            this.Name = "quanly";
            this.Text = "quanly";
            this.Load += new System.EventHandler(this.btnaddfood_Click);
            this.tpQuanLyHoatDong.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.tpquanlynhanvien.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.drgvnhanvien)).EndInit();
            this.panel27.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.tpQuanLyThucDon.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvQuanLyThucdon)).EndInit();
            this.tpDoanhThu.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartDoanhThu)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tpQuanLyHoatDong;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.TextBox txbHoatDongHomNay;
        private System.Windows.Forms.TextBox txbTongSoHoatDong;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.ListView listViewHoatDong;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TextBox txbTimKiemHoatDong;
        private System.Windows.Forms.ComboBox cmbTimKiemHoatDong;
        private System.Windows.Forms.Button btnTimKiemHoatDong;
        private System.Windows.Forms.Button btnlammoi;
        private System.Windows.Forms.DateTimePicker dtpkFromdayHoatDong;
        private System.Windows.Forms.DateTimePicker dtpkTodayHoatDong;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage tpquanlynhanvien;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.DateTimePicker dtpkTodaynhanvien;
        private System.Windows.Forms.DateTimePicker dtpkFromdaynhanvien;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.GroupBox gbThongKeNhanVien;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.DataGridView drgvnhanvien;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Button bntThoat;
        private System.Windows.Forms.Button btnxemTk;
        private System.Windows.Forms.Button btnSuaTK;
        private System.Windows.Forms.Button btnXoaTk;
        private System.Windows.Forms.Button btnThemTK;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.TextBox txbtrangthainhanvien;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnlammoitk;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.TextBox txbmktk;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.TextBox txbtenhienthitk;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.TextBox txbtentk;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage tpQuanLyThucDon;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txbtimFoodName;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnShowFood;
        private System.Windows.Forms.Button btnsuafood;
        private System.Windows.Forms.Button btnxoafood;
        private System.Windows.Forms.Button btnaddfood;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.TextBox txbSoLuong;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TextBox txbFoodPrice;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox txbDanhMucFood;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txbfoodname;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txbFoodID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dgvQuanLyThucdon;
        private System.Windows.Forms.TabPage tpDoanhThu;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartDoanhThu;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.ListView ListViewTopSanPhamBanChay;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnxuatexecl;
        private System.Windows.Forms.Button btnxemdoanhthu;
        private System.Windows.Forms.DateTimePicker dtpkFromday;
        private System.Windows.Forms.DateTimePicker dtpkToday;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView listViewDoanhThu;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Button btnQuanLyFile;
    }
}