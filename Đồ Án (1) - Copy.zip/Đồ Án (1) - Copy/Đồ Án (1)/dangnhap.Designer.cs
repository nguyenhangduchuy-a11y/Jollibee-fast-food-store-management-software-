﻿namespace Đồ_Án__1_
{
    partial class dangnhap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.thoat = new System.Windows.Forms.Button();
            this.vaoquenmk = new System.Windows.Forms.Button();
            this.vaodk = new System.Windows.Forms.Button();
            this.dangnhaptc = new System.Windows.Forms.Button();
            this.nhapmk = new System.Windows.Forms.TextBox();
            this.nhaptaikhoan = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Brown;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(340, 450);
            this.panel1.TabIndex = 20;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Đồ_Án__1_.Properties.Resources.rsz_logo465x320_15661206418131531198284_crop_1566120651485907373755_1;
            this.pictureBox1.Location = new System.Drawing.Point(3, 74);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(337, 215);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // thoat
            // 
            this.thoat.BackColor = System.Drawing.Color.Yellow;
            this.thoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.thoat.Location = new System.Drawing.Point(631, 398);
            this.thoat.Name = "thoat";
            this.thoat.Size = new System.Drawing.Size(147, 40);
            this.thoat.TabIndex = 19;
            this.thoat.Text = "THOÁT";
            this.thoat.UseVisualStyleBackColor = false;
            this.thoat.Click += new System.EventHandler(this.thoat_Click);
            // 
            // vaoquenmk
            // 
            this.vaoquenmk.BackColor = System.Drawing.Color.Yellow;
            this.vaoquenmk.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vaoquenmk.Location = new System.Drawing.Point(422, 398);
            this.vaoquenmk.Name = "vaoquenmk";
            this.vaoquenmk.Size = new System.Drawing.Size(147, 40);
            this.vaoquenmk.TabIndex = 18;
            this.vaoquenmk.Text = "QUÊN MẬT KHẨU";
            this.vaoquenmk.UseVisualStyleBackColor = false;
            this.vaoquenmk.Click += new System.EventHandler(this.vaoquenmk_Click);
            // 
            // vaodk
            // 
            this.vaodk.BackColor = System.Drawing.Color.Yellow;
            this.vaodk.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vaodk.Location = new System.Drawing.Point(631, 328);
            this.vaodk.Name = "vaodk";
            this.vaodk.Size = new System.Drawing.Size(147, 40);
            this.vaodk.TabIndex = 17;
            this.vaodk.Text = "ĐĂNG KÝ";
            this.vaodk.UseVisualStyleBackColor = false;
            this.vaodk.Click += new System.EventHandler(this.vaodk_Click);
            // 
            // dangnhaptc
            // 
            this.dangnhaptc.BackColor = System.Drawing.Color.Yellow;
            this.dangnhaptc.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dangnhaptc.Location = new System.Drawing.Point(422, 328);
            this.dangnhaptc.Name = "dangnhaptc";
            this.dangnhaptc.Size = new System.Drawing.Size(147, 40);
            this.dangnhaptc.TabIndex = 16;
            this.dangnhaptc.Text = "ĐĂNG NHẬP";
            this.dangnhaptc.UseVisualStyleBackColor = false;
            this.dangnhaptc.Click += new System.EventHandler(this.dangnhaptc_Click);
            // 
            // nhapmk
            // 
            this.nhapmk.Location = new System.Drawing.Point(476, 245);
            this.nhapmk.Name = "nhapmk";
            this.nhapmk.Size = new System.Drawing.Size(255, 22);
            this.nhapmk.TabIndex = 15;
            this.nhapmk.TextChanged += new System.EventHandler(this.nhapmk_TextChanged);
            // 
            // nhaptaikhoan
            // 
            this.nhaptaikhoan.Location = new System.Drawing.Point(476, 147);
            this.nhaptaikhoan.Name = "nhaptaikhoan";
            this.nhaptaikhoan.Size = new System.Drawing.Size(274, 22);
            this.nhaptaikhoan.TabIndex = 14;
            this.nhaptaikhoan.TextChanged += new System.EventHandler(this.nhaptaikhoan_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(373, 251);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 16);
            this.label3.TabIndex = 13;
            this.label3.Text = "MẬT KHẨU :";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(373, 153);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 16);
            this.label2.TabIndex = 12;
            this.label2.Text = "TÀI KHOẢN :";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(491, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(206, 52);
            this.label1.TabIndex = 11;
            this.label1.Text = "ĐĂNG NHẬP";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(737, 250);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(61, 20);
            this.checkBox1.TabIndex = 21;
            this.checkBox1.Text = "Hiện";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // dangnhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Brown;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.thoat);
            this.Controls.Add(this.vaoquenmk);
            this.Controls.Add(this.vaodk);
            this.Controls.Add(this.dangnhaptc);
            this.Controls.Add(this.nhapmk);
            this.Controls.Add(this.nhaptaikhoan);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkBox1);
            this.Name = "dangnhap";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button thoat;
        private System.Windows.Forms.Button vaoquenmk;
        private System.Windows.Forms.Button vaodk;
        private System.Windows.Forms.Button dangnhaptc;
        private System.Windows.Forms.TextBox nhapmk;
        private System.Windows.Forms.TextBox nhaptaikhoan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}

