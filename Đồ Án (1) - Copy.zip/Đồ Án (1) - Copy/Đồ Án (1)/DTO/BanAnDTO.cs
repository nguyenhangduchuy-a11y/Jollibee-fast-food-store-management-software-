﻿// DTO/BanAnDTO.cs
namespace Đồ_Án__1_.DTO
{
    public class BanAnDTO
    {
        public int IDBan { get; set; }
        public string TenBan { get; set; }
        public int TrangThai { get; set; }

        public BanAnDTO()
        {
            TenBan = string.Empty;
        }

        public string TenTrangThai
        {
            get
            {
                switch (TrangThai)
                {
                    case 0:
                        return "Trống";
                    case 1:
                        return "Đang dùng";
                    case 2:
                        return "Cần dọn";
                    default:
                        return "Không xác định";
                }
            }
        }
    }
}
