﻿// DTO/HoaDonDTO.cs
using System;

namespace Đồ_Án__1_.DTO
{
    public class HoaDonDTO
    {
        public int IDHoaDon { get; set; }
        public string MaHoaDon { get; set; }
        public int? IDKhachHang { get; set; }
        public string TenKhachHang { get; set; }
        public int? IDNhanVien { get; set; }
        public string TenNhanVien { get; set; }
        public DateTime NgayLap { get; set; }
        public decimal TongTien { get; set; }
        public int LoaiDon { get; set; }
        public int? IDBan { get; set; }
        public string TenBan { get; set; }
        public string PhuongThucThanhToan { get; set; }
        public int TrangThai { get; set; }

        // 🔧 THÊM THUỘC TÍNH NÀY
        public int TrangThaiDon { get; set; }  // 0: Chờ xác nhận, 1: Đã xác nhận, 2: Đã thanh toán, 3: Đã hủy

        public string GhiChu { get; set; }
        public string GhiChuNhanVien { get; set; }  // Thêm nếu cần

        public HoaDonDTO()
        {
            MaHoaDon = string.Empty;
            TenKhachHang = string.Empty;
            TenNhanVien = string.Empty;
            TenBan = string.Empty;
            PhuongThucThanhToan = "Tiền mặt";
            GhiChu = string.Empty;
            GhiChuNhanVien = string.Empty;
            TrangThaiDon = 0;  // Giá trị mặc định
        }

        public string TongTienFormat
        {
            get { return string.Format("{0:N0} đ", TongTien); }
        }

        public string NgayLapFormat
        {
            get { return NgayLap.ToString("dd/MM/yyyy HH:mm"); }
        }

        public string TenLoaiDon
        {
            get
            {
                switch (LoaiDon)
                {
                    case 1:
                        return "Ăn tại bàn";
                    case 2:
                        return "Mang về";
                    case 3:
                        return "Tự order";
                    default:
                        return "Không xác định";
                }
            }
        }
        public int SoLuongMon { get; set; }
        public string TenTrangThai
        {
            get
            {
                switch (TrangThai)
                {
                    case 0:
                        return "Chưa thanh toán";
                    case 1:
                        return "Đã thanh toán";
                    default:
                        return "Không xác định";
                }
            }
        }

        // 🔧 THÊM PROPERTY NÀY ĐỂ HIỂN THỊ TRẠNG THÁI ĐƠN
        public string TenTrangThaiDon
        {
            get
            {
                switch (TrangThaiDon)
                {
                    case 0:
                        return "Chờ xác nhận";
                    case 1:
                        return "Đã xác nhận";
                    case 2:
                        return "Đã thanh toán";
                    case 3:
                        return "Đã hủy";
                    default:
                        return "Không xác định";
                }
            }
        }
    }
}