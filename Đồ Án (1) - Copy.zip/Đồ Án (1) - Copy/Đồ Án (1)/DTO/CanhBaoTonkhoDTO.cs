﻿// DTO/CanhBaoTonKhoDTO.cs
namespace Đồ_Án__1_.DTO
{
    public class CanhBaoTonKhoDTO
    {
        public int IDSanPham { get; set; }
        public string MaSanPham { get; set; }
        public string TenSanPham { get; set; }
        public int SoLuongTon { get; set; }
        public int TonToiThieu { get; set; }
        public string TrangThai { get; set; }

        public CanhBaoTonKhoDTO()
        {
            MaSanPham = string.Empty;
            TenSanPham = string.Empty;
            TrangThai = string.Empty;
        }

        public bool LaHetHang
        {
            get { return TrangThai == "HẾT HÀNG"; }
        }

        public bool LaSapHet
        {
            get { return TrangThai == "SẮP HẾT"; }
        }
    }
}
