﻿// DTO/NguoiDungDTO.cs
using System;

namespace Đồ_Án__1_.DTO
{
    public class NguoiDungDTO
    {
        public int IDNguoiDung { get; set; }
        public string TenDangNhap { get; set; }
        public string MatKhauHash { get; set; }
        public string HoTen { get; set; }
        public int VaiTro { get; set; }
        public bool KichHoat { get; set; }
        public DateTime NgayTao { get; set; }
        public DateTime? LanDangNhapCuoi { get; set; }

        public NguoiDungDTO()
        {
            TenDangNhap = string.Empty;
            MatKhauHash = string.Empty;
            HoTen = string.Empty;
        }

        public string TenVaiTro
        {
            get
            {
                switch (VaiTro)
                {
                    case 1:
                        return "Quản lý";
                    case 2:
                        return "Nhân viên";
                    case 3:
                        return "Khách hàng";
                    default:
                        return "Không xác định";
                }
            }
        }

        public string TrangThaiHienThi
        {
            get { return KichHoat ? "Hoạt động" : "Đã khóa"; }
        }
    }
}
