﻿// DTO/DoanhThuDTO.cs
using System;

namespace Đồ_Án__1_.DTO
{
    public class DoanhThuDTO
    {
        public DateTime Ngay { get; set; }
        public string NgayText { get; set; }
        public int SoDon { get; set; }
        public decimal DoanhThu { get; set; }
        public decimal TrungBinhDon { get; set; }
        public decimal DonCaoNhat { get; set; }
        public decimal DonThapNhat { get; set; }

        public DoanhThuDTO()
        {
            NgayText = string.Empty;
        }

        public string DoanhThuFormat
        {
            get { return string.Format("{0:N0} đ", DoanhThu); }
        }
    }
}
