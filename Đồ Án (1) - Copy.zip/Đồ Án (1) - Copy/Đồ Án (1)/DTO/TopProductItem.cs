﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Đồ_Án__1_.DTO
{
    public class TopProductItem
    {
        public string TenSanPham { get; set; }
        public int SoLuong { get; set; }
        public int MaxValue { get; set; }
    }
}