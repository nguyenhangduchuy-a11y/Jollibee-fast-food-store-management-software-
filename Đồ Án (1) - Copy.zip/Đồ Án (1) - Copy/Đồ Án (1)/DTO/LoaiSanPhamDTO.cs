﻿// DTO/LoaiSanPhamDTO.cs
namespace Đồ_Án__1_.DTO
{
    public class LoaiSanPhamDTO
    {
        public int IDLoai { get; set; }
        public string TenLoai { get; set; }
        public bool KichHoat { get; set; }

        public LoaiSanPhamDTO()
        {
            TenLoai = string.Empty;
        }

        public string TrangThaiHienThi
        {
            get { return KichHoat ? "Hoạt động" : "Đã khóa"; }
        }
    }
}
