﻿using System;

namespace Đồ_Án__1_.DTO
{
    public class ThongKeNhanVienDTO
    {
        public int SoDonHoanThanh { get; set; }
        public decimal TongDoanhThu { get; set; }
        public decimal TrungBinhDon { get; set; }

        public string TongDoanhThuFormat
        {
            get { return string.Format("{0:N0} đ", TongDoanhThu); }
        }

        public string TrungBinhDonFormat
        {
            get { return string.Format("{0:N0} đ", TrungBinhDon); }
        }

        public ThongKeNhanVienDTO()
        {
            SoDonHoanThanh = 0;
            TongDoanhThu = 0;
            TrungBinhDon = 0;
        }
    }
}