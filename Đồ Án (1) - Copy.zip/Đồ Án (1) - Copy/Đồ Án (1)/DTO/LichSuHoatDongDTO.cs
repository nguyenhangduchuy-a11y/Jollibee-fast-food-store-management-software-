﻿// DTO/LichSuHoatDongDTO.cs
using System;

namespace Đồ_Án__1_.DTO
{
    /// <summary>
    /// DTO cho bảng LichSuHoatDong - Lưu lịch sử mọi hoạt động trên hệ thống
    /// </summary>
    public class LichSuHoatDongDTO
    {
        /// <summary>
        /// ID lịch sử (khóa chính)
        /// </summary>
        public int IDLichSu { get; set; }

        /// <summary>
        /// Người thực hiện hành động (tên đăng nhập hoặc HỆ THỐNG)
        /// </summary>
        public string NguoiThucHien { get; set; }

        /// <summary>
        /// ID người dùng (liên kết với bảng NguoiDung, có thể NULL)
        /// </summary>
        public int? IDNguoiDung { get; set; }

        /// <summary>
        /// Tên người dùng (lấy từ JOIN, dùng cho hiển thị)
        /// </summary>
        public string TenNguoiDung { get; set; }

        /// <summary>
        /// Thời gian thực hiện hành động
        /// </summary>
        public DateTime ThoiGian { get; set; }

        /// <summary>
        /// Thời gian định dạng chuỗi (dd/MM/yyyy HH:mm:ss)
        /// </summary>
        public string ThoiGianText { get; set; }

        /// <summary>
        /// Hành động: ĐĂNG NHẬP, THÊM, SỬA, XÓA, THANH TOÁN, DỌN BÀN,...
        /// </summary>
        public string HanhDong { get; set; }

        /// <summary>
        /// Đối tượng tác động: SẢN PHẨM, NHÂN VIÊN, HÓA ĐƠN, BÀN ĂN,...
        /// </summary>
        public string DoiTuong { get; set; }

        /// <summary>
        /// ID của đối tượng bị tác động (có thể NULL)
        /// </summary>
        public int? IDDoiTuong { get; set; }

        /// <summary>
        /// Chi tiết hành động (mô tả cụ thể)
        /// </summary>
        public string ChiTiet { get; set; }

        /// <summary>
        /// Địa chỉ IP của máy thực hiện hành động
        /// </summary>
        public string DiaChiIP { get; set; }

        /// <summary>
        /// Thông tin thiết bị (Computer Name, OS, v.v.)
        /// </summary>
        public string ThietBi { get; set; }

        /// <summary>
        /// Constructor khởi tạo giá trị mặc định
        /// </summary>
        public LichSuHoatDongDTO()
        {
            NguoiThucHien = string.Empty;
            HanhDong = string.Empty;
            DoiTuong = string.Empty;
            ChiTiet = string.Empty;
            DiaChiIP = string.Empty;
            ThietBi = string.Empty;
            ThoiGianText = string.Empty;
            TenNguoiDung = string.Empty;
        }

        /// <summary>
        /// Kiểm tra có phải là hành động THÊM không
        /// </summary>
        public bool LaHanhDongThem => HanhDong == HanhDongHeThong.THEM;

        /// <summary>
        /// Kiểm tra có phải là hành động SỬA không
        /// </summary>
        public bool LaHanhDongSua => HanhDong == HanhDongHeThong.SUA;

        /// <summary>
        /// Kiểm tra có phải là hành động XÓA không
        /// </summary>
        public bool LaHanhDongXoa => HanhDong == HanhDongHeThong.XOA;

        /// <summary>
        /// Kiểm tra có phải là hành động ĐĂNG NHẬP không
        /// </summary>
        public bool LaHanhDongDangNhap => HanhDong == HanhDongHeThong.DANG_NHAP;

        /// <summary>
        /// Kiểm tra có phải là hành động THANH TOÁN không
        /// </summary>
        public bool LaHanhDongThanhToan => HanhDong == HanhDongHeThong.THANH_TOAN;

        /// <summary>
        /// Lấy màu sắc cho từng loại hành động (dùng trong ListView)
        /// </summary>
        public System.Drawing.Color MauHanhDong
        {
            get
            {
                switch (HanhDong)
                {
                    case "ĐĂNG NHẬP":
                    case "ĐĂNG XUẤT":
                        return System.Drawing.Color.FromArgb(52, 152, 219); // Xanh dương

                    case "THÊM":
                        return System.Drawing.Color.FromArgb(46, 204, 113); // Xanh lá

                    case "SỬA":
                        return System.Drawing.Color.FromArgb(241, 196, 15); // Vàng cam

                    case "XÓA":
                    case "KHÓA":
                        return System.Drawing.Color.FromArgb(231, 76, 60); // Đỏ

                    case "MỞ KHÓA":
                        return System.Drawing.Color.FromArgb(155, 89, 182); // Tím

                    case "THANH TOÁN":
                        return System.Drawing.Color.FromArgb(142, 68, 173); // Tím đậm

                    case "DỌN BÀN":
                        return System.Drawing.Color.FromArgb(26, 188, 156); // Xanh ngọc

                    case "CHUYỂN BÀN":
                        return System.Drawing.Color.FromArgb(52, 73, 94); // Xanh đen

                    case "NHẬP KHO":
                        return System.Drawing.Color.FromArgb(243, 156, 18); // Cam

                    case "XEM BÁO CÁO":
                    case "XUẤT EXCEL":
                        return System.Drawing.Color.FromArgb(149, 165, 166); // Xám

                    default:
                        return System.Drawing.Color.FromArgb(44, 62, 80); // Mặc định
                }
            }
        }

        /// <summary>
        /// Lấy biểu tượng emoji cho hành động
        /// </summary>
        public string EmojiHanhDong
        {
            get
            {
                switch (HanhDong)
                {
                    case "ĐĂNG NHẬP": return "🔐";
                    case "ĐĂNG XUẤT": return "🚪";
                    case "THÊM": return "➕";
                    case "SỬA": return "✏️";
                    case "XÓA": return "❌";
                    case "KHÓA": return "🔒";
                    case "MỞ KHÓA": return "🔓";
                    case "THANH TOÁN": return "💰";
                    case "DỌN BÀN": return "🧹";
                    case "CHUYỂN BÀN": return "🔄";
                    case "NHẬP KHO": return "📦";
                    case "XEM BÁO CÁO": return "📊";
                    case "XUẤT EXCEL": return "📎";
                    default: return "📝";
                }
            }
        }

        /// <summary>
        /// Chuỗi hiển thị đầy đủ (dùng cho Tooltip)
        /// </summary>
        public string ThongTinChiTiet
        {
            get
            {
                return $"{EmojiHanhDong} {HanhDong}\n" +
                       $"📌 Đối tượng: {DoiTuong}\n" +
                       $"👤 Người thực hiện: {NguoiThucHien}\n" +
                       $"🕐 Thời gian: {ThoiGianText}\n" +
                       $"📝 Chi tiết: {ChiTiet}\n" +
                       $"🖥️ IP: {DiaChiIP}\n" +
                       $"💻 Thiết bị: {ThietBi}";
            }
        }
    }

    // =====================================================
    // ENUM ĐỊNH NGHĨA CÁC HÀNH ĐỘNG TRONG HỆ THỐNG
    // =====================================================

    /// <summary>
    /// Các loại hành động trong hệ thống
    /// </summary>
    public static class HanhDongHeThong
    {
        public const string DANG_NHAP = "ĐĂNG NHẬP";
        public const string DANG_XUAT = "ĐĂNG XUẤT";
        public const string THEM = "THÊM";
        public const string SUA = "SỬA";
        public const string XOA = "XÓA";
        public const string KHOA = "KHÓA";
        public const string MO_KHOA = "MỞ KHÓA";
        public const string THANH_TOAN = "THANH TOÁN";
        public const string DON_BAN = "DỌN BÀN";
        public const string CHUYEN_BAN = "CHUYỂN BÀN";
        public const string NHAP_KHO = "NHẬP KHO";
        public const string XEM_BAO_CAO = "XEM BÁO CÁO";
        public const string XUAT_EXCEL = "XUẤT EXCEL";
        public const string DOI_MAT_KHAU = "ĐỔI MẬT KHẨU";
        public const string CAP_NHAT_THONG_TIN = "CẬP NHẬT THÔNG TIN";
    }

    // =====================================================
    // ENUM ĐỊNH NGHĨA CÁC ĐỐI TƯỢNG TRONG HỆ THỐNG
    // =====================================================

    /// <summary>
    /// Các loại đối tượng trong hệ thống
    /// </summary>
    public static class DoiTuongHeThong
    {
        public const string SAN_PHAM = "SẢN PHẨM";
        public const string NHAN_VIEN = "NHÂN VIÊN";
        public const string KHACH_HANG = "KHÁCH HÀNG";
        public const string BAN_AN = "BÀN ĂN";
        public const string HOA_DON = "HÓA ĐƠN";
        public const string TAI_KHOAN = "TÀI KHOẢN";
        public const string HE_THONG = "HỆ THỐNG";
        public const string BAO_CAO = "BÁO CÁO";
        public const string DANH_MUC = "DANH MỤC";
    }
}