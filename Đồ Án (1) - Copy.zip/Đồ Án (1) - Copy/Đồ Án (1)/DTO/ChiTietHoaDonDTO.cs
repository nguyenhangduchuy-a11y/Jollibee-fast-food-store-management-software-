﻿// DTO/ChiTietHoaDonDTO.cs
namespace Đồ_Án__1_.DTO
{
    public class ChiTietHoaDonDTO
    {
        public int IDChiTiet { get; set; }
        public int IDHoaDon { get; set; }
        public int IDSanPham { get; set; }
        public string MaSanPham { get; set; }
        public string TenSanPham { get; set; }
        public int SoLuong { get; set; }
        public decimal DonGia { get; set; }
        public decimal ThanhTien { get; set; }
        public string GhiChu { get; set; }

        public ChiTietHoaDonDTO()
        {
            MaSanPham = string.Empty;
            TenSanPham = string.Empty;
            GhiChu = string.Empty;
        }

        public string DonGiaFormat
        {
            get { return string.Format("{0:N0} đ", DonGia); }
        }

        public string ThanhTienFormat
        {
            get { return string.Format("{0:N0} đ", ThanhTien); }
        }
    }
}
