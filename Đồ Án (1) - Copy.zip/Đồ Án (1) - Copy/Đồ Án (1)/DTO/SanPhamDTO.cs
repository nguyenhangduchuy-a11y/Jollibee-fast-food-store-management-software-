﻿// DTO/SanPhamDTO.cs
using System;

namespace Đồ_Án__1_.DTO
{
    public class SanPhamDTO
    {
        public int IDSanPham { get; set; }
        public string MaSanPham { get; set; }
        public string TenSanPham { get; set; }
        public int? IDLoai { get; set; }
        public string TenLoai { get; set; }
        public decimal GiaBan { get; set; }
        public int SoLuongTon { get; set; }
        public int TonToiThieu { get; set; }
        public string DuongDanAnh { get; set; }
        public bool KichHoat { get; set; }
        public DateTime NgayTao { get; set; }

        public SanPhamDTO()
        {
            MaSanPham = string.Empty;
            TenSanPham = string.Empty;
            TenLoai = string.Empty;
            DuongDanAnh = string.Empty;
        }

        public string GiaBanFormat
        {
            get { return string.Format("{0:N0} đ", GiaBan); }
        }

        public string TrangThaiTon
        {
            get
            {
                if (SoLuongTon <= 0)
                    return "Hết hàng";

                if (SoLuongTon <= TonToiThieu)
                    return "Sắp hết";

                return "Còn hàng";
            }
        }

        public string TrangThaiHienThi
        {
            get { return KichHoat ? "Đang bán" : "Ngừng bán"; }
        }
    }
}
