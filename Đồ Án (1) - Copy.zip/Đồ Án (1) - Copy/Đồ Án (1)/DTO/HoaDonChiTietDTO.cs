﻿using System;

namespace Đồ_Án__1_.DTO
{
    public class HoaDonChiTietDTO
    {
        public string MaHoaDon { get; set; }
        public DateTime NgayLap { get; set; }
        public string TenLoaiDon { get; set; }
        public string PhuongThucThanhToan { get; set; }
        public decimal TongTien { get; set; }
        public string GhiChu { get; set; }
        public string TenNhanVien { get; set; }
        public int IDSanPham { get; set; }
        public string MaSanPham { get; set; }
        public string TenSanPham { get; set; }
        public int SoLuong { get; set; }
        public decimal DonGia { get; set; }
        public decimal ThanhTien { get; set; }
        public string GhiChuCT { get; set; }

        public string TongTienFormat
        {
            get { return string.Format("{0:N0} đ", TongTien); }
        }

        public string DonGiaFormat
        {
            get { return string.Format("{0:N0} đ", DonGia); }
        }

        public string ThanhTienFormat
        {
            get { return string.Format("{0:N0} đ", ThanhTien); }
        }

        public string NgayLapFormat
        {
            get { return NgayLap.ToString("dd/MM/yyyy HH:mm"); }
        }

        public HoaDonChiTietDTO()
        {
            MaHoaDon = "";
            TenLoaiDon = "";
            PhuongThucThanhToan = "";
            GhiChu = "";
            TenNhanVien = "";
            MaSanPham = "";
            TenSanPham = "";
            GhiChuCT = "";
        }
    }
}