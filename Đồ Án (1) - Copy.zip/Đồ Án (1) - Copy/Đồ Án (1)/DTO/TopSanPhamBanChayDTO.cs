﻿// DTO/TopSanPhamBanChayDTO.cs
namespace Đồ_Án__1_.DTO
{
    public class TopSanPhamBanChayDTO
    {
        public int IDSanPham { get; set; }
        public string MaSanPham { get; set; }
        public string TenSanPham { get; set; }
        public int SoLuongBan { get; set; }
        public decimal DoanhThu { get; set; }

        public TopSanPhamBanChayDTO()
        {
            MaSanPham = string.Empty;
            TenSanPham = string.Empty;
        }

        public string DoanhThuFormat
        {
            get { return string.Format("{0:N0} đ", DoanhThu); }
        }
    }
}
