﻿// DAL/LichSuHoatDongDAL.cs
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.DAL
{
    /// <summary>
    /// DAL cho bảng LichSuHoatDong - Xử lý truy xuất database
    /// </summary>
    public class LichSuHoatDongDAL
    {
        /// <summary>
        /// Thêm mới một bản ghi lịch sử hoạt động
        /// </summary>
        /// <param name="log">Đối tượng lịch sử cần thêm</param>
        /// <returns>ID của bản ghi vừa thêm (trả về 0 nếu thất bại)</returns>
        public int Them(LichSuHoatDongDTO log)
        {
            if (log == null)
                return 0;

            try
            {
                using (SqlConnection conn = DatabaseHelper.OpenConnection())
                using (SqlCommand cmd = new SqlCommand("sp_ThemLichSuHoatDong", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@NguoiThucHien", SqlDbType.NVarChar, 50).Value = log.NguoiThucHien ?? "HỆ THỐNG";
                    cmd.Parameters.Add("@IDNguoiDung", SqlDbType.Int).Value = DatabaseHelper.DbValue(log.IDNguoiDung);
                    cmd.Parameters.Add("@HanhDong", SqlDbType.NVarChar, 50).Value = log.HanhDong ?? string.Empty;
                    cmd.Parameters.Add("@DoiTuong", SqlDbType.NVarChar, 50).Value = log.DoiTuong ?? string.Empty;
                    cmd.Parameters.Add("@IDDoiTuong", SqlDbType.Int).Value = DatabaseHelper.DbValue(log.IDDoiTuong);
                    cmd.Parameters.Add("@ChiTiet", SqlDbType.NVarChar, 500).Value = DatabaseHelper.DbValue(log.ChiTiet);
                    cmd.Parameters.Add("@DiaChiIP", SqlDbType.NVarChar, 50).Value = DatabaseHelper.DbValue(log.DiaChiIP);
                    cmd.Parameters.Add("@ThietBi", SqlDbType.NVarChar, 200).Value = DatabaseHelper.DbValue(log.ThietBi);

                    object result = cmd.ExecuteScalar();
                    return result != null && result != DBNull.Value ? Convert.ToInt32(result) : 0;
                }
            }
            catch
            {
                // Không throw exception để tránh ảnh hưởng đến chức năng chính
                return 0;
            }
        }

        /// <summary>
        /// Lấy danh sách lịch sử hoạt động với các bộ lọc tùy chọn
        /// </summary>
        /// <param name="tuNgay">Từ ngày (NULL = không lọc)</param>
        /// <param name="denNgay">Đến ngày (NULL = không lọc)</param>
        /// <param name="hanhDong">Hành động cần lọc (NULL = tất cả)</param>
        /// <param name="nguoiThucHien">Người thực hiện (NULL = tất cả)</param>
        /// <param name="doiTuong">Đối tượng (NULL = tất cả)</param>
        /// <param name="top">Số lượng bản ghi tối đa (mặc định 1000)</param>
        /// <returns>Danh sách lịch sử hoạt động</returns>
        public List<LichSuHoatDongDTO> LayDanhSach(
            DateTime? tuNgay = null,
            DateTime? denNgay = null,
            string hanhDong = null,
            string nguoiThucHien = null,
            string doiTuong = null,
            int top = 1000)
        {
            List<LichSuHoatDongDTO> ds = new List<LichSuHoatDongDTO>();

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand("sp_LayLichSuHoatDong", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@TuNgay", SqlDbType.Date).Value = DatabaseHelper.DbValue(tuNgay?.Date);
                cmd.Parameters.Add("@DenNgay", SqlDbType.Date).Value = DatabaseHelper.DbValue(denNgay?.Date);
                cmd.Parameters.Add("@HanhDong", SqlDbType.NVarChar, 50).Value = DatabaseHelper.DbValue(hanhDong);
                cmd.Parameters.Add("@NguoiThucHien", SqlDbType.NVarChar, 50).Value = DatabaseHelper.DbValue(nguoiThucHien);
                cmd.Parameters.Add("@DoiTuong", SqlDbType.NVarChar, 50).Value = DatabaseHelper.DbValue(doiTuong);
                cmd.Parameters.Add("@Top", SqlDbType.Int).Value = top;

                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        ds.Add(MapLichSu(rd));
                    }
                }
            }
            return ds;
        }

        /// <summary>
        /// Lấy lịch sử hoạt động theo ID
        /// </summary>
        /// <param name="idLichSu">ID lịch sử cần tìm</param>
        /// <returns>Đối tượng lịch sử, null nếu không tồn tại</returns>
        public LichSuHoatDongDTO LayTheoID(int idLichSu)
        {
            const string sql = @"
                SELECT ls.*, ISNULL(nd.HoTen, ls.NguoiThucHien) AS TenNguoiDung
                FROM LichSuHoatDong ls
                LEFT JOIN NguoiDung nd ON ls.IDNguoiDung = nd.IDNguoiDung
                WHERE ls.IDLichSu = @IDLichSu";

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.Add("@IDLichSu", SqlDbType.Int).Value = idLichSu;

                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    if (rd.Read())
                        return MapLichSu(rd);
                    return null;
                }
            }
        }

        /// <summary>
        /// Lấy lịch sử hoạt động theo ID người dùng
        /// </summary>
        /// <param name="idNguoiDung">ID người dùng</param>
        /// <param name="top">Số lượng bản ghi tối đa</param>
        /// <returns>Danh sách lịch sử của người dùng</returns>
        public List<LichSuHoatDongDTO> LayTheoNguoiDung(int idNguoiDung, int top = 100)
        {
            return LayDanhSach(null, null, null, null, null, top)
                .FindAll(log => log.IDNguoiDung == idNguoiDung);
        }

        /// <summary>
        /// Lấy lịch sử hoạt động hôm nay
        /// </summary>
        /// <returns>Danh sách lịch sử hôm nay</returns>
        public List<LichSuHoatDongDTO> LayHomNay()
        {
            return LayDanhSach(DateTime.Today, DateTime.Today, null, null, null, 500);
        }

        /// <summary>
        /// Lấy lịch sử hoạt động theo hành động cụ thể
        /// </summary>
        /// <param name="hanhDong">Hành động cần lọc</param>
        /// <param name="tuNgay">Từ ngày (NULL = không lọc)</param>
        /// <param name="denNgay">Đến ngày (NULL = không lọc)</param>
        /// <returns>Danh sách lịch sử theo hành động</returns>
        public List<LichSuHoatDongDTO> LayTheoHanhDong(string hanhDong, DateTime? tuNgay = null, DateTime? denNgay = null)
        {
            return LayDanhSach(tuNgay, denNgay, hanhDong, null, null, 1000);
        }

        /// <summary>
        /// Lấy lịch sử hoạt động theo đối tượng cụ thể
        /// </summary>
        /// <param name="doiTuong">Đối tượng cần lọc</param>
        /// <param name="idDoiTuong">ID đối tượng (NULL = tất cả)</param>
        /// <param name="tuNgay">Từ ngày (NULL = không lọc)</param>
        /// <param name="denNgay">Đến ngày (NULL = không lọc)</param>
        /// <returns>Danh sách lịch sử theo đối tượng</returns>
        public List<LichSuHoatDongDTO> LayTheoDoiTuong(string doiTuong, int? idDoiTuong = null, DateTime? tuNgay = null, DateTime? denNgay = null)
        {
            var ds = LayDanhSach(tuNgay, denNgay, null, null, doiTuong, 1000);
            if (idDoiTuong.HasValue)
                ds = ds.FindAll(log => log.IDDoiTuong == idDoiTuong.Value);
            return ds;
        }

        /// <summary>
        /// Đếm tổng số bản ghi lịch sử
        /// </summary>
        /// <param name="tuNgay">Từ ngày (NULL = không lọc)</param>
        /// <param name="denNgay">Đến ngày (NULL = không lọc)</param>
        /// <returns>Số lượng bản ghi</returns>
        public int DemTongSo(DateTime? tuNgay = null, DateTime? denNgay = null)
        {
            string sql = "SELECT COUNT(*) FROM LichSuHoatDong WHERE 1=1";
            List<SqlParameter> parameters = new List<SqlParameter>();

            if (tuNgay.HasValue)
            {
                sql += " AND CAST(ThoiGian AS DATE) >= @TuNgay";
                parameters.Add(new SqlParameter("@TuNgay", SqlDbType.Date) { Value = tuNgay.Value.Date });
            }
            if (denNgay.HasValue)
            {
                sql += " AND CAST(ThoiGian AS DATE) <= @DenNgay";
                parameters.Add(new SqlParameter("@DenNgay", SqlDbType.Date) { Value = denNgay.Value.Date });
            }

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                foreach (var param in parameters)
                    cmd.Parameters.Add(param);

                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        /// <summary>
        /// Đếm số lượng lịch sử hôm nay
        /// </summary>
        /// <returns>Số lượng bản ghi hôm nay</returns>
        public int DemHomNay()
        {
            return DemTongSo(DateTime.Today, DateTime.Today);
        }

        /// <summary>
        /// Xóa lịch sử cũ (quá số ngày chỉ định)
        /// </summary>
        /// <param name="soNgayToiThieu">Giữ lại lịch sử trong vòng bao nhiêu ngày</param>
        /// <returns>Số bản ghi đã xóa</returns>
        public int XoaLichSuCu(int soNgayToiThieu = 90)
        {
            string sql = "DELETE FROM LichSuHoatDong WHERE ThoiGian < DATEADD(day, -@SoNgay, GETDATE())";

            return DatabaseHelper.ExecuteNonQuery(
                sql,
                new SqlParameter("@SoNgay", SqlDbType.Int) { Value = soNgayToiThieu }
            );
        }

        /// <summary>
        /// Xóa toàn bộ lịch sử (chỉ dùng cho admin)
        /// </summary>
        /// <returns>Số bản ghi đã xóa</returns>
        public int XoaToanBo()
        {
            const string sql = "DELETE FROM LichSuHoatDong";
            return DatabaseHelper.ExecuteNonQuery(sql);
        }

        /// <summary>
        /// Map dữ liệu từ SqlDataReader sang DTO
        /// </summary>
        private LichSuHoatDongDTO MapLichSu(SqlDataReader rd)
        {
            return new LichSuHoatDongDTO
            {
                IDLichSu = Convert.ToInt32(rd["IDLichSu"]),
                NguoiThucHien = rd["NguoiThucHien"]?.ToString() ?? string.Empty,
                IDNguoiDung = rd["IDNguoiDung"] == DBNull.Value ? (int?)null : Convert.ToInt32(rd["IDNguoiDung"]),
                TenNguoiDung = rd["TenNguoiDung"] == DBNull.Value ? (rd["NguoiThucHien"]?.ToString() ?? string.Empty) : rd["TenNguoiDung"].ToString(),
                ThoiGian = Convert.ToDateTime(rd["ThoiGian"]),
                ThoiGianText = rd["ThoiGianText"]?.ToString() ?? Convert.ToDateTime(rd["ThoiGian"]).ToString("dd/MM/yyyy HH:mm:ss"),
                HanhDong = rd["HanhDong"]?.ToString() ?? string.Empty,
                DoiTuong = rd["DoiTuong"]?.ToString() ?? string.Empty,
                IDDoiTuong = rd["IDDoiTuong"] == DBNull.Value ? (int?)null : Convert.ToInt32(rd["IDDoiTuong"]),
                ChiTiet = rd["ChiTiet"] == DBNull.Value ? string.Empty : rd["ChiTiet"].ToString(),
                DiaChiIP = rd["DiaChiIP"] == DBNull.Value ? string.Empty : rd["DiaChiIP"].ToString(),
                ThietBi = rd["ThietBi"] == DBNull.Value ? string.Empty : rd["ThietBi"].ToString()
            };
        }
    }
}