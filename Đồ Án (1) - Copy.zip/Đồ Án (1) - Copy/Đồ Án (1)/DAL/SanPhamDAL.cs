﻿// DAL/SanPhamDAL.cs
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.DAL
{
    public class SanPhamDAL
    {
        public List<SanPhamDTO> LayDanhSachSanPham(bool chiLayDangBan = true)
        {
            const string sql = @"
                SELECT sp.*, lsp.TenLoai
                FROM SanPham sp
                LEFT JOIN LoaiSanPham lsp ON sp.IDLoai = lsp.IDLoai
                WHERE (@ChiLayDangBan = 0 OR (sp.KichHoat = 1 AND sp.SoLuongTon > 0))
                ORDER BY sp.IDSanPham DESC";

            List<SanPhamDTO> ds = new List<SanPhamDTO>();

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.Add("@ChiLayDangBan", SqlDbType.Bit).Value = chiLayDangBan;

                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        ds.Add(MapSanPham(rd));
                    }
                }
            }

            return ds;
        }

        public List<SanPhamDTO> TimKiem(string tuKhoa)
        {
            const string sql = @"
                SELECT sp.*, lsp.TenLoai
                FROM SanPham sp
                LEFT JOIN LoaiSanPham lsp ON sp.IDLoai = lsp.IDLoai
                WHERE sp.KichHoat = 1
                  AND (sp.MaSanPham LIKE @TuKhoa OR sp.TenSanPham LIKE @TuKhoa)
                ORDER BY sp.TenSanPham";

            List<SanPhamDTO> ds = new List<SanPhamDTO>();

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.Add("@TuKhoa", SqlDbType.NVarChar, 100).Value = "%" + tuKhoa + "%";

                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        ds.Add(MapSanPham(rd));
                    }
                }
            }

            return ds;
        }

        public SanPhamDTO LayTheoID(int idSanPham)
        {
            const string sql = @"
                SELECT sp.*, lsp.TenLoai
                FROM SanPham sp
                LEFT JOIN LoaiSanPham lsp ON sp.IDLoai = lsp.IDLoai
                WHERE sp.IDSanPham = @IDSanPham";

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.Add("@IDSanPham", SqlDbType.Int).Value = idSanPham;

                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    if (rd.Read())
                        return MapSanPham(rd);

                    return null;
                }
            }
        }

        public bool TonTaiSanPham(int idSanPham)
        {
            const string sql = "SELECT COUNT(*) FROM SanPham WHERE IDSanPham = @IDSanPham";

            return DatabaseHelper.Exists(
                sql,
                new SqlParameter("@IDSanPham", SqlDbType.Int) { Value = idSanPham }
            );
        }

        public bool TonTaiMaSanPham(string maSanPham, int? boQuaID = null)
        {
            const string sql = @"
                SELECT COUNT(*)
                FROM SanPham
                WHERE MaSanPham = @MaSanPham
                  AND (@BoQuaID IS NULL OR IDSanPham <> @BoQuaID)";

            return DatabaseHelper.Exists(
                sql,
                new SqlParameter("@MaSanPham", SqlDbType.NVarChar, 20) { Value = maSanPham },
                new SqlParameter("@BoQuaID", SqlDbType.Int) { Value = DatabaseHelper.DbValue(boQuaID) }
            );
        }

        public bool Them(SanPhamDTO sp)
        {
            const string sql = @"
                INSERT INTO SanPham
                (MaSanPham, TenSanPham, IDLoai, GiaBan, SoLuongTon, TonToiThieu, DuongDanAnh, KichHoat)
                VALUES
                (@MaSanPham, @TenSanPham, @IDLoai, @GiaBan, @SoLuongTon, @TonToiThieu, @DuongDanAnh, @KichHoat)";

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                AddSanPhamParams(cmd, sp, false);
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool Sua(SanPhamDTO sp)
        {
            const string sql = @"
                UPDATE SanPham
                SET MaSanPham = @MaSanPham,
                    TenSanPham = @TenSanPham,
                    IDLoai = @IDLoai,
                    GiaBan = @GiaBan,
                    SoLuongTon = @SoLuongTon,
                    TonToiThieu = @TonToiThieu,
                    DuongDanAnh = @DuongDanAnh,
                    KichHoat = @KichHoat
                WHERE IDSanPham = @IDSanPham";

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                AddSanPhamParams(cmd, sp, true);
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public bool Xoa(int idSanPham)
        {
            const string sql = "UPDATE SanPham SET KichHoat = 0 WHERE IDSanPham = @IDSanPham";

            return DatabaseHelper.ExecuteNonQuery(
                sql,
                new SqlParameter("@IDSanPham", SqlDbType.Int) { Value = idSanPham }
            ) > 0;
        }

        public bool NhapKho(int idSanPham, int soLuongNhap)
        {
            const string sql = @"
                UPDATE SanPham
                SET SoLuongTon = SoLuongTon + @SoLuongNhap
                WHERE IDSanPham = @IDSanPham
                  AND KichHoat = 1";

            return DatabaseHelper.ExecuteNonQuery(
                sql,
                new SqlParameter("@IDSanPham", SqlDbType.Int) { Value = idSanPham },
                new SqlParameter("@SoLuongNhap", SqlDbType.Int) { Value = soLuongNhap }
            ) > 0;
        }

        public List<CanhBaoTonKhoDTO> CanhBaoTonKho()
        {
            const string sql = @"
                SELECT IDSanPham, MaSanPham, TenSanPham, SoLuongTon, TonToiThieu,
                       CASE
                           WHEN SoLuongTon <= 0 THEN N'HẾT HÀNG'
                           WHEN SoLuongTon <= TonToiThieu THEN N'SẮP HẾT'
                           ELSE N'BÌNH THƯỜNG'
                       END AS TrangThai
                FROM SanPham
                WHERE KichHoat = 1 AND SoLuongTon <= TonToiThieu
                ORDER BY SoLuongTon ASC";

            List<CanhBaoTonKhoDTO> ds = new List<CanhBaoTonKhoDTO>();

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            using (SqlDataReader rd = cmd.ExecuteReader())
            {
                while (rd.Read())
                {
                    ds.Add(new CanhBaoTonKhoDTO
                    {
                        IDSanPham = Convert.ToInt32(rd["IDSanPham"]),
                        MaSanPham = rd["MaSanPham"].ToString(),
                        TenSanPham = rd["TenSanPham"].ToString(),
                        SoLuongTon = Convert.ToInt32(rd["SoLuongTon"]),
                        TonToiThieu = Convert.ToInt32(rd["TonToiThieu"]),
                        TrangThai = rd["TrangThai"].ToString()
                    });
                }
            }

            return ds;
        }

        private void AddSanPhamParams(SqlCommand cmd, SanPhamDTO sp, bool includeId)
        {
            if (includeId)
                cmd.Parameters.Add("@IDSanPham", SqlDbType.Int).Value = sp.IDSanPham;

            cmd.Parameters.Add("@MaSanPham", SqlDbType.NVarChar, 20).Value = sp.MaSanPham;
            cmd.Parameters.Add("@TenSanPham", SqlDbType.NVarChar, 100).Value = sp.TenSanPham;
            cmd.Parameters.Add("@IDLoai", SqlDbType.Int).Value = DatabaseHelper.DbValue(sp.IDLoai);
            cmd.Parameters.Add("@GiaBan", SqlDbType.Decimal).Value = sp.GiaBan;
            cmd.Parameters.Add("@SoLuongTon", SqlDbType.Int).Value = sp.SoLuongTon;
            cmd.Parameters.Add("@TonToiThieu", SqlDbType.Int).Value = sp.TonToiThieu;
            cmd.Parameters.Add("@DuongDanAnh", SqlDbType.NVarChar, 255).Value = DatabaseHelper.DbValue(sp.DuongDanAnh);
            cmd.Parameters.Add("@KichHoat", SqlDbType.Bit).Value = sp.KichHoat;
        }

        private SanPhamDTO MapSanPham(SqlDataReader rd)
        {
            return new SanPhamDTO
            {
                IDSanPham = Convert.ToInt32(rd["IDSanPham"]),
                MaSanPham = rd["MaSanPham"].ToString(),
                TenSanPham = rd["TenSanPham"].ToString(),
                IDLoai = rd["IDLoai"] == DBNull.Value ? (int?)null : Convert.ToInt32(rd["IDLoai"]),
                TenLoai = rd["TenLoai"] == DBNull.Value ? string.Empty : rd["TenLoai"].ToString(),
                GiaBan = Convert.ToDecimal(rd["GiaBan"]),
                SoLuongTon = Convert.ToInt32(rd["SoLuongTon"]),
                TonToiThieu = Convert.ToInt32(rd["TonToiThieu"]),
                DuongDanAnh = rd["DuongDanAnh"] == DBNull.Value ? string.Empty : rd["DuongDanAnh"].ToString(),
                KichHoat = Convert.ToBoolean(rd["KichHoat"]),
                NgayTao = rd["NgayTao"] == DBNull.Value ? DateTime.MinValue : Convert.ToDateTime(rd["NgayTao"])
            };
        }
    }
}
