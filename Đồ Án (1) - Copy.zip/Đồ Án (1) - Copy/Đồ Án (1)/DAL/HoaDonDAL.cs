﻿// DAL/HoaDonDAL.cs
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.DAL
{
    public class HoaDonDAL
    {
        // =====================================================
        // CÁC PHƯƠNG THỨC HIỆN CÓ (GIỮ NGUYÊN)
        // =====================================================

        public int TaoHoaDon(HoaDonDTO hoaDon, List<ChiTietHoaDonDTO> chiTietList, out string maHoaDon)
        {
            maHoaDon = "HD" + DateTime.Now.ToString("yyyyMMddHHmmss");

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                using (SqlTransaction tran = conn.BeginTransaction(IsolationLevel.ReadCommitted))
                {
                    try
                    {
                        int idHoaDon = InsertHoaDon(conn, tran, hoaDon, maHoaDon);
                        decimal tongTien = 0;

                        foreach (ChiTietHoaDonDTO ct in chiTietList)
                        {
                            SanPhamDTO sp = LaySanPhamCoKhoa(conn, tran, ct.IDSanPham);

                            if (sp.SoLuongTon < ct.SoLuong)
                                throw new Exception(string.Format("Sản phẩm '{0}' không đủ hàng. Còn {1}.", sp.TenSanPham, sp.SoLuongTon));

                            decimal thanhTien = sp.GiaBan * ct.SoLuong;
                            tongTien += thanhTien;

                            InsertChiTiet(conn, tran, idHoaDon, ct, sp.GiaBan, thanhTien);
                            TruTonKho(conn, tran, ct.IDSanPham, ct.SoLuong);
                        }

                        CapNhatTongTien(conn, tran, idHoaDon, tongTien);

                        if (hoaDon.LoaiDon == 1 && hoaDon.IDBan.HasValue)
                        {
                            BanAnDTO ban = LayBan(conn, tran, hoaDon.IDBan.Value);
                            if (ban.TrangThai == 0)
                            {
                                CapNhatTrangThaiBan(conn, tran, hoaDon.IDBan.Value, 1);
                            }
                        }

                        tran.Commit();
                        return idHoaDon;
                    }
                    catch
                    {
                        tran.Rollback();
                        throw;
                    }
                }
            }
        }

        public bool HoanTatThanhToan(int idHoaDon, string phuongThucThanhToan)
        {
            const string sql = @"
                UPDATE HoaDon
                SET PhuongThucThanhToan = @PhuongThucThanhToan,
                    TrangThai = 1,
                    TrangThaiDon = 2
                WHERE IDHoaDon = @IDHoaDon
                  AND TrangThai = 0;";

            return DatabaseHelper.ExecuteNonQuery(
                sql,
                new SqlParameter("@IDHoaDon", SqlDbType.Int) { Value = idHoaDon },
                new SqlParameter("@PhuongThucThanhToan", SqlDbType.NVarChar, 50) { Value = phuongThucThanhToan }
            ) > 0;
        }

        // =====================================================
        // PHƯƠNG THỨC MỚI CHO ĐẶT HÀNG CỦA KHÁCH
        // =====================================================

        /// <summary>
        /// Tạo đơn hàng chờ (khách hàng order - KHÔNG trừ tồn kho)
        /// </summary>
        public int TaoDonHangCho(HoaDonDTO hoaDon, out string maHoaDon)
        {
            maHoaDon = "OD" + DateTime.Now.ToString("yyyyMMddHHmmss");
            int idHoaDon = 0;

            string sql = @"
                INSERT INTO HoaDon (MaHoaDon, IDKhachHang, IDNhanVien, NgayLap, TongTien, LoaiDon, IDBan, PhuongThucThanhToan, TrangThai, TrangThaiDon)
                VALUES (@MaHoaDon, @IDKhachHang, NULL, GETDATE(), 0, @LoaiDon, NULL, @PhuongThucThanhToan, 0, 0);
                SELECT SCOPE_IDENTITY();";

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@MaHoaDon", maHoaDon);
                    cmd.Parameters.AddWithValue("@IDKhachHang", hoaDon.IDKhachHang);
                    cmd.Parameters.AddWithValue("@LoaiDon", hoaDon.LoaiDon);
                    cmd.Parameters.AddWithValue("@PhuongThucThanhToan", hoaDon.PhuongThucThanhToan);

                    object result = cmd.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        idHoaDon = Convert.ToInt32(result);
                    }
                }
                conn.Close();
            }

            return idHoaDon;
        }

        /// <summary>
        /// Thêm chi tiết vào đơn hàng chờ
        /// </summary>
        public decimal ThemChiTietDonCho(int idHoaDon, ChiTietHoaDonDTO chiTiet)
        {
            string sql = @"
                DECLARE @DonGia DECIMAL(18,2);
                DECLARE @ThanhTien DECIMAL(18,2);
                
                SELECT @DonGia = GiaBan FROM SanPham WHERE IDSanPham = @IDSanPham;
                SET @ThanhTien = @DonGia * @SoLuong;
                
                INSERT INTO ChiTietHoaDon (IDHoaDon, IDSanPham, SoLuong, DonGia, ThanhTien, GhiChu)
                VALUES (@IDHoaDon, @IDSanPham, @SoLuong, @DonGia, @ThanhTien, @GhiChu);
                
                UPDATE HoaDon 
                SET TongTien = (SELECT SUM(ThanhTien) FROM ChiTietHoaDon WHERE IDHoaDon = @IDHoaDon)
                WHERE IDHoaDon = @IDHoaDon;
                
                SELECT @ThanhTien;";

            decimal result = 0;
            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@IDHoaDon", idHoaDon);
                    cmd.Parameters.AddWithValue("@IDSanPham", chiTiet.IDSanPham);
                    cmd.Parameters.AddWithValue("@SoLuong", chiTiet.SoLuong);
                    cmd.Parameters.AddWithValue("@GhiChu", DatabaseHelper.DbValue(chiTiet.GhiChu));

                    object obj = cmd.ExecuteScalar();
                    if (obj != null && obj != DBNull.Value)
                    {
                        result = Convert.ToDecimal(obj);
                    }
                }
                conn.Close();
            }

            return result;
        }

        /// <summary>
        /// Lấy danh sách đơn hàng chờ xác nhận
        /// </summary>
        public List<HoaDonDTO> LayDonChoXacNhan()
        {
            List<HoaDonDTO> ds = new List<HoaDonDTO>();

            string sql = @"
                SELECT 
                    hd.IDHoaDon,
                    hd.MaHoaDon,
                    hd.NgayLap,
                    hd.TongTien,
                    ISNULL(kh.HoTen, N'Khách vãng lai') AS TenKhachHang,
                    (SELECT COUNT(*) FROM ChiTietHoaDon WHERE IDHoaDon = hd.IDHoaDon) AS SoLuongMon
                FROM HoaDon hd
                LEFT JOIN NguoiDung kh ON hd.IDKhachHang = kh.IDNguoiDung
                WHERE hd.LoaiDon = 3 
                  AND hd.TrangThaiDon = 0
                  AND hd.TrangThai = 0
                ORDER BY hd.NgayLap ASC";

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        while (rd.Read())
                        {
                            HoaDonDTO hd = new HoaDonDTO();
                            hd.IDHoaDon = Convert.ToInt32(rd["IDHoaDon"]);
                            hd.MaHoaDon = rd["MaHoaDon"].ToString();
                            hd.NgayLap = Convert.ToDateTime(rd["NgayLap"]);
                            hd.TongTien = Convert.ToDecimal(rd["TongTien"]);
                            hd.TenKhachHang = rd["TenKhachHang"].ToString();

                            if (rd["SoLuongMon"] != DBNull.Value)
                            {
                                hd.SoLuongMon = Convert.ToInt32(rd["SoLuongMon"]);
                            }

                            ds.Add(hd);
                        }
                    }
                }
                conn.Close();
            }

            return ds;
        }

        /// <summary>
        /// Xác nhận đơn hàng (nhân viên duyệt - trừ tồn kho)
        /// KHÔNG cập nhật IDNhanVien để tránh vi phạm CHECK constraint
        /// </summary>
        public bool XacNhanDonHang(int idHoaDon, string ghiChu)
        {
            string sql = @"
                UPDATE HoaDon 
                SET TrangThaiDon = 1,
                    GhiChuNhanVien = @GhiChu
                WHERE IDHoaDon = @IDHoaDon
                  AND LoaiDon = 3 
                  AND TrangThaiDon = 0;
                
                UPDATE sp
                SET sp.SoLuongTon = sp.SoLuongTon - ct.SoLuong
                FROM SanPham sp
                INNER JOIN ChiTietHoaDon ct ON sp.IDSanPham = ct.IDSanPham
                WHERE ct.IDHoaDon = @IDHoaDon;";

            int rowsAffected = 0;
            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@IDHoaDon", idHoaDon);
                    cmd.Parameters.AddWithValue("@GhiChu", DatabaseHelper.DbValue(ghiChu));

                    rowsAffected = cmd.ExecuteNonQuery();
                }
                conn.Close();
            }

            return rowsAffected > 0;
        }

        /// <summary>
        /// Từ chối/Hủy đơn hàng
        /// </summary>
        public bool TuChoiDonHang(int idHoaDon, string lyDo)
        {
            string sql = @"
                UPDATE HoaDon 
                SET TrangThaiDon = 3,
                    GhiChuNhanVien = @LyDo
                WHERE IDHoaDon = @IDHoaDon
                  AND LoaiDon = 3 
                  AND TrangThaiDon = 0;";

            int rowsAffected = 0;
            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@IDHoaDon", idHoaDon);
                    cmd.Parameters.AddWithValue("@LyDo", lyDo);

                    rowsAffected = cmd.ExecuteNonQuery();
                }
                conn.Close();
            }

            return rowsAffected > 0;
        }

        /// <summary>
        /// Lấy lịch sử đơn hàng của khách
        /// </summary>
        public DataTable LayLichSuDonHangKhachHang(int idKhachHang, DateTime? tuNgay = null, DateTime? denNgay = null)
        {
            DataTable dt = new DataTable();

            string sql = @"
                SELECT 
                    hd.IDHoaDon,
                    hd.MaHoaDon,
                    hd.NgayLap,
                    FORMAT(hd.NgayLap, 'dd/MM/yyyy HH:mm') AS NgayLapText,
                    hd.TongTien,
                    FORMAT(hd.TongTien, 'N0') AS TongTienFormat,
                    CASE hd.LoaiDon
                        WHEN 1 THEN N'Ăn tại bàn'
                        WHEN 2 THEN N'Mang về'
                        WHEN 3 THEN N'Tự order'
                    END AS LoaiDonText,
                    CASE hd.TrangThaiDon
                        WHEN 0 THEN N'Chờ xác nhận'
                        WHEN 1 THEN N'Đã xác nhận'
                        WHEN 2 THEN N'Đã thanh toán'
                        WHEN 3 THEN N'Đã hủy'
                    END AS TrangThaiDonText,
                    ISNULL(nv.HoTen, N'Chưa có NV') AS TenNhanVien,
                    (SELECT COUNT(*) FROM ChiTietHoaDon WHERE IDHoaDon = hd.IDHoaDon) AS SoLuongMon
                FROM HoaDon hd
                LEFT JOIN NguoiDung nv ON hd.IDNhanVien = nv.IDNguoiDung
                WHERE hd.IDKhachHang = @IDKhachHang
                  AND (@TuNgay IS NULL OR CAST(hd.NgayLap AS DATE) >= @TuNgay)
                  AND (@DenNgay IS NULL OR CAST(hd.NgayLap AS DATE) <= @DenNgay)
                ORDER BY hd.NgayLap DESC";

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    cmd.Parameters.AddWithValue("@IDKhachHang", idKhachHang);
                    cmd.Parameters.AddWithValue("@TuNgay", DatabaseHelper.DbValue(tuNgay?.Date));
                    cmd.Parameters.AddWithValue("@DenNgay", DatabaseHelper.DbValue(denNgay?.Date));

                    da.Fill(dt);
                }
                conn.Close();
            }

            return dt;
        }

        /// <summary>
        /// Đếm số đơn hàng chờ xác nhận
        /// </summary>
        public int DemDonChoXacNhan()
        {
            const string sql = "SELECT COUNT(*) FROM HoaDon WHERE LoaiDon = 3 AND TrangThaiDon = 0 AND TrangThai = 0";
            int count = 0;

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    count = Convert.ToInt32(cmd.ExecuteScalar());
                }
                conn.Close();
            }

            return count;
        }

        // =====================================================
        // CÁC PHƯƠNG THỨC PRIVATE HIỆN CÓ (GIỮ NGUYÊN)
        // =====================================================

        private int InsertHoaDon(SqlConnection conn, SqlTransaction tran, HoaDonDTO hd, string maHoaDon)
        {
            const string sql = @"
                INSERT INTO HoaDon
                (MaHoaDon, IDKhachHang, IDNhanVien, NgayLap, TongTien, LoaiDon, IDBan, PhuongThucThanhToan, TrangThai, TrangThaiDon, GhiChu)
                OUTPUT INSERTED.IDHoaDon
                VALUES
                (@MaHoaDon, @IDKhachHang, @IDNhanVien, GETDATE(), 0, @LoaiDon, @IDBan, @PhuongThucThanhToan, 0, 
                CASE WHEN @LoaiDon = 3 THEN 0 ELSE 1 END, @GhiChu)";

            using (SqlCommand cmd = new SqlCommand(sql, conn, tran))
            {
                cmd.Parameters.Add("@MaHoaDon", SqlDbType.NVarChar, 20).Value = maHoaDon;
                cmd.Parameters.Add("@IDKhachHang", SqlDbType.Int).Value = DatabaseHelper.DbValue(hd.IDKhachHang);
                cmd.Parameters.Add("@IDNhanVien", SqlDbType.Int).Value = DatabaseHelper.DbValue(hd.IDNhanVien);
                cmd.Parameters.Add("@LoaiDon", SqlDbType.Int).Value = hd.LoaiDon;
                cmd.Parameters.Add("@IDBan", SqlDbType.Int).Value = DatabaseHelper.DbValue(hd.IDBan);
                cmd.Parameters.Add("@PhuongThucThanhToan", SqlDbType.NVarChar, 50).Value = hd.PhuongThucThanhToan;
                cmd.Parameters.Add("@GhiChu", SqlDbType.NVarChar, 500).Value = DatabaseHelper.DbValue(hd.GhiChu);
                return Convert.ToInt32(cmd.ExecuteScalar());
            }
        }

        private BanAnDTO LayBan(SqlConnection conn, SqlTransaction tran, int idBan)
        {
            const string sql = "SELECT IDBan, TenBan, TrangThai FROM BanAn WHERE IDBan = @IDBan";

            using (SqlCommand cmd = new SqlCommand(sql, conn, tran))
            {
                cmd.Parameters.Add("@IDBan", SqlDbType.Int).Value = idBan;
                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    if (rd.Read())
                    {
                        return new BanAnDTO
                        {
                            IDBan = Convert.ToInt32(rd["IDBan"]),
                            TenBan = rd["TenBan"].ToString(),
                            TrangThai = Convert.ToInt32(rd["TrangThai"])
                        };
                    }
                    return null;
                }
            }
        }

        private SanPhamDTO LaySanPhamCoKhoa(SqlConnection conn, SqlTransaction tran, int idSanPham)
        {
            const string sql = @"
                SELECT IDSanPham, TenSanPham, GiaBan, SoLuongTon
                FROM SanPham WITH (UPDLOCK, ROWLOCK)
                WHERE IDSanPham = @IDSanPham AND KichHoat = 1";

            using (SqlCommand cmd = new SqlCommand(sql, conn, tran))
            {
                cmd.Parameters.Add("@IDSanPham", SqlDbType.Int).Value = idSanPham;
                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    if (!rd.Read())
                        throw new Exception("Sản phẩm không tồn tại hoặc đã ngừng bán.");
                    return new SanPhamDTO
                    {
                        IDSanPham = Convert.ToInt32(rd["IDSanPham"]),
                        TenSanPham = rd["TenSanPham"].ToString(),
                        GiaBan = Convert.ToDecimal(rd["GiaBan"]),
                        SoLuongTon = Convert.ToInt32(rd["SoLuongTon"])
                    };
                }
            }
        }

        private void InsertChiTiet(SqlConnection conn, SqlTransaction tran, int idHoaDon, ChiTietHoaDonDTO ct, decimal donGia, decimal thanhTien)
        {
            const string sql = @"
                INSERT INTO ChiTietHoaDon
                (IDHoaDon, IDSanPham, SoLuong, DonGia, ThanhTien, GhiChu)
                VALUES
                (@IDHoaDon, @IDSanPham, @SoLuong, @DonGia, @ThanhTien, @GhiChu)";

            using (SqlCommand cmd = new SqlCommand(sql, conn, tran))
            {
                cmd.Parameters.Add("@IDHoaDon", SqlDbType.Int).Value = idHoaDon;
                cmd.Parameters.Add("@IDSanPham", SqlDbType.Int).Value = ct.IDSanPham;
                cmd.Parameters.Add("@SoLuong", SqlDbType.Int).Value = ct.SoLuong;
                cmd.Parameters.Add("@DonGia", SqlDbType.Decimal).Value = donGia;
                cmd.Parameters.Add("@ThanhTien", SqlDbType.Decimal).Value = thanhTien;
                cmd.Parameters.Add("@GhiChu", SqlDbType.NVarChar, 200).Value = DatabaseHelper.DbValue(ct.GhiChu);
                cmd.ExecuteNonQuery();
            }
        }

        private void TruTonKho(SqlConnection conn, SqlTransaction tran, int idSanPham, int soLuong)
        {
            const string sql = "UPDATE SanPham SET SoLuongTon = SoLuongTon - @SoLuong WHERE IDSanPham = @IDSanPham";
            using (SqlCommand cmd = new SqlCommand(sql, conn, tran))
            {
                cmd.Parameters.Add("@IDSanPham", SqlDbType.Int).Value = idSanPham;
                cmd.Parameters.Add("@SoLuong", SqlDbType.Int).Value = soLuong;
                cmd.ExecuteNonQuery();
            }
        }

        private void CapNhatTongTien(SqlConnection conn, SqlTransaction tran, int idHoaDon, decimal tongTien)
        {
            const string sql = "UPDATE HoaDon SET TongTien = @TongTien WHERE IDHoaDon = @IDHoaDon";
            using (SqlCommand cmd = new SqlCommand(sql, conn, tran))
            {
                cmd.Parameters.Add("@IDHoaDon", SqlDbType.Int).Value = idHoaDon;
                cmd.Parameters.Add("@TongTien", SqlDbType.Decimal).Value = tongTien;
                cmd.ExecuteNonQuery();
            }
        }

        private void CapNhatTrangThaiBan(SqlConnection conn, SqlTransaction tran, int idBan, int trangThai)
        {
            const string sql = "UPDATE BanAn SET TrangThai = @TrangThai WHERE IDBan = @IDBan";
            using (SqlCommand cmd = new SqlCommand(sql, conn, tran))
            {
                cmd.Parameters.Add("@IDBan", SqlDbType.Int).Value = idBan;
                cmd.Parameters.Add("@TrangThai", SqlDbType.Int).Value = trangThai;
                cmd.ExecuteNonQuery();
            }
        }

        public List<HoaDonDTO> LayTatCa()
        {
            const string sql = @"
                SELECT hd.*, nv.HoTen AS TenNhanVien, kh.HoTen AS TenKhachHang, b.TenBan
                FROM HoaDon hd
                LEFT JOIN NguoiDung nv ON hd.IDNhanVien = nv.IDNguoiDung
                LEFT JOIN NguoiDung kh ON hd.IDKhachHang = kh.IDNguoiDung
                LEFT JOIN BanAn b ON hd.IDBan = b.IDBan
                ORDER BY hd.NgayLap DESC";
            return ExecuteHoaDonList(sql);
        }

        public List<HoaDonDTO> LayTheoNgay(DateTime tuNgay, DateTime denNgay)
        {
            const string sql = @"
                SELECT hd.*, nv.HoTen AS TenNhanVien, kh.HoTen AS TenKhachHang, b.TenBan
                FROM HoaDon hd
                LEFT JOIN NguoiDung nv ON hd.IDNhanVien = nv.IDNguoiDung
                LEFT JOIN NguoiDung kh ON hd.IDKhachHang = kh.IDNguoiDung
                LEFT JOIN BanAn b ON hd.IDBan = b.IDBan
                WHERE hd.NgayLap >= @TuNgay AND hd.NgayLap < @DenNgay
                ORDER BY hd.NgayLap DESC";

            List<HoaDonDTO> ds = new List<HoaDonDTO>();
            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.Add("@TuNgay", SqlDbType.DateTime).Value = tuNgay.Date;
                    cmd.Parameters.Add("@DenNgay", SqlDbType.DateTime).Value = denNgay.Date.AddDays(1);
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        while (rd.Read())
                            ds.Add(MapHoaDon(rd));
                    }
                }
                conn.Close();
            }
            return ds;
        }

        public HoaDonDTO LayTheoID(int idHoaDon)
        {
            const string sql = @"
                SELECT hd.*, nv.HoTen AS TenNhanVien, kh.HoTen AS TenKhachHang, b.TenBan
                FROM HoaDon hd
                LEFT JOIN NguoiDung nv ON hd.IDNhanVien = nv.IDNguoiDung
                LEFT JOIN NguoiDung kh ON hd.IDKhachHang = kh.IDNguoiDung
                LEFT JOIN BanAn b ON hd.IDBan = b.IDBan
                WHERE hd.IDHoaDon = @IDHoaDon";

            HoaDonDTO result = null;
            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.Add("@IDHoaDon", SqlDbType.Int).Value = idHoaDon;
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        if (rd.Read())
                            result = MapHoaDon(rd);
                    }
                }
                conn.Close();
            }
            return result;
        }

        public List<HoaDonChiTietDTO> LayChiTietHoaDon(int idHoaDon)
        {
            List<HoaDonChiTietDTO> ds = new List<HoaDonChiTietDTO>();

            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("sp_ChiTietHoaDon", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@IDHoaDon", SqlDbType.Int).Value = idHoaDon;

                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        while (rd.Read())
                        {
                            HoaDonChiTietDTO ct = new HoaDonChiTietDTO();
                            ct.MaHoaDon = rd["MaHoaDon"].ToString();
                            ct.NgayLap = Convert.ToDateTime(rd["NgayLap"]);
                            ct.TenLoaiDon = rd["TenLoaiDon"].ToString();
                            ct.PhuongThucThanhToan = rd["PhuongThucThanhToan"].ToString();
                            ct.TongTien = Convert.ToDecimal(rd["TongTien"]);
                            ct.GhiChu = rd["GhiChu"] == DBNull.Value ? "" : rd["GhiChu"].ToString();
                            ct.TenNhanVien = rd["TenNhanVien"].ToString();
                            ct.IDSanPham = rd["IDSanPham"] == DBNull.Value ? 0 : Convert.ToInt32(rd["IDSanPham"]);
                            ct.MaSanPham = rd["MaSanPham"] == DBNull.Value ? "" : rd["MaSanPham"].ToString();
                            ct.TenSanPham = rd["TenSanPham"] == DBNull.Value ? "" : rd["TenSanPham"].ToString();
                            ct.SoLuong = rd["SoLuong"] == DBNull.Value ? 0 : Convert.ToInt32(rd["SoLuong"]);
                            ct.DonGia = rd["DonGia"] == DBNull.Value ? 0 : Convert.ToDecimal(rd["DonGia"]);
                            ct.ThanhTien = rd["ThanhTien"] == DBNull.Value ? 0 : Convert.ToDecimal(rd["ThanhTien"]);
                            ct.GhiChuCT = rd["GhiChuCT"] == DBNull.Value ? "" : rd["GhiChuCT"].ToString();
                            ds.Add(ct);
                        }
                    }
                }
                conn.Close();
            }
            return ds;
        }

        private List<HoaDonDTO> ExecuteHoaDonList(string sql)
        {
            List<HoaDonDTO> ds = new List<HoaDonDTO>();
            using (SqlConnection conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                        ds.Add(MapHoaDon(rd));
                }
                conn.Close();
            }
            return ds;
        }

        private HoaDonDTO MapHoaDon(SqlDataReader rd)
        {
            return new HoaDonDTO
            {
                IDHoaDon = Convert.ToInt32(rd["IDHoaDon"]),
                MaHoaDon = rd["MaHoaDon"].ToString(),
                IDKhachHang = rd["IDKhachHang"] == DBNull.Value ? (int?)null : Convert.ToInt32(rd["IDKhachHang"]),
                IDNhanVien = rd["IDNhanVien"] == DBNull.Value ? (int?)null : Convert.ToInt32(rd["IDNhanVien"]),
                TenKhachHang = rd["TenKhachHang"] == DBNull.Value ? null : rd["TenKhachHang"].ToString(),
                TenNhanVien = rd["TenNhanVien"] == DBNull.Value ? null : rd["TenNhanVien"].ToString(),
                NgayLap = Convert.ToDateTime(rd["NgayLap"]),
                TongTien = Convert.ToDecimal(rd["TongTien"]),
                LoaiDon = Convert.ToInt32(rd["LoaiDon"]),
                IDBan = rd["IDBan"] == DBNull.Value ? (int?)null : Convert.ToInt32(rd["IDBan"]),
                TenBan = rd["TenBan"] == DBNull.Value ? null : rd["TenBan"].ToString(),
                PhuongThucThanhToan = rd["PhuongThucThanhToan"].ToString(),
                TrangThai = Convert.ToInt32(rd["TrangThai"]),
                TrangThaiDon = rd["TrangThaiDon"] == DBNull.Value ? 0 : Convert.ToInt32(rd["TrangThaiDon"]),
                GhiChu = rd["GhiChu"] == DBNull.Value ? null : rd["GhiChu"].ToString()
            };
        }
    }
}