﻿// DAL/LoaiSanPhamDAL.cs
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.DAL
{
    public class LoaiSanPhamDAL
    {
        public List<LoaiSanPhamDTO> LayDanhSach(bool chiLayDangHoatDong = true)
        {
            string sql = chiLayDangHoatDong
                ? "SELECT * FROM LoaiSanPham WHERE KichHoat = 1 ORDER BY IDLoai"
                : "SELECT * FROM LoaiSanPham ORDER BY IDLoai";

            List<LoaiSanPhamDTO> ds = new List<LoaiSanPhamDTO>();

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            using (SqlDataReader rd = cmd.ExecuteReader())
            {
                while (rd.Read())
                {
                    ds.Add(new LoaiSanPhamDTO
                    {
                        IDLoai = Convert.ToInt32(rd["IDLoai"]),
                        TenLoai = rd["TenLoai"].ToString(),
                        KichHoat = Convert.ToBoolean(rd["KichHoat"])
                    });
                }
            }

            return ds;
        }

        public bool TonTaiTenLoai(string tenLoai, int? boQuaID = null)
        {
            const string sql = @"
                SELECT COUNT(*)
                FROM LoaiSanPham
                WHERE TenLoai = @TenLoai
                  AND (@BoQuaID IS NULL OR IDLoai <> @BoQuaID)";

            return DatabaseHelper.Exists(
                sql,
                new SqlParameter("@TenLoai", SqlDbType.NVarChar, 50) { Value = tenLoai },
                new SqlParameter("@BoQuaID", SqlDbType.Int) { Value = DatabaseHelper.DbValue(boQuaID) }
            );
        }

        public bool Them(LoaiSanPhamDTO loai)
        {
            const string sql = "INSERT INTO LoaiSanPham (TenLoai, KichHoat) VALUES (@TenLoai, @KichHoat)";

            return DatabaseHelper.ExecuteNonQuery(
                sql,
                new SqlParameter("@TenLoai", SqlDbType.NVarChar, 50) { Value = loai.TenLoai },
                new SqlParameter("@KichHoat", SqlDbType.Bit) { Value = loai.KichHoat }
            ) > 0;
        }

        public bool Sua(LoaiSanPhamDTO loai)
        {
            const string sql = "UPDATE LoaiSanPham SET TenLoai = @TenLoai, KichHoat = @KichHoat WHERE IDLoai = @IDLoai";

            return DatabaseHelper.ExecuteNonQuery(
                sql,
                new SqlParameter("@IDLoai", SqlDbType.Int) { Value = loai.IDLoai },
                new SqlParameter("@TenLoai", SqlDbType.NVarChar, 50) { Value = loai.TenLoai },
                new SqlParameter("@KichHoat", SqlDbType.Bit) { Value = loai.KichHoat }
            ) > 0;
        }

        public bool Xoa(int idLoai)
        {
            const string sql = "UPDATE LoaiSanPham SET KichHoat = 0 WHERE IDLoai = @IDLoai";

            return DatabaseHelper.ExecuteNonQuery(
                sql,
                new SqlParameter("@IDLoai", SqlDbType.Int) { Value = idLoai }
            ) > 0;
        }
    }
}
