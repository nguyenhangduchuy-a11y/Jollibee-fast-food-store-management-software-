﻿// DAL/ChiTietHoaDonDAL.cs
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.DAL
{
    public class ChiTietHoaDonDAL
    {
        public List<ChiTietHoaDonDTO> LayTheoHoaDon(int idHoaDon)
        {
            const string sql = @"
                SELECT ct.*, sp.MaSanPham, sp.TenSanPham
                FROM ChiTietHoaDon ct
                INNER JOIN SanPham sp ON ct.IDSanPham = sp.IDSanPham
                WHERE ct.IDHoaDon = @IDHoaDon";

            List<ChiTietHoaDonDTO> ds = new List<ChiTietHoaDonDTO>();

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.Add("@IDHoaDon", SqlDbType.Int).Value = idHoaDon;

                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        ds.Add(new ChiTietHoaDonDTO
                        {
                            IDChiTiet = Convert.ToInt32(rd["IDChiTiet"]),
                            IDHoaDon = Convert.ToInt32(rd["IDHoaDon"]),
                            IDSanPham = Convert.ToInt32(rd["IDSanPham"]),
                            MaSanPham = rd["MaSanPham"].ToString(),
                            TenSanPham = rd["TenSanPham"].ToString(),
                            SoLuong = Convert.ToInt32(rd["SoLuong"]),
                            DonGia = Convert.ToDecimal(rd["DonGia"]),
                            ThanhTien = Convert.ToDecimal(rd["ThanhTien"]),
                            GhiChu = rd["GhiChu"] == DBNull.Value ? null : rd["GhiChu"].ToString()
                        });
                    }
                }
            }

            return ds;
        }
    }
}
