﻿// DAL/NguoiDungDAL.cs
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.DAL
{
    public class NguoiDungDAL
    {
        public NguoiDungDTO DangNhap(string tenDangNhap, string matKhau)
        {
            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand("sp_DangNhap", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@TenDangNhap", SqlDbType.NVarChar, 50).Value = tenDangNhap;
                cmd.Parameters.Add("@MatKhau", SqlDbType.NVarChar, 255).Value = matKhau;

                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    if (rd.Read())
                        return MapNguoiDung(rd);

                    return null;
                }
            }
        }

        public int DangKyKhachHang(string tenDangNhap, string matKhau, string hoTen)
        {
            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand("sp_DangKyKhachHang", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@TenDangNhap", SqlDbType.NVarChar, 50).Value = tenDangNhap;
                cmd.Parameters.Add("@MatKhau", SqlDbType.NVarChar, 255).Value = matKhau;
                cmd.Parameters.Add("@HoTen", SqlDbType.NVarChar, 100).Value = hoTen;

                SqlParameter ketQua = new SqlParameter("@KetQua", SqlDbType.Int);
                ketQua.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(ketQua);

                cmd.ExecuteNonQuery();
                return Convert.ToInt32(ketQua.Value);
            }
        }

        public bool DoiMatKhau(int idNguoiDung, string matKhauCu, string matKhauMoi)
        {
            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand("sp_DoiMatKhau", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add("@IDNguoiDung", SqlDbType.Int).Value = idNguoiDung;
                cmd.Parameters.Add("@MatKhauCu", SqlDbType.NVarChar, 255).Value = matKhauCu;
                cmd.Parameters.Add("@MatKhauMoi", SqlDbType.NVarChar, 255).Value = matKhauMoi;

                SqlParameter ketQua = new SqlParameter("@KetQua", SqlDbType.Int);
                ketQua.Direction = ParameterDirection.Output;
                cmd.Parameters.Add(ketQua);

                cmd.ExecuteNonQuery();
                return Convert.ToInt32(ketQua.Value) == 1;
            }
        }

        public List<NguoiDungDTO> LayDanhSachNguoiDung()
        {
            const string sql = "SELECT * FROM NguoiDung ORDER BY IDNguoiDung DESC";
            return ExecuteList(sql);
        }

        public List<NguoiDungDTO> LayDanhSachNhanVien()
        {
            const string sql = "SELECT * FROM NguoiDung WHERE VaiTro = 2 ORDER BY IDNguoiDung DESC";
            return ExecuteList(sql);
        }

        public List<NguoiDungDTO> LayDanhSachKhachHang()
        {
            const string sql = "SELECT * FROM NguoiDung WHERE VaiTro = 3 ORDER BY IDNguoiDung DESC";
            return ExecuteList(sql);
        }

        public NguoiDungDTO LayTheoID(int idNguoiDung)
        {
            const string sql = "SELECT * FROM NguoiDung WHERE IDNguoiDung = @IDNguoiDung";

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.Add("@IDNguoiDung", SqlDbType.Int).Value = idNguoiDung;

                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    if (rd.Read())
                        return MapNguoiDung(rd);

                    return null;
                }
            }
        }

        public bool TonTaiNguoiDung(int idNguoiDung)
        {
            const string sql = "SELECT COUNT(*) FROM NguoiDung WHERE IDNguoiDung = @IDNguoiDung";

            return DatabaseHelper.Exists(
                sql,
                new SqlParameter("@IDNguoiDung", SqlDbType.Int) { Value = idNguoiDung }
            );
        }

        public bool TonTaiTenDangNhap(string tenDangNhap, int? boQuaID = null)
        {
            const string sql = @"
                SELECT COUNT(*)
                FROM NguoiDung
                WHERE TenDangNhap = @TenDangNhap
                  AND (@BoQuaID IS NULL OR IDNguoiDung <> @BoQuaID)";

            return DatabaseHelper.Exists(
                sql,
                new SqlParameter("@TenDangNhap", SqlDbType.NVarChar, 50) { Value = tenDangNhap },
                new SqlParameter("@BoQuaID", SqlDbType.Int) { Value = DatabaseHelper.DbValue(boQuaID) }
            );
        }

        public bool ThemNhanVien(string tenDangNhap, string matKhau, string hoTen)
        {
            const string sql = @"
                INSERT INTO NguoiDung (TenDangNhap, MatKhauHash, HoTen, VaiTro, KichHoat)
                VALUES (@TenDangNhap, HASHBYTES('SHA2_256', @MatKhau), @HoTen, 2, 1)";

            return DatabaseHelper.ExecuteNonQuery(
                sql,
                new SqlParameter("@TenDangNhap", SqlDbType.NVarChar, 50) { Value = tenDangNhap },
                new SqlParameter("@MatKhau", SqlDbType.NVarChar, 255) { Value = matKhau },
                new SqlParameter("@HoTen", SqlDbType.NVarChar, 100) { Value = hoTen }
            ) > 0;
        }

        public bool CapNhatNguoiDung(NguoiDungDTO nd)
        {
            const string sql = @"
                UPDATE NguoiDung
                SET HoTen = @HoTen, VaiTro = @VaiTro, KichHoat = @KichHoat
                WHERE IDNguoiDung = @IDNguoiDung";

            return DatabaseHelper.ExecuteNonQuery(
                sql,
                new SqlParameter("@IDNguoiDung", SqlDbType.Int) { Value = nd.IDNguoiDung },
                new SqlParameter("@HoTen", SqlDbType.NVarChar, 100) { Value = nd.HoTen },
                new SqlParameter("@VaiTro", SqlDbType.Int) { Value = nd.VaiTro },
                new SqlParameter("@KichHoat", SqlDbType.Bit) { Value = nd.KichHoat }
            ) > 0;
        }

        public bool KhoaMoTaiKhoan(int idNguoiDung, bool kichHoat)
        {
            const string sql = "UPDATE NguoiDung SET KichHoat = @KichHoat WHERE IDNguoiDung = @IDNguoiDung";

            return DatabaseHelper.ExecuteNonQuery(
                sql,
                new SqlParameter("@IDNguoiDung", SqlDbType.Int) { Value = idNguoiDung },
                new SqlParameter("@KichHoat", SqlDbType.Bit) { Value = kichHoat }
            ) > 0;
        }

        private List<NguoiDungDTO> ExecuteList(string sql)
        {
            List<NguoiDungDTO> ds = new List<NguoiDungDTO>();

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            using (SqlDataReader rd = cmd.ExecuteReader())
            {
                while (rd.Read())
                {
                    ds.Add(MapNguoiDung(rd));
                }
            }

            return ds;
        }

        private NguoiDungDTO MapNguoiDung(SqlDataReader rd)
        {
            NguoiDungDTO nd = new NguoiDungDTO();

            nd.IDNguoiDung = Convert.ToInt32(rd["IDNguoiDung"]);
            nd.TenDangNhap = rd["TenDangNhap"].ToString();
            nd.HoTen = rd["HoTen"].ToString();
            nd.VaiTro = Convert.ToInt32(rd["VaiTro"]);
            nd.KichHoat = Convert.ToBoolean(rd["KichHoat"]);

            nd.MatKhauHash = HasColumn(rd, "MatKhauHash") && rd["MatKhauHash"] != DBNull.Value
                ? rd["MatKhauHash"].ToString()
                : string.Empty;

            nd.NgayTao = HasColumn(rd, "NgayTao") && rd["NgayTao"] != DBNull.Value
                ? Convert.ToDateTime(rd["NgayTao"])
                : DateTime.MinValue;

            nd.LanDangNhapCuoi = HasColumn(rd, "LanDangNhapCuoi") && rd["LanDangNhapCuoi"] != DBNull.Value
                ? (DateTime?)Convert.ToDateTime(rd["LanDangNhapCuoi"])
                : (DateTime?)null;

            return nd;
        }

        private bool HasColumn(SqlDataReader rd, string columnName)
        {
            for (int i = 0; i < rd.FieldCount; i++)
            {
                if (string.Equals(rd.GetName(i), columnName, StringComparison.OrdinalIgnoreCase))
                    return true;
            }

            return false;
        }
    }
}
