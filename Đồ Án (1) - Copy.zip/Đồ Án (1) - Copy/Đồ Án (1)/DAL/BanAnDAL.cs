﻿// DAL/BanAnDAL.cs
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.DAL
{
    public class BanAnDAL
    {
        public List<BanAnDTO> LayDanhSachBan()
        {
            const string sql = "SELECT * FROM BanAn ORDER BY IDBan";
            return ExecuteList(sql);
        }

        public List<BanAnDTO> LayBanTrong()
        {
            const string sql = "SELECT * FROM BanAn WHERE TrangThai = 0 ORDER BY IDBan";
            return ExecuteList(sql);
        }

        public BanAnDTO LayTheoID(int idBan)
        {
            const string sql = "SELECT * FROM BanAn WHERE IDBan = @IDBan";

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.Add("@IDBan", SqlDbType.Int).Value = idBan;

                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    if (rd.Read())
                        return MapBan(rd);

                    return null;
                }
            }
        }

        public bool TonTaiTenBan(string tenBan, int? boQuaID = null)
        {
            const string sql = @"
                SELECT COUNT(*)
                FROM BanAn
                WHERE TenBan = @TenBan
                  AND (@BoQuaID IS NULL OR IDBan <> @BoQuaID)";

            return DatabaseHelper.Exists(
                sql,
                new SqlParameter("@TenBan", SqlDbType.NVarChar, 20) { Value = tenBan },
                new SqlParameter("@BoQuaID", SqlDbType.Int) { Value = DatabaseHelper.DbValue(boQuaID) }
            );
        }

        public bool Them(BanAnDTO ban)
        {
            const string sql = "INSERT INTO BanAn (TenBan, TrangThai) VALUES (@TenBan, 0)";

            return DatabaseHelper.ExecuteNonQuery(
                sql,
                new SqlParameter("@TenBan", SqlDbType.NVarChar, 20) { Value = ban.TenBan }
            ) > 0;
        }

        public bool Sua(BanAnDTO ban)
        {
            const string sql = "UPDATE BanAn SET TenBan = @TenBan, TrangThai = @TrangThai WHERE IDBan = @IDBan";

            return DatabaseHelper.ExecuteNonQuery(
                sql,
                new SqlParameter("@IDBan", SqlDbType.Int) { Value = ban.IDBan },
                new SqlParameter("@TenBan", SqlDbType.NVarChar, 20) { Value = ban.TenBan },
                new SqlParameter("@TrangThai", SqlDbType.Int) { Value = ban.TrangThai }
            ) > 0;
        }

        public bool Xoa(int idBan)
        {
            const string sql = "DELETE FROM BanAn WHERE IDBan = @IDBan AND TrangThai = 0";

            return DatabaseHelper.ExecuteNonQuery(
                sql,
                new SqlParameter("@IDBan", SqlDbType.Int) { Value = idBan }
            ) > 0;
        }

        public bool CapNhatTrangThai(int idBan, int trangThai)
        {
            const string sql = "UPDATE BanAn SET TrangThai = @TrangThai WHERE IDBan = @IDBan";

            return DatabaseHelper.ExecuteNonQuery(
                sql,
                new SqlParameter("@IDBan", SqlDbType.Int) { Value = idBan },
                new SqlParameter("@TrangThai", SqlDbType.Int) { Value = trangThai }
            ) > 0;
        }

        public bool DonBan(int idBan)
        {
            return CapNhatTrangThai(idBan, 0);
        }

        private List<BanAnDTO> ExecuteList(string sql)
        {
            List<BanAnDTO> ds = new List<BanAnDTO>();

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            using (SqlDataReader rd = cmd.ExecuteReader())
            {
                while (rd.Read())
                {
                    ds.Add(MapBan(rd));
                }
            }

            return ds;
        }

        private BanAnDTO MapBan(SqlDataReader rd)
        {
            return new BanAnDTO
            {
                IDBan = Convert.ToInt32(rd["IDBan"]),
                TenBan = rd["TenBan"].ToString(),
                TrangThai = Convert.ToInt32(rd["TrangThai"])
            };
        }
    }
}
