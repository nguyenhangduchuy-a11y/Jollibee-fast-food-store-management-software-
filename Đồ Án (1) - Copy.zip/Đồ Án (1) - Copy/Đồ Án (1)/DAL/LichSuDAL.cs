﻿// DAL/LichSuDAL.cs
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.DAL
{
    public class LichSuDAL
    {
        public List<HoaDonDTO> LayTheoNhanVien(int idNhanVien, DateTime? ngay = null)
        {
            const string sql = @"
                SELECT hd.*, nv.HoTen AS TenNhanVien, kh.HoTen AS TenKhachHang, b.TenBan
                FROM HoaDon hd
                LEFT JOIN NguoiDung nv ON hd.IDNhanVien = nv.IDNguoiDung
                LEFT JOIN NguoiDung kh ON hd.IDKhachHang = kh.IDNguoiDung
                LEFT JOIN BanAn b ON hd.IDBan = b.IDBan
                WHERE hd.IDNhanVien = @IDNhanVien
                  AND CAST(hd.NgayLap AS DATE) = @Ngay
                  AND hd.TrangThai = 1
                ORDER BY hd.NgayLap DESC";

            return ExecuteHoaDonList(
                sql,
                new SqlParameter("@IDNhanVien", SqlDbType.Int) { Value = idNhanVien },
                new SqlParameter("@Ngay", SqlDbType.Date) { Value = (ngay ?? DateTime.Today).Date }
            );
        }

        public List<HoaDonDTO> LayTheoKhachHang(int idKhachHang)
        {
            const string sql = @"
                SELECT hd.*, nv.HoTen AS TenNhanVien, kh.HoTen AS TenKhachHang, b.TenBan
                FROM HoaDon hd
                LEFT JOIN NguoiDung nv ON hd.IDNhanVien = nv.IDNguoiDung
                LEFT JOIN NguoiDung kh ON hd.IDKhachHang = kh.IDNguoiDung
                LEFT JOIN BanAn b ON hd.IDBan = b.IDBan
                WHERE hd.IDKhachHang = @IDKhachHang
                  AND hd.TrangThai = 1
                ORDER BY hd.NgayLap DESC";

            return ExecuteHoaDonList(
                sql,
                new SqlParameter("@IDKhachHang", SqlDbType.Int) { Value = idKhachHang }
            );
        }

        public List<HoaDonDTO> LayTheoThoiGian(DateTime tuNgay, DateTime denNgay)
        {
            const string sql = @"
                SELECT hd.*, nv.HoTen AS TenNhanVien, kh.HoTen AS TenKhachHang, b.TenBan
                FROM HoaDon hd
                LEFT JOIN NguoiDung nv ON hd.IDNhanVien = nv.IDNguoiDung
                LEFT JOIN NguoiDung kh ON hd.IDKhachHang = kh.IDNguoiDung
                LEFT JOIN BanAn b ON hd.IDBan = b.IDBan
                WHERE hd.NgayLap >= @TuNgay
                  AND hd.NgayLap < @DenNgay
                  AND hd.TrangThai = 1
                ORDER BY hd.NgayLap DESC";

            return ExecuteHoaDonList(
                sql,
                new SqlParameter("@TuNgay", SqlDbType.DateTime) { Value = tuNgay.Date },
                new SqlParameter("@DenNgay", SqlDbType.DateTime) { Value = denNgay.Date.AddDays(1) }
            );
        }

        private List<HoaDonDTO> ExecuteHoaDonList(string sql, params SqlParameter[] parameters)
        {
            List<HoaDonDTO> ds = new List<HoaDonDTO>();

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddRange(parameters);

                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        ds.Add(new HoaDonDTO
                        {
                            IDHoaDon = Convert.ToInt32(rd["IDHoaDon"]),
                            MaHoaDon = rd["MaHoaDon"].ToString(),
                            IDKhachHang = rd["IDKhachHang"] == DBNull.Value ? (int?)null : Convert.ToInt32(rd["IDKhachHang"]),
                            IDNhanVien = rd["IDNhanVien"] == DBNull.Value ? (int?)null : Convert.ToInt32(rd["IDNhanVien"]),
                            TenKhachHang = rd["TenKhachHang"] == DBNull.Value ? null : rd["TenKhachHang"].ToString(),
                            TenNhanVien = rd["TenNhanVien"] == DBNull.Value ? null : rd["TenNhanVien"].ToString(),
                            NgayLap = Convert.ToDateTime(rd["NgayLap"]),
                            TongTien = Convert.ToDecimal(rd["TongTien"]),
                            LoaiDon = Convert.ToInt32(rd["LoaiDon"]),
                            IDBan = rd["IDBan"] == DBNull.Value ? (int?)null : Convert.ToInt32(rd["IDBan"]),
                            TenBan = rd["TenBan"] == DBNull.Value ? null : rd["TenBan"].ToString(),
                            PhuongThucThanhToan = rd["PhuongThucThanhToan"].ToString(),
                            TrangThai = Convert.ToInt32(rd["TrangThai"]),
                            GhiChu = rd["GhiChu"] == DBNull.Value ? null : rd["GhiChu"].ToString()
                        });
                    }
                }
            }

            return ds;
        }
    }
}
