﻿// DAL/DatabaseHelper.cs
using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IO;
using System.Xml;

namespace Đồ_Án__1_.DAL
{
    public static class DatabaseHelper
    {
        private static string _connectionString;
        private static bool _logErrors = true;
        private static readonly object _lockObject = new object();

        static DatabaseHelper()
        {
            InitializeConnectionString();
        }

        private static void InitializeConnectionString()
        {
            try
            {
                string configPath = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
                if (File.Exists(configPath))
                {
                    XmlDocument doc = new XmlDocument();
                    doc.Load(configPath);
                    XmlNode node = doc.SelectSingleNode("//connectionStrings/add[@name='QuanLyJollibee']");
                    if (node != null && node.Attributes?["connectionString"] != null)
                    {
                        _connectionString = node.Attributes["connectionString"].Value;
                        if (!string.IsNullOrEmpty(_connectionString))
                            return;
                    }
                }
            }
            catch (Exception ex)
            {
                LogError("Lỗi đọc connection string", ex);
            }

            _connectionString = GetDefaultConnectionString();
        }

        private static string GetDefaultConnectionString()
        {
            return @"Data Source=localhost;Initial Catalog=QuanLyJollibee;Integrated Security=True;TrustServerCertificate=True";
        }

        public static string ConnectionString
        {
            get { return _connectionString; }
        }

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(_connectionString);
        }

        /// <summary>
        /// ⚠️ CẢNH BÁO: Chỉ dùng method này khi bạn chắc chắn sẽ đóng connection!
        /// Khuyến khích dùng GetConnection() + using thay vì OpenConnection()
        /// </summary>
        public static SqlConnection OpenConnection()
        {
            var conn = GetConnection();
            conn.Open();
            return conn;
        }

        public static async Task<SqlConnection> OpenConnectionAsync()
        {
            var conn = GetConnection();
            await conn.OpenAsync();
            return conn;
        }

        public static object DbValue(object value)
        {
            return value ?? DBNull.Value;
        }

        public static bool Exists(string sql, params SqlParameter[] parameters)
        {
            using (var conn = GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                conn.Open();
                var result = cmd.ExecuteScalar();
                return result != null && result != DBNull.Value && Convert.ToInt32(result) > 0;
            }
        }

        public static async Task<bool> ExistsAsync(string sql, params SqlParameter[] parameters)
        {
            using (var conn = GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                await conn.OpenAsync();
                var result = await cmd.ExecuteScalarAsync();
                return result != null && result != DBNull.Value && Convert.ToInt32(result) > 0;
            }
        }

        public static int ExecuteNonQuery(string sql, params SqlParameter[] parameters)
        {
            using (var conn = GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                conn.Open();
                return cmd.ExecuteNonQuery();
            }
        }

        public static async Task<int> ExecuteNonQueryAsync(string sql, params SqlParameter[] parameters)
        {
            using (var conn = GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                await conn.OpenAsync();
                return await cmd.ExecuteNonQueryAsync();
            }
        }

        public static object ExecuteScalar(string sql, params SqlParameter[] parameters)
        {
            using (var conn = GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                conn.Open();
                return cmd.ExecuteScalar();
            }
        }

        public static async Task<object> ExecuteScalarAsync(string sql, params SqlParameter[] parameters)
        {
            using (var conn = GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                await conn.OpenAsync();
                return await cmd.ExecuteScalarAsync();
            }
        }

        public static SqlDataReader ExecuteReader(string sql, params SqlParameter[] parameters)
        {
            var conn = GetConnection();
            var cmd = new SqlCommand(sql, conn);
            if (parameters != null)
                cmd.Parameters.AddRange(parameters);
            conn.Open();
            return cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }

        public static SqlDataReader ExecuteStoredProcedure(string storedProcName, params SqlParameter[] parameters)
        {
            var conn = GetConnection();
            var cmd = new SqlCommand(storedProcName, conn);
            cmd.CommandType = CommandType.StoredProcedure;
            if (parameters != null)
                cmd.Parameters.AddRange(parameters);
            conn.Open();
            return cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }

        public static DataTable ExecuteDataTable(string sql, params SqlParameter[] parameters)
        {
            using (var conn = GetConnection())
            using (var cmd = new SqlCommand(sql, conn))
            using (var da = new SqlDataAdapter(cmd))
            {
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                conn.Open();
                var dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public static DataTable ExecuteStoredProcedureDataTable(string storedProcName, params SqlParameter[] parameters)
        {
            using (var conn = GetConnection())
            using (var cmd = new SqlCommand(storedProcName, conn))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);
                conn.Open();
                var dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public static bool TestConnection()
        {
            try
            {
                using (var conn = GetConnection())
                {
                    conn.Open();
                    return true;
                }
            }
            catch (Exception ex)
            {
                LogError("TestConnection thất bại", ex);
                return false;
            }
        }

        public static async Task<bool> TestConnectionAsync()
        {
            try
            {
                using (var conn = GetConnection())
                {
                    await conn.OpenAsync();
                    return true;
                }
            }
            catch (Exception ex)
            {
                LogError("TestConnectionAsync thất bại", ex);
                return false;
            }
        }

        #region Logging

        public static bool LogErrors
        {
            get { return _logErrors; }
            set { _logErrors = value; }
        }

        private static void LogError(string message, Exception ex)
        {
            if (!_logErrors) return;

            try
            {
                string logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "DatabaseLog.txt");
                string logMessage = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} [ERROR] {message}\n" +
                                   $"Exception: {ex.Message}\n" +
                                   $"Stack Trace: {ex.StackTrace}\n" +
                                   $"----------------------------------------\n";

                lock (_lockObject)
                {
                    File.AppendAllText(logPath, logMessage);
                }
            }
            catch
            {
                Debug.WriteLine($"{DateTime.Now} [ERROR] {message}: {ex.Message}");
            }
        }

        #endregion
    }
}