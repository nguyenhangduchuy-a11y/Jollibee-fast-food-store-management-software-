﻿// DAL/ThongKeDAL.cs - Phiên bản đúng với stored procedure
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.DAL
{
    public class ThongKeDAL
    {
        public List<DoanhThuDTO> BaoCaoDoanhThu(DateTime tuNgay, DateTime denNgay)
        {
            List<DoanhThuDTO> ds = new List<DoanhThuDTO>();

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand("sp_BaoCaoDoanhThu", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@TuNgay", SqlDbType.Date).Value = tuNgay.Date;
                cmd.Parameters.Add("@DenNgay", SqlDbType.Date).Value = denNgay.Date;

                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        ds.Add(new DoanhThuDTO
                        {
                            Ngay = Convert.ToDateTime(rd["Ngay"]),
                            NgayText = rd["NgayText"].ToString(),
                            SoDon = Convert.ToInt32(rd["SoDon"]),
                            DoanhThu = Convert.ToDecimal(rd["DoanhThu"]),
                            TrungBinhDon = Convert.ToDecimal(rd["TrungBinhDon"]),
                            DonCaoNhat = Convert.ToDecimal(rd["DonCaoNhat"]),
                            DonThapNhat = Convert.ToDecimal(rd["DonThapNhat"])
                        });
                    }
                }
            }
            return ds;
        }

        public List<TopSanPhamBanChayDTO> TopSanPhamBanChay(int top)
        {
            List<TopSanPhamBanChayDTO> ds = new List<TopSanPhamBanChayDTO>();

            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand("sp_TopSanPhamBanChay", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@Top", SqlDbType.Int).Value = top;

                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    while (rd.Read())
                    {
                        ds.Add(new TopSanPhamBanChayDTO
                        {
                            IDSanPham = Convert.ToInt32(rd["IDSanPham"]),
                            MaSanPham = rd["MaSanPham"].ToString(),
                            TenSanPham = rd["TenSanPham"].ToString(),
                            SoLuongBan = Convert.ToInt32(rd["SoLuongBan"]),
                            DoanhThu = Convert.ToDecimal(rd["DoanhThu"])
                        });
                    }
                }
            }
            return ds;
        }

        public ThongKeNhanVienDTO ThongKeNhanVien(int idNhanVien, DateTime tuNgay, DateTime denNgay)
        {
            using (SqlConnection conn = DatabaseHelper.OpenConnection())
            using (SqlCommand cmd = new SqlCommand("sp_ThongKeNhanVien", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@IDNhanVien", SqlDbType.Int).Value = idNhanVien;
                cmd.Parameters.Add("@TuNgay", SqlDbType.Date).Value = tuNgay.Date;
                cmd.Parameters.Add("@DenNgay", SqlDbType.Date).Value = denNgay.Date;

                using (SqlDataReader rd = cmd.ExecuteReader())
                {
                    if (rd.Read())
                    {
                        return new ThongKeNhanVienDTO
                        {
                            SoDonHoanThanh = rd["SoDonHoanThanh"] == DBNull.Value ? 0 : Convert.ToInt32(rd["SoDonHoanThanh"]),
                            TongDoanhThu = rd["TongDoanhThu"] == DBNull.Value ? 0 : Convert.ToDecimal(rd["TongDoanhThu"]),
                            TrungBinhDon = rd["TrungBinhDon"] == DBNull.Value ? 0 : Convert.ToDecimal(rd["TrungBinhDon"])
                        };
                    }
                    return new ThongKeNhanVienDTO();
                }
            }
        }
    }
}