﻿namespace Đồ_Án__1_
{
    partial class quanlyxuatfile
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.btnLamMoiTopSanPham = new System.Windows.Forms.Button();
            this.dtpkToDayTopsanPham = new System.Windows.Forms.DateTimePicker();
            this.dtpkFromDayTopSanPham = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.listBoxTopSanPham = new System.Windows.Forms.ListBox();
            this.panel21 = new System.Windows.Forms.Panel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.btnSanPham = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.btnHoaDonTheoNgay = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.btnHoaDon = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.btnDoanhThu = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.panel30.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.Silver;
            this.panel30.Controls.Add(this.panel22);
            this.panel30.Controls.Add(this.label14);
            this.panel30.Location = new System.Drawing.Point(12, 12);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(1213, 46);
            this.panel30.TabIndex = 3;
            this.panel30.Paint += new System.Windows.Forms.PaintEventHandler(this.panel30_Paint);
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.btnLamMoiTopSanPham);
            this.panel22.Controls.Add(this.dtpkToDayTopsanPham);
            this.panel22.Controls.Add(this.dtpkFromDayTopSanPham);
            this.panel22.Location = new System.Drawing.Point(659, 6);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(548, 37);
            this.panel22.TabIndex = 4;
            // 
            // btnLamMoiTopSanPham
            // 
            this.btnLamMoiTopSanPham.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnLamMoiTopSanPham.Location = new System.Drawing.Point(467, 3);
            this.btnLamMoiTopSanPham.Name = "btnLamMoiTopSanPham";
            this.btnLamMoiTopSanPham.Size = new System.Drawing.Size(75, 30);
            this.btnLamMoiTopSanPham.TabIndex = 3;
            this.btnLamMoiTopSanPham.Text = "Làm Mới";
            this.btnLamMoiTopSanPham.UseVisualStyleBackColor = false;
            // 
            // dtpkToDayTopsanPham
            // 
            this.dtpkToDayTopsanPham.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.dtpkToDayTopsanPham.CalendarTitleForeColor = System.Drawing.SystemColors.Info;
            this.dtpkToDayTopsanPham.Location = new System.Drawing.Point(235, 3);
            this.dtpkToDayTopsanPham.Name = "dtpkToDayTopsanPham";
            this.dtpkToDayTopsanPham.Size = new System.Drawing.Size(200, 22);
            this.dtpkToDayTopsanPham.TabIndex = 0;
            this.dtpkToDayTopsanPham.ValueChanged += new System.EventHandler(this.dtpkToDayTopsanPham_ValueChanged_1);
            // 
            // dtpkFromDayTopSanPham
            // 
            this.dtpkFromDayTopSanPham.Location = new System.Drawing.Point(26, 3);
            this.dtpkFromDayTopSanPham.Name = "dtpkFromDayTopSanPham";
            this.dtpkFromDayTopSanPham.Size = new System.Drawing.Size(200, 22);
            this.dtpkFromDayTopSanPham.TabIndex = 1;
            this.dtpkFromDayTopSanPham.ValueChanged += new System.EventHandler(this.dtpkFromDayTopSanPham_ValueChanged_1);
            // 
            // label14
            // 
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(4, 11);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(225, 23);
            this.label14.TabIndex = 2;
            this.label14.Text = "Quản Lý File Excel";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label14.Click += new System.EventHandler(this.label14_Click_1);
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.listBoxTopSanPham);
            this.panel20.Location = new System.Drawing.Point(9, 64);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(1210, 317);
            this.panel20.TabIndex = 4;
            this.panel20.Paint += new System.Windows.Forms.PaintEventHandler(this.panel20_Paint);
            // 
            // listBoxTopSanPham
            // 
            this.listBoxTopSanPham.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxTopSanPham.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.listBoxTopSanPham.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxTopSanPham.FormattingEnabled = true;
            this.listBoxTopSanPham.Location = new System.Drawing.Point(0, 0);
            this.listBoxTopSanPham.Name = "listBoxTopSanPham";
            this.listBoxTopSanPham.Size = new System.Drawing.Size(1210, 317);
            this.listBoxTopSanPham.TabIndex = 0;
            this.listBoxTopSanPham.SelectedIndexChanged += new System.EventHandler(this.listBoxTopSanPham_SelectedIndexChanged_1);
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.panel31);
            this.panel21.Controls.Add(this.panel34);
            this.panel21.Controls.Add(this.panel32);
            this.panel21.Controls.Add(this.panel33);
            this.panel21.Location = new System.Drawing.Point(12, 387);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(1213, 73);
            this.panel21.TabIndex = 5;
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel31.Controls.Add(this.btnSanPham);
            this.panel31.Controls.Add(this.label15);
            this.panel31.ForeColor = System.Drawing.Color.Black;
            this.panel31.Location = new System.Drawing.Point(7, 10);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(268, 60);
            this.panel31.TabIndex = 2;
            // 
            // btnSanPham
            // 
            this.btnSanPham.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnSanPham.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSanPham.ForeColor = System.Drawing.Color.Black;
            this.btnSanPham.Location = new System.Drawing.Point(158, 7);
            this.btnSanPham.Name = "btnSanPham";
            this.btnSanPham.Size = new System.Drawing.Size(75, 53);
            this.btnSanPham.TabIndex = 1;
            this.btnSanPham.Text = "MỞ FILE";
            this.btnSanPham.UseVisualStyleBackColor = false;
            this.btnSanPham.Click += new System.EventHandler(this.btnSanPham_Click_1);
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(15, 6);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(124, 52);
            this.label15.TabIndex = 0;
            this.label15.Text = "SẢN PHẨM:";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel34.Controls.Add(this.btnHoaDonTheoNgay);
            this.panel34.Controls.Add(this.label18);
            this.panel34.ForeColor = System.Drawing.Color.Black;
            this.panel34.Location = new System.Drawing.Point(942, 10);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(268, 60);
            this.panel34.TabIndex = 3;
            // 
            // btnHoaDonTheoNgay
            // 
            this.btnHoaDonTheoNgay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnHoaDonTheoNgay.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHoaDonTheoNgay.ForeColor = System.Drawing.Color.Black;
            this.btnHoaDonTheoNgay.Location = new System.Drawing.Point(158, 7);
            this.btnHoaDonTheoNgay.Name = "btnHoaDonTheoNgay";
            this.btnHoaDonTheoNgay.Size = new System.Drawing.Size(75, 53);
            this.btnHoaDonTheoNgay.TabIndex = 1;
            this.btnHoaDonTheoNgay.Text = "MỞ FILE";
            this.btnHoaDonTheoNgay.UseVisualStyleBackColor = false;
            this.btnHoaDonTheoNgay.Click += new System.EventHandler(this.btnHoaDonTheoNgay_Click_1);
            // 
            // label18
            // 
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(15, 6);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(124, 52);
            this.label18.TabIndex = 0;
            this.label18.Text = "HÓA ĐƠN THEO NGÀY:";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label18.Click += new System.EventHandler(this.label18_Click_1);
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel32.Controls.Add(this.btnHoaDon);
            this.panel32.Controls.Add(this.label16);
            this.panel32.ForeColor = System.Drawing.Color.Black;
            this.panel32.Location = new System.Drawing.Point(303, 10);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(268, 60);
            this.panel32.TabIndex = 3;
            // 
            // btnHoaDon
            // 
            this.btnHoaDon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnHoaDon.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHoaDon.ForeColor = System.Drawing.Color.Black;
            this.btnHoaDon.Location = new System.Drawing.Point(158, 7);
            this.btnHoaDon.Name = "btnHoaDon";
            this.btnHoaDon.Size = new System.Drawing.Size(75, 53);
            this.btnHoaDon.TabIndex = 1;
            this.btnHoaDon.Text = "MỞ FILE";
            this.btnHoaDon.UseVisualStyleBackColor = false;
            this.btnHoaDon.Click += new System.EventHandler(this.btnHoaDon_Click_1);
            // 
            // label16
            // 
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(15, 6);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(124, 52);
            this.label16.TabIndex = 0;
            this.label16.Text = "HÓA ĐƠN:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel33.Controls.Add(this.btnDoanhThu);
            this.panel33.Controls.Add(this.label17);
            this.panel33.ForeColor = System.Drawing.Color.Black;
            this.panel33.Location = new System.Drawing.Point(621, 10);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(289, 60);
            this.panel33.TabIndex = 4;
            // 
            // btnDoanhThu
            // 
            this.btnDoanhThu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnDoanhThu.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDoanhThu.ForeColor = System.Drawing.Color.Black;
            this.btnDoanhThu.Location = new System.Drawing.Point(211, 7);
            this.btnDoanhThu.Name = "btnDoanhThu";
            this.btnDoanhThu.Size = new System.Drawing.Size(75, 53);
            this.btnDoanhThu.TabIndex = 1;
            this.btnDoanhThu.Text = "MỞ FILE";
            this.btnDoanhThu.UseVisualStyleBackColor = false;
            this.btnDoanhThu.Click += new System.EventHandler(this.btnDoanhThu_Click_1);
            // 
            // label17
            // 
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(15, 6);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(156, 52);
            this.label17.TabIndex = 0;
            this.label17.Text = "DOANH THU:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label17.Click += new System.EventHandler(this.label17_Click_1);
            // 
            // quanlyxuatfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 472);
            this.Controls.Add(this.panel21);
            this.Controls.Add(this.panel20);
            this.Controls.Add(this.panel30);
            this.Name = "quanlyxuatfile";
            this.Text = "quanlyxuatfile";
            this.panel30.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Button btnLamMoiTopSanPham;
        private System.Windows.Forms.DateTimePicker dtpkToDayTopsanPham;
        private System.Windows.Forms.DateTimePicker dtpkFromDayTopSanPham;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.ListBox listBoxTopSanPham;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Button btnSanPham;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Button btnHoaDonTheoNgay;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Button btnHoaDon;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Button btnDoanhThu;
        private System.Windows.Forms.Label label17;
    }
}