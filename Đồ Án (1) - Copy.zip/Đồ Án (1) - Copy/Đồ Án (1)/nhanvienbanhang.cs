﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Đồ_Án__1_.BUS;
using Đồ_Án__1_.DTO;
using Đồ_Án__1_.Utils;

namespace Đồ_Án__1_
{
    public partial class nhanvienbanhang : Form
    {
        private readonly BanAnBUS banAnBUS = new BanAnBUS();
        private readonly SanPhamBUS sanPhamBUS = new SanPhamBUS();
        private readonly LoaiSanPhamBUS loaiSanPhamBUS = new LoaiSanPhamBUS();
        private readonly HoaDonBUS hoaDonBUS = new HoaDonBUS();
        private readonly ChiTietHoaDonBUS chiTietHoaDonBUS = new ChiTietHoaDonBUS();

        // Lớp lưu thông tin giỏ hàng (có lưu % giảm giá riêng cho từng món)
        private class GioHangItem
        {
            public ChiTietHoaDonDTO ChiTiet { get; set; }
            public decimal PhanTramGiam { get; set; } // 0-100

            public decimal TinhThanhTien()
            {
                decimal thanhTienGoc = ChiTiet.DonGia * ChiTiet.SoLuong;
                return thanhTienGoc * (1 - PhanTramGiam / 100);
            }
        }

        private List<GioHangItem> gioHang = new List<GioHangItem>();
        private BanAnDTO banDaChon = null;
        private Form formChiTietHoaDon = null;
        private Form formQuanLyHoaDon = null;

        // Label hiển thị thông tin sản phẩm được chọn
        private Label lblGiaSanPham = new Label();
        private Label lblTonKho = new Label();

        public nhanvienbanhang()
        {
            InitializeComponent();
            InitializeCustomControls();
            this.Load += Nhanvienbanhang_Load;
            this.FormClosing += Nhanvienbanhang_FormClosing;
        }

        #region Khởi tạo giao diện

        private void InitializeCustomControls()
        {
            // Khởi tạo các label tổng tiền
            lblTongTien.Font = new Font("Segoe UI", 10, FontStyle.Bold);
            lblTongTien.ForeColor = Color.FromArgb(70, 70, 70);
            lblTongTien.Location = new Point(10, 230);
            lblTongTien.Size = new Size(200, 25);

            lblTienGiam.Font = new Font("Segoe UI", 9);
            lblTienGiam.ForeColor = Color.Red;
            lblTienGiam.Location = new Point(10, 255);
            lblTienGiam.Size = new Size(200, 20);

            lblThanhToan.Font = new Font("Segoe UI", 12, FontStyle.Bold);
            lblThanhToan.ForeColor = Color.FromArgb(211, 47, 47);
            lblThanhToan.Location = new Point(10, 280);
            lblThanhToan.Size = new Size(250, 30);

            panel2.Controls.Add(lblTongTien);
            panel2.Controls.Add(lblTienGiam);
            panel2.Controls.Add(lblThanhToan);

            // Khởi tạo label hiển thị giá và tồn kho sản phẩm được chọn
            lblGiaSanPham.Font = new Font("Segoe UI", 9);
            lblGiaSanPham.ForeColor = Color.FromArgb(211, 47, 47);
            lblGiaSanPham.Location = new Point(3, 70);
            lblGiaSanPham.Size = new Size(150, 20);

            lblTonKho.Font = new Font("Segoe UI", 9);
            lblTonKho.ForeColor = Color.FromArgb(70, 70, 70);
            lblTonKho.Location = new Point(160, 70);
            lblTonKho.Size = new Size(150, 20);

            panel4.Controls.Add(lblGiaSanPham);
            panel4.Controls.Add(lblTonKho);
        }

        private void SetupNumericUpDown()
        {
            numericUpDown1.Minimum = 1;
            numericUpDown1.Maximum = 100;
            numericUpDown1.Value = 1;

            numericUpDown2.Minimum = 0;
            numericUpDown2.Maximum = 100;
            numericUpDown2.Value = 0;
        }

        private void SetupTextBoxGiamGia()
        {
            tbGiamGia.Text = "0";
            tbGiamGia.TextAlign = HorizontalAlignment.Right;
        }

        private void InitListView()
        {
            listView1.View = View.Details;
            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            listView1.Font = new Font("Segoe UI", 10);
            listView1.Columns.Clear();
            listView1.Columns.Add("Mã SP", 80);
            listView1.Columns.Add("Tên sản phẩm", 200);
            listView1.Columns.Add("Số lượng", 70, HorizontalAlignment.Center);
            listView1.Columns.Add("Đơn giá", 100, HorizontalAlignment.Right);
            listView1.Columns.Add("Thành tiền", 120, HorizontalAlignment.Right);
            listView1.Columns.Add("Ghi chú", 150);
            listView1.MultiSelect = false;
        }

        private void Nhanvienbanhang_Load(object sender, EventArgs e)
        {
            if (!SessionManager.CanSell)
            {
                MessageBox.Show("Bạn không có quyền truy cập chức năng này!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
                return;
            }

            InitListView();
            SetupNumericUpDown();
            SetupTextBoxGiamGia();
            LoadDanhSachBan();
            LoadDanhMucSanPham();
            LoadComboChuyenBan();
        }

        private void Nhanvienbanhang_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (formChiTietHoaDon != null && !formChiTietHoaDon.IsDisposed)
            {
                formChiTietHoaDon.Close();
            }
            if (formQuanLyHoaDon != null && !formQuanLyHoaDon.IsDisposed)
            {
                formQuanLyHoaDon.Close();
            }
        }

        #endregion

        #region Quản lý bàn ăn

        private void LoadDanhSachBan()
        {
            try
            {
                List<BanAnDTO> danhSachBan = banAnBUS.LayDanhSachBan();
                flowLayoutPanel1.Controls.Clear();
                flowLayoutPanel1.AutoScroll = true;
                flowLayoutPanel1.WrapContents = true;

                foreach (BanAnDTO ban in danhSachBan)
                {
                    Button btnBan = TaoButtonBan(ban);
                    flowLayoutPanel1.Controls.Add(btnBan);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải bàn: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Tạo button cho một bàn (tách riêng để dùng lại)
        /// </summary>
        private Button TaoButtonBan(BanAnDTO ban)
        {
            Button btnBan = new Button();
            btnBan.Size = new Size(100, 70);
            btnBan.Tag = ban;
            btnBan.Click += BtnBan_Click;
            btnBan.Font = new Font("Arial", 9, FontStyle.Bold);

            switch (ban.TrangThai)
            {
                case 0:
                    btnBan.BackColor = Color.LightGreen;
                    btnBan.Text = ban.TenBan + "\nTRỐNG";
                    break;
                case 1:
                    btnBan.BackColor = Color.Gold;
                    btnBan.Text = ban.TenBan + "\nĐANG DÙNG";
                    break;
                case 2:
                    btnBan.BackColor = Color.LightCoral;
                    btnBan.Text = ban.TenBan + "\nCẦN DỌN";
                    break;
            }

            return btnBan;
        }

        /// <summary>
        /// Cập nhật màu sắc và trạng thái của button bàn ngay lập tức
        /// </summary>
        private void CapNhatMauButtonBan(int idBan, int trangThaiMoi)
        {
            foreach (Control ctrl in flowLayoutPanel1.Controls)
            {
                if (ctrl is Button btn && btn.Tag is BanAnDTO ban)
                {
                    if (ban.IDBan == idBan)
                    {
                        ban.TrangThai = trangThaiMoi;

                        switch (trangThaiMoi)
                        {
                            case 0:
                                btn.BackColor = Color.LightGreen;
                                btn.Text = ban.TenBan + "\nTRỐNG";
                                break;
                            case 1:
                                btn.BackColor = Color.Gold;
                                btn.Text = ban.TenBan + "\nĐANG DÙNG";
                                break;
                            case 2:
                                btn.BackColor = Color.LightCoral;
                                btn.Text = ban.TenBan + "\nCẦN DỌN";
                                break;
                        }
                        btn.Font = new Font("Arial", 9, FontStyle.Bold);
                        break;
                    }
                }
            }
        }

        private void BtnBan_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            BanAnDTO ban = btn.Tag as BanAnDTO;

            if (ban.TrangThai == 0)
            {
                ChonBanTrong(ban);
            }
            else if (ban.TrangThai == 1)
            {
                ChonBanDangDung(ban);
            }
            else if (ban.TrangThai == 2)
            {
                DonBan(ban);
            }
        }

        private void ChonBanTrong(BanAnDTO ban)
        {
            if (gioHang.Count > 0 && banDaChon != null)
            {
                DialogResult dr = MessageBox.Show(
                    $"Bạn đang có đơn hàng cho bàn {banDaChon.TenBan}.\n" +
                    "Chọn bàn mới sẽ xóa đơn hàng hiện tại. Tiếp tục?",
                    "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (dr != DialogResult.Yes) return;
                XoaGioHang();
            }

            banDaChon = ban;
            XoaGioHang();

            MessageBox.Show($"Đã chọn bàn: {ban.TenBan}\nHãy bắt đầu thêm món!",
                "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

            HighlightBanDaChon(ban.IDBan);
        }

        private void ChonBanDangDung(BanAnDTO ban)
        {
            DialogResult dr = MessageBox.Show(
                $"Bàn {ban.TenBan} đang có khách.\nBạn có muốn gọi thêm món cho bàn này không?\n\n" +
                "(Lưu ý: Sẽ tạo hóa đơn MỚI, không cộng dồn vào hóa đơn cũ)",
                "Xác nhận gọi món",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {
                if (gioHang.Count > 0 && banDaChon != null && banDaChon.IDBan != ban.IDBan)
                {
                    DialogResult drGioHang = MessageBox.Show(
                        $"Bạn đang có đơn hàng cho bàn {banDaChon.TenBan}.\n" +
                        "Chọn bàn mới sẽ xóa đơn hàng hiện tại. Tiếp tục?",
                        "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (drGioHang != DialogResult.Yes) return;
                    XoaGioHang();
                }

                banDaChon = ban;

                MessageBox.Show($"Đã chọn bàn: {ban.TenBan}\nHãy bắt đầu thêm món cho hóa đơn MỚI!",
                    "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                HighlightBanDaChon(ban.IDBan);
            }
        }

        private void DonBan(BanAnDTO ban)
        {
            DialogResult dr = MessageBox.Show($"Dọn bàn {ban.TenBan}?",
                "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {
                try
                {
                    banAnBUS.DonBan(ban.IDBan);

                    // GHI LOG DỌN BÀN
                    LogHelper.LogDonBan(ban.IDBan, ban.TenBan);

                    CapNhatMauButtonBan(ban.IDBan, 0);
                    LoadComboChuyenBan();

                    if (banDaChon != null && banDaChon.IDBan == ban.IDBan)
                    {
                        XoaGioHang();
                        banDaChon = null;
                    }

                    MessageBox.Show($"Đã dọn bàn {ban.TenBan}!",
                        "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void HighlightBanDaChon(int idBan)
        {
            foreach (Control ctrl in flowLayoutPanel1.Controls)
            {
                if (ctrl is Button btn && btn.Tag is BanAnDTO ban)
                {
                    if (ban.IDBan == idBan)
                    {
                        btn.BackColor = Color.LimeGreen;
                        btn.FlatStyle = FlatStyle.Standard;
                        btn.Font = new Font("Arial", 9, FontStyle.Bold | FontStyle.Underline);
                    }
                    else if (ban.TrangThai == 0)
                    {
                        btn.BackColor = Color.LightGreen;
                        btn.FlatStyle = FlatStyle.Standard;
                        btn.Font = new Font("Arial", 9, FontStyle.Bold);
                    }
                    else if (ban.TrangThai == 1)
                    {
                        btn.BackColor = Color.Gold;
                        btn.FlatStyle = FlatStyle.Standard;
                        btn.Font = new Font("Arial", 9, FontStyle.Bold);
                    }
                    else if (ban.TrangThai == 2)
                    {
                        btn.BackColor = Color.LightCoral;
                        btn.FlatStyle = FlatStyle.Standard;
                        btn.Font = new Font("Arial", 9, FontStyle.Bold);
                    }
                }
            }
        }

        #endregion

        #region Quản lý sản phẩm

        private void LoadDanhMucSanPham()
        {
            try
            {
                List<LoaiSanPhamDTO> danhMuc = loaiSanPhamBUS.LayDanhSachDangHoatDong();
                cbcategory.Items.Clear();
                cbcategory.Items.Add("-- Tất cả --");

                foreach (LoaiSanPhamDTO loai in danhMuc)
                {
                    cbcategory.Items.Add(loai.TenLoai);
                }
                cbcategory.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh mục: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadSanPhamTheoLoai(int? idLoai = null)
        {
            try
            {
                List<SanPhamDTO> danhSach = sanPhamBUS.LayDanhSachSanPham();

                if (idLoai.HasValue && idLoai.Value > 0)
                {
                    danhSach = danhSach.Where(sp => sp.IDLoai == idLoai.Value).ToList();
                }

                cbmonan.Items.Clear();
                cbmonan.DisplayMember = "TenSanPham";

                foreach (SanPhamDTO sp in danhSach)
                {
                    cbmonan.Items.Add(sp);
                }

                if (cbmonan.Items.Count > 0)
                    cbmonan.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải sản phẩm: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbcategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbcategory.SelectedIndex == 0)
            {
                LoadSanPhamTheoLoai(null);
            }
            else
            {
                string tenLoai = cbcategory.SelectedItem.ToString();
                List<LoaiSanPhamDTO> danhMuc = loaiSanPhamBUS.LayDanhSachDangHoatDong();
                LoaiSanPhamDTO loai = danhMuc.FirstOrDefault(l => l.TenLoai == tenLoai);

                if (loai != null)
                    LoadSanPhamTheoLoai(loai.IDLoai);
            }
        }

        private void cbmonan_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbmonan.SelectedItem is SanPhamDTO sp)
            {
                lblGiaSanPham.Text = $"💰 Giá: {sp.GiaBan:N0} đ";
                lblTonKho.Text = $"📦 Tồn kho: {sp.SoLuongTon}";
                lblTonKho.ForeColor = sp.SoLuongTon <= sp.TonToiThieu ? Color.Orange : Color.FromArgb(70, 70, 70);
            }
        }

        #endregion

        #region Giỏ hàng

        private void CapNhatGioHangListView()
        {
            listView1.Items.Clear();
            decimal tongTien = 0;

            foreach (GioHangItem item in gioHang)
            {
                decimal thanhTien = item.TinhThanhTien();
                ListViewItem lvi = new ListViewItem(item.ChiTiet.MaSanPham);
                lvi.SubItems.Add(item.ChiTiet.TenSanPham);
                lvi.SubItems.Add(item.ChiTiet.SoLuong.ToString());
                lvi.SubItems.Add(string.Format("{0:N0} đ", item.ChiTiet.DonGia));
                lvi.SubItems.Add(string.Format("{0:N0} đ", thanhTien));

                string ghiChu = item.ChiTiet.GhiChu ?? "";
                if (item.PhanTramGiam > 0 && !ghiChu.Contains($"giảm {item.PhanTramGiam}%"))
                {
                    ghiChu = string.IsNullOrEmpty(ghiChu)
                        ? $"Giảm {item.PhanTramGiam}%"
                        : $"{ghiChu}, giảm {item.PhanTramGiam}%";
                }
                lvi.SubItems.Add(ghiChu);
                lvi.Tag = item;

                listView1.Items.Add(lvi);
                tongTien += thanhTien;
            }

            decimal phanTramGiamToanBo = GetPhanTramGiamGia();
            decimal tienGiamToanBo = tongTien * phanTramGiamToanBo / 100;
            decimal tongSauGiam = tongTien - tienGiamToanBo;

            lblTongTien.Text = string.Format("Tổng tiền: {0:N0} đ", tongTien);
            lblTienGiam.Text = phanTramGiamToanBo > 0 ? string.Format("Giảm {0}% toàn bộ: -{1:N0} đ", phanTramGiamToanBo, tienGiamToanBo) : "";
            lblThanhToan.Text = string.Format("Thanh toán: {0:N0} đ", tongSauGiam);
        }

        private decimal GetPhanTramGiamGia()
        {
            if (string.IsNullOrWhiteSpace(tbGiamGia.Text))
                return 0;

            if (decimal.TryParse(tbGiamGia.Text, out decimal phanTram))
            {
                if (phanTram < 0) return 0;
                if (phanTram > 100) return 100;
                return phanTram;
            }
            return 0;
        }

        private decimal TinhTongTienSauGiam()
        {
            decimal tongTienGoc = 0;
            foreach (GioHangItem item in gioHang)
            {
                tongTienGoc += item.TinhThanhTien();
            }
            decimal phanTramGiamToanBo = GetPhanTramGiamGia();
            return tongTienGoc * (1 - phanTramGiamToanBo / 100);
        }

        private void XoaGioHang()
        {
            gioHang.Clear();
            tbGiamGia.Text = "0";
            CapNhatGioHangListView();
        }

        private void btnthemmon_Click(object sender, EventArgs e)
        {
            if (cbmonan.SelectedItem == null)
            {
                MessageBox.Show("Vui lòng chọn sản phẩm!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (banDaChon == null)
            {
                MessageBox.Show("Vui lòng chọn bàn trước khi thêm món!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SanPhamDTO sp = cbmonan.SelectedItem as SanPhamDTO;
            int soLuong = (int)numericUpDown1.Value;

            if (soLuong <= 0)
            {
                MessageBox.Show("Số lượng phải lớn hơn 0!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (sp.SoLuongTon < soLuong)
            {
                MessageBox.Show($"Sản phẩm {sp.TenSanPham} chỉ còn {sp.SoLuongTon} sản phẩm!",
                    "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Tìm món đã có trong giỏ
            GioHangItem existing = gioHang.FirstOrDefault(item => item.ChiTiet.IDSanPham == sp.IDSanPham);

            if (existing != null)
            {
                existing.ChiTiet.SoLuong += soLuong;
            }
            else
            {
                ChiTietHoaDonDTO chiTiet = new ChiTietHoaDonDTO
                {
                    IDSanPham = sp.IDSanPham,
                    MaSanPham = sp.MaSanPham,
                    TenSanPham = sp.TenSanPham,
                    SoLuong = soLuong,
                    DonGia = sp.GiaBan,
                    ThanhTien = sp.GiaBan * soLuong,
                    GhiChu = null
                };

                gioHang.Add(new GioHangItem
                {
                    ChiTiet = chiTiet,
                    PhanTramGiam = 0
                });
            }

            CapNhatGioHangListView();
            numericUpDown1.Value = 1;
        }

        private void btnHuyDonHang_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn món cần hủy!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ListViewItem selectedItem = listView1.SelectedItems[0];
            GioHangItem item = selectedItem.Tag as GioHangItem;
            int soLuongHuy = (int)numericUpDown2.Value;

            if (soLuongHuy <= 0)
            {
                MessageBox.Show("Số lượng hủy phải lớn hơn 0!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (item.ChiTiet.SoLuong <= soLuongHuy)
            {
                gioHang.Remove(item);
            }
            else
            {
                item.ChiTiet.SoLuong -= soLuongHuy;
            }

            CapNhatGioHangListView();
            numericUpDown2.Value = 0;
        }

        private void btngiamgia_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn món cần giảm giá!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ListViewItem selectedItem = listView1.SelectedItems[0];
            GioHangItem item = selectedItem.Tag as GioHangItem;
            decimal phanTramGiam = GetPhanTramGiamGia();

            if (phanTramGiam <= 0)
            {
                MessageBox.Show("Vui lòng nhập phần trăm giảm giá (1-100)!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            item.PhanTramGiam = phanTramGiam;
            item.ChiTiet.GhiChu = string.IsNullOrEmpty(item.ChiTiet.GhiChu)
                ? $"Giảm {phanTramGiam}%"
                : item.ChiTiet.GhiChu + $", giảm {phanTramGiam}%";

            CapNhatGioHangListView();
            tbGiamGia.Text = "0";

            MessageBox.Show($"Đã giảm {phanTramGiam}% cho món {item.ChiTiet.TenSanPham}!",
                "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void tbGiamGia_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(tbGiamGia.Text))
            {
                if (decimal.TryParse(tbGiamGia.Text, out decimal value))
                {
                    if (value > 100)
                    {
                        tbGiamGia.Text = "100";
                        tbGiamGia.SelectionStart = tbGiamGia.Text.Length;
                    }
                    else if (value < 0)
                    {
                        tbGiamGia.Text = "0";
                        tbGiamGia.SelectionStart = tbGiamGia.Text.Length;
                    }
                }
            }
            CapNhatGioHangListView();
        }

        #endregion

        #region Thanh toán

        private void btnthanhtoan_Click(object sender, EventArgs e)
        {
            if (gioHang.Count == 0)
            {
                MessageBox.Show("Giỏ hàng trống! Hãy thêm món trước khi thanh toán.",
                    "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (banDaChon == null)
            {
                MessageBox.Show("Vui lòng chọn bàn trước khi thanh toán!",
                    "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string maHoaDon = "";
                int idHoaDon = 0;
                decimal tongTien = TinhTongTienSauGiam();

                HoaDonDTO hoaDon = new HoaDonDTO
                {
                    LoaiDon = 1,
                    IDNhanVien = SessionManager.GetCurrentUserId(),
                    IDKhachHang = null,
                    IDBan = banDaChon.IDBan,
                    PhuongThucThanhToan = "Tiền mặt",
                    GhiChu = null
                };

                // Tạo danh sách chi tiết để lưu vào database
                List<ChiTietHoaDonDTO> chiTietLuu = new List<ChiTietHoaDonDTO>();
                foreach (GioHangItem item in gioHang)
                {
                    ChiTietHoaDonDTO ct = new ChiTietHoaDonDTO
                    {
                        IDSanPham = item.ChiTiet.IDSanPham,
                        MaSanPham = item.ChiTiet.MaSanPham,
                        TenSanPham = item.ChiTiet.TenSanPham,
                        SoLuong = item.ChiTiet.SoLuong,
                        DonGia = item.ChiTiet.DonGia,
                        ThanhTien = item.TinhThanhTien(),
                        GhiChu = item.ChiTiet.GhiChu
                    };
                    chiTietLuu.Add(ct);
                }

                // Tạo hóa đơn
                idHoaDon = hoaDonBUS.TaoHoaDon(hoaDon, chiTietLuu, out maHoaDon);

                // Cập nhật trạng thái hóa đơn thành ĐÃ THANH TOÁN
                bool thanhToanThanhCong = hoaDonBUS.HoanTatThanhToan(idHoaDon, "Tiền mặt");

                if (thanhToanThanhCong)
                {
                    // GHI LOG THANH TOÁN
                    LogHelper.LogThanhToan(idHoaDon, maHoaDon, tongTien, banDaChon.TenBan);

                    // Mở form xem chi tiết hóa đơn
                    MoFormChiTietHoaDon(idHoaDon, maHoaDon);

                    // Luôn cập nhật bàn thành ĐANG DÙNG (trạng thái 1) sau mỗi lần thanh toán
                    if (banDaChon.TrangThai != 1)
                    {
                        banAnBUS.CapNhatTrangThai(banDaChon.IDBan, 1);
                    }
                    banDaChon.TrangThai = 1;

                    // Cập nhật màu button bàn NGAY LẬP TỨC
                    CapNhatMauButtonBan(banDaChon.IDBan, 1);

                    // Cập nhật lại combo chuyển bàn
                    LoadComboChuyenBan();

                    MessageBox.Show($"Thanh toán thành công!\nMã hóa đơn: {maHoaDon}\nTổng tiền: {tongTien:N0} đ",
                        "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Xóa giỏ hàng
                    XoaGioHang();
                    tbGiamGia.Text = "0";
                }
                else
                {
                    MessageBox.Show("Cập nhật thanh toán thất bại! Hóa đơn chưa được ghi nhận.",
                        "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi thanh toán: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MoFormChiTietHoaDon(int idHoaDon, string maHoaDon)
        {
            if (formChiTietHoaDon != null && !formChiTietHoaDon.IsDisposed)
            {
                formChiTietHoaDon.Close();
            }

            formChiTietHoaDon = new chitiethoadon(idHoaDon, maHoaDon);
            formChiTietHoaDon.FormClosed += (s, args) => formChiTietHoaDon = null;
            formChiTietHoaDon.ShowDialog();
        }

        #endregion

        #region Chuyển trạng thái bàn

        private void LoadComboChuyenBan()
        {
            try
            {
                List<BanAnDTO> tatCaBan = banAnBUS.LayDanhSachBan();
                List<BanAnDTO> banDangDung = tatCaBan.Where(b => b.TrangThai == 1).ToList();

                cbchuyenban.Items.Clear();
                cbchuyenban.DisplayMember = "TenBan";

                foreach (BanAnDTO ban in banDangDung)
                {
                    cbchuyenban.Items.Add(ban);
                }

                if (cbchuyenban.Items.Count > 0)
                    cbchuyenban.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách bàn: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bntchuyenban_Click(object sender, EventArgs e)
        {
            if (cbchuyenban.Items.Count == 0)
            {
                MessageBox.Show("Hiện không có bàn nào đang có khách để chuyển trạng thái!",
                    "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            BanAnDTO banCanDon = cbchuyenban.SelectedItem as BanAnDTO;
            if (banCanDon == null) return;

            DialogResult dr = MessageBox.Show(
                $"Chuyển bàn {banCanDon.TenBan} từ trạng thái ĐANG DÙNG sang CẦN DỌN?",
                "XÁC NHẬN CHUYỂN TRẠNG THÁI",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {
                try
                {
                    bool ketQua = banAnBUS.CapNhatTrangThai(banCanDon.IDBan, 2);

                    if (ketQua)
                    {
                        // GHI LOG CHUYỂN BÀN
                        LogHelper.LogChuyenBan(banCanDon.IDBan, banCanDon.TenBan, 2);

                        CapNhatMauButtonBan(banCanDon.IDBan, 2);

                        if (banDaChon != null && banDaChon.IDBan == banCanDon.IDBan)
                        {
                            XoaGioHang();
                            banDaChon = null;
                        }

                        LoadComboChuyenBan();

                        MessageBox.Show($"Đã chuyển bàn {banCanDon.TenBan} sang trạng thái CẦN DỌN!\n" +
                            "Hãy dọn bàn sạch sẽ và ấn vào bàn để hoàn tất.",
                            "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Cập nhật trạng thái bàn thất bại!", "Lỗi",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        #endregion

        #region Menu Strip Events

        private void quanlyToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (SessionManager.IsAdmin)
            {
                this.Hide();
                quanly frmQuanLy = new quanly(this);
                frmQuanLy.FormClosed += (s, args) => this.Show();
                frmQuanLy.Show();
            }
            else
            {
                MessageBox.Show("Bạn không có quyền truy cập quản lý!",
                    "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void thôngTinCáNhânToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            thongtinnhanvien frmThongTin = new thongtinnhanvien();
            frmThongTin.ShowDialog();
        }

        private void đăngXuấtToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muốn đăng xuất?",
                "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {
                SessionManager.DangXuat();

                if (formChiTietHoaDon != null && !formChiTietHoaDon.IsDisposed)
                {
                    formChiTietHoaDon.Close();
                }
                if (formQuanLyHoaDon != null && !formQuanLyHoaDon.IsDisposed)
                {
                    formQuanLyHoaDon.Close();
                }

                this.Close();

                dangnhap frmDangNhap = new dangnhap();
                frmDangNhap.Show();
            }
        }

        private void quảnLýToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        #endregion

        #region Các sự kiện khác

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e) { }
        private void panel4_Paint(object sender, PaintEventArgs e) { }
        private void panel2_Paint(object sender, PaintEventArgs e) { }
        private void panel3_Paint(object sender, PaintEventArgs e) { }
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            btngiamgia.Enabled = (listView1.SelectedItems.Count > 0);
            btnHuyDonHang.Enabled = (listView1.SelectedItems.Count > 0);
        }
        private void numericUpDown1_ValueChanged(object sender, EventArgs e) { }
        private void numericUpDown2_ValueChanged(object sender, EventArgs e) { }
        private void cbchuyenban_SelectedIndexChanged(object sender, EventArgs e) { }

        #endregion

        // Các label tổng tiền
        private Label lblTongTien = new Label();
        private Label lblTienGiam = new Label();
        private Label lblThanhToan = new Label();

        private void đơnChờXácNhậnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Ẩn form hiện tại (form gọi menu này)
            this.Hide();

            // Tạo và mở form mới
            nhanvienxacnhan formNVXN = new nhanvienxacnhan();

            // Khi form mới đóng, sẽ show lại form chính
            formNVXN.FormClosed += (s, args) => this.Show();

            formNVXN.Show();
        }

        private void chiTiếtSảnPhẩmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Ẩn form hiện tại
            this.Hide();

            // Tạo và mở form mới
            chitietsanpham formCTSP = new chitietsanpham();

            // Khi form mới đóng, show lại form chính
            formCTSP.FormClosed += (s, args) => this.Show();

            formCTSP.Show();
        }

        private void chiTiếtSảnPhẩmToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            // Ẩn form hiện tại
            this.Hide();

            // Tạo và mở form mới
            chitietsanpham formCTSP = new chitietsanpham();

            // Khi form mới đóng, show lại form chính
            formCTSP.FormClosed += (s, args) => this.Show();

            formCTSP.Show();
        }
        
    }
}