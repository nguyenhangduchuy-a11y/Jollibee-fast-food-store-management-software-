﻿using System;
using System.Windows.Forms;
using Đồ_Án__1_.BUS;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_
{
    public partial class doimatkhau : Form
    {
        private readonly NguoiDungBUS nguoiDungBUS = new NguoiDungBUS();
        private dangnhap loginForm;

        public doimatkhau()
        {
            InitializeComponent();
            SetupPasswordChars();
        }

        public doimatkhau(dangnhap loginForm) : this()
        {
            this.loginForm = loginForm;
        }

        private void SetupPasswordChars()
        {
            if (nhapmk != null)
            {
                nhapmk.PasswordChar = '*';
            }
            if (xacnhanmk != null)
            {
                xacnhanmk.PasswordChar = '*';
            }
        }

        private void xacnhan_Click(object sender, EventArgs e)
        {
            try
            {
                string tenDangNhap = nhaptaikhoan.Text.Trim();
                string matKhauCu = nhapmk.Text;
                string matKhauMoi = xacnhanmk.Text;  // Ô xác nhận dùng làm mật khẩu mới

                // Kiểm tra các trường nhập
                if (string.IsNullOrWhiteSpace(tenDangNhap))
                {
                    MessageBox.Show("Vui lòng nhập tên đăng nhập!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    nhaptaikhoan.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(matKhauCu))
                {
                    MessageBox.Show("Vui lòng nhập mật khẩu cũ!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    nhapmk.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(matKhauMoi))
                {
                    MessageBox.Show("Vui lòng nhập mật khẩu mới!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    xacnhanmk.Focus();
                    return;
                }

                if (matKhauMoi.Length < 6)
                {
                    MessageBox.Show("Mật khẩu mới phải có ít nhất 6 ký tự!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    xacnhanmk.Clear();
                    xacnhanmk.Focus();
                    return;
                }

                if (matKhauCu == matKhauMoi)
                {
                    MessageBox.Show("Mật khẩu mới phải khác mật khẩu cũ!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    xacnhanmk.Clear();
                    xacnhanmk.Focus();
                    return;
                }

                // Đăng nhập để lấy ID người dùng
                NguoiDungDTO nguoiDung = nguoiDungBUS.DangNhap(tenDangNhap, matKhauCu);

                if (nguoiDung == null)
                {
                    MessageBox.Show("Tên đăng nhập hoặc mật khẩu cũ không đúng!",
                        "Xác thực thất bại", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    nhapmk.Clear();
                    xacnhanmk.Clear();
                    nhapmk.Focus();
                    return;
                }

                // Đổi mật khẩu
                bool ketQua = nguoiDungBUS.DoiMatKhau(nguoiDung.IDNguoiDung, matKhauCu, matKhauMoi);

                if (ketQua)
                {
                    MessageBox.Show("Đổi mật khẩu thành công!\nVui lòng đăng nhập lại.",
                        "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Quay về form đăng nhập
                    if (loginForm != null)
                    {
                        loginForm.Show();
                    }
                    else
                    {
                        dangnhap login = new dangnhap();
                        login.Show();
                    }
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Đổi mật khẩu thất bại! Vui lòng thử lại.",
                        "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi hệ thống",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void thoat_Click(object sender, EventArgs e)
        {
            // Quay về form đăng nhập
            if (loginForm != null)
            {
                loginForm.Show();
            }
            else
            {
                dangnhap login = new dangnhap();
                login.Show();
            }
            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            // Hiển thị/ẩn mật khẩu cũ
            if (nhapmk != null)
            {
                nhapmk.PasswordChar = checkBox1.Checked ? '\0' : '*';
            }
        }

        private void cbxacnhanmk_CheckedChanged(object sender, EventArgs e)
        {
            // Hiển thị/ẩn mật khẩu mới
            if (xacnhanmk != null)
            {
                xacnhanmk.PasswordChar = cbxacnhanmk.Checked ? '\0' : '*';
            }
        }

        // Phím Enter để di chuyển giữa các ô
        private void nhaptaikhoan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                nhapmk.Focus();
            }
        }

        private void nhapmk_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                xacnhanmk.Focus();
            }
        }

        private void xacnhanmk_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                xacnhan_Click(sender, e);
            }
        }

        // Các phương thức trống giữ nguyên
        private void panel1_Paint(object sender, PaintEventArgs e) { }
        private void pictureBox1_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void nhaptaikhoan_TextChanged(object sender, EventArgs e) { }
        private void nhapmk_TextChanged(object sender, EventArgs e) { }
        private void xacnhanmk_TextChanged(object sender, EventArgs e) { }
    }
}