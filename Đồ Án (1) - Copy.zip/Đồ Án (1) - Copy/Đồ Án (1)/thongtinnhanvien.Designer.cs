﻿namespace Đồ_Án__1_
{
    partial class thongtinnhanvien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txbTenDangNhap = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txbHoTen = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txbNgayTao = new System.Windows.Forms.TextBox();
            this.txbTrangThai = new System.Windows.Forms.TextBox();
            this.dtpkFromday = new System.Windows.Forms.DateTimePicker();
            this.dtpkToday = new System.Windows.Forms.DateTimePicker();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.listViewRhongTinNhanVien = new System.Windows.Forms.ListView();
            this.btnXuatExcel = new System.Windows.Forms.Button();
            this.btnHoTro = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txbSoDon = new System.Windows.Forms.TextBox();
            this.txbDoanhThu = new System.Windows.Forms.TextBox();
            this.txbTrungBinhDon = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.IndianRed;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(4, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(878, 36);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txbTrangThai);
            this.panel2.Controls.Add(this.txbNgayTao);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txbHoTen);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.txbTenDangNhap);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(4, 44);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(321, 206);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txbTrungBinhDon);
            this.panel3.Controls.Add(this.txbDoanhThu);
            this.panel3.Controls.Add(this.txbSoDon);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Location = new System.Drawing.Point(331, 44);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(551, 206);
            this.panel3.TabIndex = 2;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.listViewRhongTinNhanVien);
            this.panel4.Location = new System.Drawing.Point(4, 256);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(878, 201);
            this.panel4.TabIndex = 3;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(8, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(193, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "🍔Jollibee Việt Nam";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(310, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(225, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "Thông Tin Nhân Viên";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(26, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(225, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "Thông Tin Tài Khoản";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(147, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(225, 23);
            this.label4.TabIndex = 2;
            this.label4.Text = "Thống Kê Hiệu Suất";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 25);
            this.label5.TabIndex = 3;
            this.label5.Text = "Tên Đăng Nhập:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // txbTenDangNhap
            // 
            this.txbTenDangNhap.Location = new System.Drawing.Point(143, 40);
            this.txbTenDangNhap.Name = "txbTenDangNhap";
            this.txbTenDangNhap.Size = new System.Drawing.Size(151, 22);
            this.txbTenDangNhap.TabIndex = 4;
            this.txbTenDangNhap.TextChanged += new System.EventHandler(this.txbTenDangNhap_TextChanged);
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(8, 80);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "Họ Và Tên:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // txbHoTen
            // 
            this.txbHoTen.Location = new System.Drawing.Point(143, 82);
            this.txbHoTen.Name = "txbHoTen";
            this.txbHoTen.Size = new System.Drawing.Size(151, 22);
            this.txbHoTen.TabIndex = 6;
            this.txbHoTen.TextChanged += new System.EventHandler(this.txbHoTen_TextChanged);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 123);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(133, 25);
            this.label7.TabIndex = 7;
            this.label7.Text = "Ngày Tạo:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 159);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 25);
            this.label8.TabIndex = 8;
            this.label8.Text = "Trạng Thái:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // txbNgayTao
            // 
            this.txbNgayTao.Location = new System.Drawing.Point(142, 125);
            this.txbNgayTao.Name = "txbNgayTao";
            this.txbNgayTao.Size = new System.Drawing.Size(151, 22);
            this.txbNgayTao.TabIndex = 9;
            this.txbNgayTao.TextChanged += new System.EventHandler(this.txbNgayTao_TextChanged);
            // 
            // txbTrangThai
            // 
            this.txbTrangThai.Location = new System.Drawing.Point(143, 162);
            this.txbTrangThai.Name = "txbTrangThai";
            this.txbTrangThai.Size = new System.Drawing.Size(151, 22);
            this.txbTrangThai.TabIndex = 10;
            this.txbTrangThai.TextChanged += new System.EventHandler(this.txbTrangThai_TextChanged);
            // 
            // dtpkFromday
            // 
            this.dtpkFromday.Location = new System.Drawing.Point(26, 3);
            this.dtpkFromday.Name = "dtpkFromday";
            this.dtpkFromday.Size = new System.Drawing.Size(200, 22);
            this.dtpkFromday.TabIndex = 1;
            this.dtpkFromday.ValueChanged += new System.EventHandler(this.dtpkFromday_ValueChanged);
            // 
            // dtpkToday
            // 
            this.dtpkToday.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.dtpkToday.CalendarTitleForeColor = System.Drawing.SystemColors.Info;
            this.dtpkToday.Location = new System.Drawing.Point(235, 3);
            this.dtpkToday.Name = "dtpkToday";
            this.dtpkToday.Size = new System.Drawing.Size(200, 22);
            this.dtpkToday.TabIndex = 0;
            this.dtpkToday.ValueChanged += new System.EventHandler(this.dtpkToday_ValueChanged);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnLamMoi);
            this.panel5.Controls.Add(this.dtpkToday);
            this.panel5.Controls.Add(this.dtpkFromday);
            this.panel5.Location = new System.Drawing.Point(3, 26);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(548, 37);
            this.panel5.TabIndex = 3;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // btnLamMoi
            // 
            this.btnLamMoi.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnLamMoi.Location = new System.Drawing.Point(467, 3);
            this.btnLamMoi.Name = "btnLamMoi";
            this.btnLamMoi.Size = new System.Drawing.Size(75, 30);
            this.btnLamMoi.TabIndex = 3;
            this.btnLamMoi.Text = "Làm Mới";
            this.btnLamMoi.UseVisualStyleBackColor = false;
            this.btnLamMoi.Click += new System.EventHandler(this.btnLamMoi_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btnHoTro);
            this.panel6.Controls.Add(this.btnXuatExcel);
            this.panel6.Location = new System.Drawing.Point(5, 463);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(874, 56);
            this.panel6.TabIndex = 4;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // listViewRhongTinNhanVien
            // 
            this.listViewRhongTinNhanVien.HideSelection = false;
            this.listViewRhongTinNhanVien.Location = new System.Drawing.Point(3, 3);
            this.listViewRhongTinNhanVien.Name = "listViewRhongTinNhanVien";
            this.listViewRhongTinNhanVien.Size = new System.Drawing.Size(762, 195);
            this.listViewRhongTinNhanVien.TabIndex = 0;
            this.listViewRhongTinNhanVien.UseCompatibleStateImageBehavior = false;
            this.listViewRhongTinNhanVien.SelectedIndexChanged += new System.EventHandler(this.listViewRhongTinNhanVien_SelectedIndexChanged);
            // 
            // btnXuatExcel
            // 
            this.btnXuatExcel.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnXuatExcel.Location = new System.Drawing.Point(796, 3);
            this.btnXuatExcel.Name = "btnXuatExcel";
            this.btnXuatExcel.Size = new System.Drawing.Size(75, 50);
            this.btnXuatExcel.TabIndex = 4;
            this.btnXuatExcel.Text = "In";
            this.btnXuatExcel.UseVisualStyleBackColor = false;
            this.btnXuatExcel.Click += new System.EventHandler(this.btnXuatExcel_Click);
            // 
            // btnHoTro
            // 
            this.btnHoTro.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnHoTro.Location = new System.Drawing.Point(715, 3);
            this.btnHoTro.Name = "btnHoTro";
            this.btnHoTro.Size = new System.Drawing.Size(75, 53);
            this.btnHoTro.TabIndex = 5;
            this.btnHoTro.Text = "Hỗ Trợ";
            this.btnHoTro.UseVisualStyleBackColor = false;
            this.btnHoTro.Click += new System.EventHandler(this.btnHoTro_Click);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(25, 82);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(81, 25);
            this.label9.TabIndex = 6;
            this.label9.Text = "Số Đơn:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(25, 122);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 25);
            this.label10.TabIndex = 7;
            this.label10.Text = "DoanhThu:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label11
            // 
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 162);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(137, 25);
            this.label11.TabIndex = 8;
            this.label11.Text = "Trung Bình Đơn:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // txbSoDon
            // 
            this.txbSoDon.Location = new System.Drawing.Point(136, 80);
            this.txbSoDon.Name = "txbSoDon";
            this.txbSoDon.Size = new System.Drawing.Size(248, 22);
            this.txbSoDon.TabIndex = 9;
            this.txbSoDon.TextChanged += new System.EventHandler(this.txbSoDon_TextChanged);
            // 
            // txbDoanhThu
            // 
            this.txbDoanhThu.Location = new System.Drawing.Point(136, 122);
            this.txbDoanhThu.Name = "txbDoanhThu";
            this.txbDoanhThu.Size = new System.Drawing.Size(248, 22);
            this.txbDoanhThu.TabIndex = 10;
            this.txbDoanhThu.TextChanged += new System.EventHandler(this.txbDoanhThu_TextChanged);
            // 
            // txbTrungBinhDon
            // 
            this.txbTrungBinhDon.Location = new System.Drawing.Point(136, 162);
            this.txbTrungBinhDon.Name = "txbTrungBinhDon";
            this.txbTrungBinhDon.Size = new System.Drawing.Size(248, 22);
            this.txbTrungBinhDon.TabIndex = 11;
            this.txbTrungBinhDon.TextChanged += new System.EventHandler(this.txbTrungBinhDon_TextChanged);
            // 
            // thongtinnhanvien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(881, 529);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "thongtinnhanvien";
            this.Text = "thongtinnhanvien";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txbTrangThai;
        private System.Windows.Forms.TextBox txbNgayTao;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txbHoTen;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txbTenDangNhap;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DateTimePicker dtpkToday;
        private System.Windows.Forms.DateTimePicker dtpkFromday;
        private System.Windows.Forms.Button btnLamMoi;
        private System.Windows.Forms.ListView listViewRhongTinNhanVien;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btnXuatExcel;
        private System.Windows.Forms.Button btnHoTro;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txbTrungBinhDon;
        private System.Windows.Forms.TextBox txbDoanhThu;
        private System.Windows.Forms.TextBox txbSoDon;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
    }
}