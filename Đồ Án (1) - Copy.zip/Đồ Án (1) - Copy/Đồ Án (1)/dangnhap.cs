﻿using System;
using System.Windows.Forms;
using Đồ_Án__1_.BUS;
using Đồ_Án__1_.DTO;
using Đồ_Án__1_.Utils;

namespace Đồ_Án__1_
{
    public partial class dangnhap : Form
    {
        private readonly NguoiDungBUS nguoiDungBUS = new NguoiDungBUS();
        private readonly LichSuHoatDongBUS logBUS = new LichSuHoatDongBUS();

        public dangnhap()
        {
            InitializeComponent();
            SetupPasswordChar();

            // Ghi log khởi động form đăng nhập
            LogHelper.LogNhanh("Form đăng nhập được mở");
        }

        private void SetupPasswordChar()
        {
            // Giả sử ô nhập mật khẩu tên là nhapmk
            nhapmk.PasswordChar = '*';
        }

        private void dangnhaptc_Click(object sender, EventArgs e)
        {
            try
            {
                string tenDangNhap = nhaptaikhoan.Text.Trim();
                string matKhau = nhapmk.Text;

                // Kiểm tra dữ liệu nhập
                if (string.IsNullOrWhiteSpace(tenDangNhap))
                {
                    MessageBox.Show("Vui lòng nhập tên đăng nhập!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    nhaptaikhoan.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(matKhau))
                {
                    MessageBox.Show("Vui lòng nhập mật khẩu!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    nhapmk.Focus();
                    return;
                }

                // Gọi BUS để đăng nhập
                NguoiDungDTO nguoiDung = nguoiDungBUS.DangNhap(tenDangNhap, matKhau);

                if (nguoiDung == null)
                {
                    // Ghi log đăng nhập thất bại
                    LogHelper.Log("ĐĂNG NHẬP THẤT BẠI", "TÀI KHOẢN", null,
                        $"Đăng nhập thất bại với tài khoản: {tenDangNhap} - Sai tên đăng nhập hoặc mật khẩu");

                    MessageBox.Show("Tên đăng nhập hoặc mật khẩu không đúng!", "Đăng nhập thất bại",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    nhaptaikhoan.Clear();
                    nhapmk.Clear();
                    nhaptaikhoan.Focus();
                    return;
                }

                if (!nguoiDung.KichHoat)
                {
                    // Ghi log tài khoản bị khóa
                    LogHelper.Log("ĐĂNG NHẬP THẤT BẠI", "TÀI KHOẢN", nguoiDung.IDNguoiDung,
                        $"Đăng nhập thất bại - Tài khoản {tenDangNhap} đã bị khóa");

                    MessageBox.Show("Tài khoản của bạn đã bị khóa. Vui lòng liên hệ quản trị viên!",
                        "Tài khoản bị khóa", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Lưu thông tin người dùng vào Session
                SessionManager.DangNhap(nguoiDung);

                // GHI LOG ĐĂNG NHẬP THÀNH CÔNG
                LogHelper.LogDangNhap(nguoiDung.TenDangNhap, nguoiDung.IDNguoiDung);

                // Ghi log thêm thông tin về vai trò
                string vaiTro = "";
                switch (nguoiDung.VaiTro)
                {
                    case 1: vaiTro = "Quản trị viên"; break;
                    case 2: vaiTro = "Nhân viên"; break;
                    case 3: vaiTro = "Khách hàng"; break;
                }
                LogHelper.LogNhanh($"{nguoiDung.HoTen} ({vaiTro}) đã đăng nhập thành công");

                // =============================================
                // PHÂN QUYỀN THEO VAI TRÒ
                // =============================================

                // Vai trò 1: Quản lý (Admin)
                // Vai trò 2: Nhân viên
                if (nguoiDung.VaiTro == 1 || nguoiDung.VaiTro == 2)
                {
                    // Chuyển đến form bán hàng cho nhân viên và quản lý
                    nhanvienbanhang mainForm = new nhanvienbanhang();
                    mainForm.Show();
                    this.Hide();
                }
                // Vai trò 3: Khách hàng
                else if (nguoiDung.VaiTro == 3)
                {
                    // Hiển thị thông báo chào mừng
                    DialogResult result = MessageBox.Show(
                        $"Chào mừng {nguoiDung.HoTen} đến với Jollibee Việt Nam!\n\nChúng tôi rất vui khi được phục vụ bạn!",
                        "Chào mừng đến Jollibee",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    if (result == DialogResult.OK)
                    {
                        // Chuyển đến form chi tiết sản phẩm cho khách hàng
                        // Giả sử form của bạn tên là chitietsanpham
                        // Nếu tên khác, hãy sửa lại cho đúng
                        chitietsanpham productForm = new chitietsanpham();
                        productForm.Show();
                        this.Hide();
                    }
                }
            }
            catch (Exception ex)
            {
                // Ghi log lỗi đăng nhập
                LogHelper.LogLoi("Đăng nhập", ex.Message);

                MessageBox.Show($"Lỗi đăng nhập: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void vaodk_Click(object sender, EventArgs e)
        {
            // Ghi log chuyển sang form đăng ký
            LogHelper.LogNhanh("Người dùng chuyển sang form đăng ký");

            // Chuyển sang form Đăng ký
            dangky registerForm = new dangky();
            registerForm.Show();
            this.Hide();
        }

        private void vaoquenmk_Click(object sender, EventArgs e)
        {
            // Ghi log chuyển sang form đổi mật khẩu
            LogHelper.LogNhanh("Người dùng chuyển sang form đổi mật khẩu");

            // Chuyển sang form Đổi mật khẩu
            doimatkhau forgotPasswordForm = new doimatkhau();
            forgotPasswordForm.Show();
            this.Hide();
        }

        private void thoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn thoát không?",
                "Xác nhận thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // Ghi log thoát ứng dụng (nếu đã đăng nhập)
                if (SessionManager.IsLoggedIn)
                {
                    LogHelper.LogDangXuat();
                }
                else
                {
                    LogHelper.LogNhanh("Thoát ứng dụng từ form đăng nhập");
                }

                Application.Exit();
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            // Hiển thị/ẩn mật khẩu
            nhapmk.PasswordChar = checkBox1.Checked ? '\0' : '*';
        }

        private void nhaptaikhoan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                dangnhaptc.Focus();
            }
        }

        private void nhapmk_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                dangnhaptc_Click(sender, e);
            }
        }

        /// <summary>
        /// Sự kiện khi form đăng nhập đóng
        /// </summary>
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            // Nếu đóng form mà chưa đăng nhập thành công thì không cần ghi log đăng xuất
            if (!SessionManager.IsLoggedIn)
            {
                LogHelper.LogNhanh("Đóng form đăng nhập mà không đăng nhập");
            }
        }

        // Các phương thức giữ nguyên (không xóa)
        private void panel1_Paint(object sender, PaintEventArgs e) { }
        private void pictureBox1_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void nhaptaikhoan_TextChanged(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void nhapmk_TextChanged(object sender, EventArgs e) { }
    }
}