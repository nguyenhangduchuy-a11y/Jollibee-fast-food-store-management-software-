﻿namespace Đồ_Án__1_
{
    partial class nhanvienbanhang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.listView1 = new System.Windows.Forms.ListView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tbGiamGia = new System.Windows.Forms.TextBox();
            this.btnHuyDonHang = new System.Windows.Forms.Button();
            this.cbchuyenban = new System.Windows.Forms.ComboBox();
            this.bntchuyenban = new System.Windows.Forms.Button();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.btngiamgia = new System.Windows.Forms.Button();
            this.btnthanhtoan = new System.Windows.Forms.Button();
            this.btnthemmon = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinCáNhânToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.đăngXuấtToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.quanlyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.đơnChờXácNhậnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.panel4 = new System.Windows.Forms.Panel();
            this.cbmonan = new System.Windows.Forms.ComboBox();
            this.cbcategory = new System.Windows.Forms.ComboBox();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.chiTiếtSảnPhẩmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.listView1);
            this.panel2.Location = new System.Drawing.Point(394, 124);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(412, 235);
            this.panel2.TabIndex = 17;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(0, 3);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(403, 229);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tbGiamGia);
            this.panel3.Controls.Add(this.btnHuyDonHang);
            this.panel3.Controls.Add(this.cbchuyenban);
            this.panel3.Controls.Add(this.bntchuyenban);
            this.panel3.Controls.Add(this.numericUpDown2);
            this.panel3.Controls.Add(this.btngiamgia);
            this.panel3.Controls.Add(this.btnthanhtoan);
            this.panel3.Location = new System.Drawing.Point(394, 365);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(412, 73);
            this.panel3.TabIndex = 18;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // tbGiamGia
            // 
            this.tbGiamGia.Location = new System.Drawing.Point(101, 44);
            this.tbGiamGia.Name = "tbGiamGia";
            this.tbGiamGia.Size = new System.Drawing.Size(100, 22);
            this.tbGiamGia.TabIndex = 9;
            this.tbGiamGia.TextChanged += new System.EventHandler(this.tbGiamGia_TextChanged);
            // 
            // btnHuyDonHang
            // 
            this.btnHuyDonHang.Location = new System.Drawing.Point(216, 14);
            this.btnHuyDonHang.Name = "btnHuyDonHang";
            this.btnHuyDonHang.Size = new System.Drawing.Size(75, 23);
            this.btnHuyDonHang.TabIndex = 8;
            this.btnHuyDonHang.Text = "Hủy";
            this.btnHuyDonHang.UseVisualStyleBackColor = true;
            this.btnHuyDonHang.Click += new System.EventHandler(this.btnHuyDonHang_Click);
            // 
            // cbchuyenban
            // 
            this.cbchuyenban.FormattingEnabled = true;
            this.cbchuyenban.Location = new System.Drawing.Point(3, 45);
            this.cbchuyenban.Name = "cbchuyenban";
            this.cbchuyenban.Size = new System.Drawing.Size(92, 24);
            this.cbchuyenban.TabIndex = 7;
            this.cbchuyenban.SelectedIndexChanged += new System.EventHandler(this.cbchuyenban_SelectedIndexChanged);
            // 
            // bntchuyenban
            // 
            this.bntchuyenban.Location = new System.Drawing.Point(3, 14);
            this.bntchuyenban.Name = "bntchuyenban";
            this.bntchuyenban.Size = new System.Drawing.Size(92, 25);
            this.bntchuyenban.TabIndex = 6;
            this.bntchuyenban.Text = "Chuyển bàn";
            this.bntchuyenban.UseVisualStyleBackColor = true;
            this.bntchuyenban.Click += new System.EventHandler(this.bntchuyenban_Click);
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(216, 45);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(92, 22);
            this.numericUpDown2.TabIndex = 5;
            this.numericUpDown2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDown2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown2.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // btngiamgia
            // 
            this.btngiamgia.Location = new System.Drawing.Point(109, 12);
            this.btngiamgia.Name = "btngiamgia";
            this.btngiamgia.Size = new System.Drawing.Size(92, 25);
            this.btngiamgia.TabIndex = 4;
            this.btngiamgia.Text = "Giảm giá";
            this.btngiamgia.UseVisualStyleBackColor = true;
            this.btngiamgia.Click += new System.EventHandler(this.btngiamgia_Click);
            // 
            // btnthanhtoan
            // 
            this.btnthanhtoan.Location = new System.Drawing.Point(314, 14);
            this.btnthanhtoan.Name = "btnthanhtoan";
            this.btnthanhtoan.Size = new System.Drawing.Size(92, 53);
            this.btnthanhtoan.TabIndex = 3;
            this.btnthanhtoan.Text = "Thanh toán";
            this.btnthanhtoan.UseVisualStyleBackColor = true;
            this.btnthanhtoan.Click += new System.EventHandler(this.btnthanhtoan_Click);
            // 
            // btnthemmon
            // 
            this.btnthemmon.Location = new System.Drawing.Point(247, 12);
            this.btnthemmon.Name = "btnthemmon";
            this.btnthemmon.Size = new System.Drawing.Size(92, 56);
            this.btnthemmon.TabIndex = 2;
            this.btnthemmon.Text = "Thêm món";
            this.btnthemmon.UseVisualStyleBackColor = true;
            this.btnthemmon.Click += new System.EventHandler(this.btnthemmon_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýToolStripMenuItem,
            this.quanlyToolStripMenuItem1,
            this.đơnChờXácNhậnToolStripMenuItem,
            this.chiTiếtSảnPhẩmToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(818, 28);
            this.menuStrip1.TabIndex = 16;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinCáNhânToolStripMenuItem1,
            this.đăngXuấtToolStripMenuItem1});
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(151, 24);
            this.quảnLýToolStripMenuItem.Text = "Thông tin tài khoản";
            this.quảnLýToolStripMenuItem.Click += new System.EventHandler(this.quảnLýToolStripMenuItem_Click);
            // 
            // thôngTinCáNhânToolStripMenuItem1
            // 
            this.thôngTinCáNhânToolStripMenuItem1.Name = "thôngTinCáNhânToolStripMenuItem1";
            this.thôngTinCáNhânToolStripMenuItem1.Size = new System.Drawing.Size(210, 26);
            this.thôngTinCáNhânToolStripMenuItem1.Text = "Thông tin cá nhân";
            this.thôngTinCáNhânToolStripMenuItem1.Click += new System.EventHandler(this.thôngTinCáNhânToolStripMenuItem1_Click);
            // 
            // đăngXuấtToolStripMenuItem1
            // 
            this.đăngXuấtToolStripMenuItem1.Name = "đăngXuấtToolStripMenuItem1";
            this.đăngXuấtToolStripMenuItem1.Size = new System.Drawing.Size(210, 26);
            this.đăngXuấtToolStripMenuItem1.Text = "Đăng xuất";
            this.đăngXuấtToolStripMenuItem1.Click += new System.EventHandler(this.đăngXuấtToolStripMenuItem1_Click);
            // 
            // quanlyToolStripMenuItem1
            // 
            this.quanlyToolStripMenuItem1.Name = "quanlyToolStripMenuItem1";
            this.quanlyToolStripMenuItem1.Size = new System.Drawing.Size(75, 24);
            this.quanlyToolStripMenuItem1.Text = "Quản Lý";
            this.quanlyToolStripMenuItem1.Click += new System.EventHandler(this.quanlyToolStripMenuItem1_Click);
            // 
            // đơnChờXácNhậnToolStripMenuItem
            // 
            this.đơnChờXácNhậnToolStripMenuItem.Name = "đơnChờXácNhậnToolStripMenuItem";
            this.đơnChờXácNhậnToolStripMenuItem.Size = new System.Drawing.Size(148, 24);
            this.đơnChờXácNhậnToolStripMenuItem.Text = "Đơn Chờ Xác Nhận";
            this.đơnChờXácNhậnToolStripMenuItem.Click += new System.EventHandler(this.đơnChờXácNhậnToolStripMenuItem_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(345, 30);
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(61, 22);
            this.numericUpDown1.TabIndex = 3;
            this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.numericUpDown1);
            this.panel4.Controls.Add(this.btnthemmon);
            this.panel4.Controls.Add(this.cbmonan);
            this.panel4.Controls.Add(this.cbcategory);
            this.panel4.Location = new System.Drawing.Point(397, 31);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(412, 86);
            this.panel4.TabIndex = 19;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // cbmonan
            // 
            this.cbmonan.FormattingEnabled = true;
            this.cbmonan.Location = new System.Drawing.Point(3, 44);
            this.cbmonan.Name = "cbmonan";
            this.cbmonan.Size = new System.Drawing.Size(238, 24);
            this.cbmonan.TabIndex = 1;
            this.cbmonan.SelectedIndexChanged += new System.EventHandler(this.cbmonan_SelectedIndexChanged);
            // 
            // cbcategory
            // 
            this.cbcategory.FormattingEnabled = true;
            this.cbcategory.Location = new System.Drawing.Point(3, 14);
            this.cbcategory.Name = "cbcategory";
            this.cbcategory.Size = new System.Drawing.Size(238, 24);
            this.cbcategory.TabIndex = 0;
            this.cbcategory.SelectedIndexChanged += new System.EventHandler(this.cbcategory_SelectedIndexChanged);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(12, 31);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(379, 407);
            this.flowLayoutPanel1.TabIndex = 20;
            this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // chiTiếtSảnPhẩmToolStripMenuItem
            // 
            this.chiTiếtSảnPhẩmToolStripMenuItem.Name = "chiTiếtSảnPhẩmToolStripMenuItem";
            this.chiTiếtSảnPhẩmToolStripMenuItem.Size = new System.Drawing.Size(142, 24);
            this.chiTiếtSảnPhẩmToolStripMenuItem.Text = "Chi Tiết Sản Phẩm";
            this.chiTiếtSảnPhẩmToolStripMenuItem.Click += new System.EventHandler(this.chiTiếtSảnPhẩmToolStripMenuItem_Click_1);
            // 
            // nhanvienbanhang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "nhanvienbanhang";
            this.Text = "nhanvienbanhang";
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox tbGiamGia;
        private System.Windows.Forms.Button btnHuyDonHang;
        private System.Windows.Forms.ComboBox cbchuyenban;
        private System.Windows.Forms.Button bntchuyenban;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Button btngiamgia;
        private System.Windows.Forms.Button btnthanhtoan;
        private System.Windows.Forms.Button btnthemmon;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinCáNhânToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem đăngXuấtToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem quanlyToolStripMenuItem1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox cbmonan;
        private System.Windows.Forms.ComboBox cbcategory;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.ToolStripMenuItem đơnChờXácNhậnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chiTiếtSảnPhẩmToolStripMenuItem;
    }
}