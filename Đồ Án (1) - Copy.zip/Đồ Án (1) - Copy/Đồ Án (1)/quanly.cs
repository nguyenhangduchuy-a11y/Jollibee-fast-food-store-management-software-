﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using Đồ_Án__1_.BUS;
using Đồ_Án__1_.DAL;
using Đồ_Án__1_.DTO;
using Đồ_Án__1_.Utils;
using Excel = Microsoft.Office.Interop.Excel;

namespace Đồ_Án__1_
{
    public partial class quanly : Form
    {
        #region Khai báo BUS
        private readonly SanPhamBUS sanPhamBUS = new SanPhamBUS();
        private readonly LoaiSanPhamBUS loaiSanPhamBUS = new LoaiSanPhamBUS();
        private readonly ThongKeBUS thongKeBUS = new ThongKeBUS();
        private readonly NguoiDungBUS nguoiDungBUS = new NguoiDungBUS();
        private readonly ThongKeDAL thongKeDAL = new ThongKeDAL();
        private readonly LichSuHoatDongBUS lichSuBUS = new LichSuHoatDongBUS();
        #endregion

        #region Biến trạng thái
        private enum Mode { Xem, Them, Sua, Xoa }
        private Mode currentMode = Mode.Xem;
        private SanPhamDTO sanPhamDangChon = null;
        private NguoiDungDTO nhanVienDangChon = null;
        private Form nhanVienBanHangForm = null;
        #endregion

        public quanly()
        {
            InitializeComponent();
            this.Load += Quanly_Load;
            this.FormClosing += Quanly_FormClosing;
        }

        public quanly(Form nhanVienBanHangForm) : this()
        {
            this.nhanVienBanHangForm = nhanVienBanHangForm;
        }

        #region Khởi tạo form
        private void Quanly_Load(object sender, EventArgs e)
        {
            if (!SessionManager.IsAdmin)
            {
                LogHelper.LogCanhBao("Phân quyền", $"{SessionManager.GetCurrentUserName()} cố gắng truy cập Quản lý nhưng không có quyền");
                MessageBox.Show("Bạn không có quyền truy cập chức năng quản lý!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
                return;
            }

            dtpkFromday.Value = DateTime.Today.AddDays(-30);
            dtpkToday.Value = DateTime.Today;
            dtpkFromdaynhanvien.Value = DateTime.Today.AddDays(-30);
            dtpkTodaynhanvien.Value = DateTime.Today;

            // Khởi tạo DateTimePicker cho Tab Hoạt động
            dtpkFromdayHoatDong.Value = DateTime.Today.AddDays(-7);
            dtpkTodayHoatDong.Value = DateTime.Today;

            // Cấu hình ListView Doanh Thu
            CauHinhListViewDoanhThu();
            // Cấu hình ListView Top Sản Phẩm
            CauHinhListViewTopSanPham();
            // Cấu hình ListView Hoạt Động
            CauHinhListViewHoatDong();
            // Load ComboBox hành động
            LoadComboHanhDong();

            LoadDoanhThu();
            LoadTopSanPhamBanChay();
            LoadDanhSachSanPham();
            LoadDanhSachNhanVien();
            LoadDanhSachHoatDong();

            SetXemMode();

            dgvQuanLyThucdon.CellClick += dgvQuanLyThucdon_CellClick;

            LogHelper.LogNhanh($"Admin {SessionManager.GetCurrentUserName()} đã mở form Quản lý");
        }

        private void Quanly_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (nhanVienBanHangForm != null && !nhanVienBanHangForm.IsDisposed)
            {
                nhanVienBanHangForm.Show();
            }
            LogHelper.LogNhanh($"Admin {SessionManager.GetCurrentUserName()} đóng form Quản lý");
        }

        private void SetXemMode()
        {
            currentMode = Mode.Xem;
            SetTextBoxReadOnly(true);
            btnaddfood.Text = "Thêm";
            btnsuafood.Text = "Sửa";
            btnxoafood.Text = "Xóa";
            btnShowFood.Enabled = true;
        }

        private void SetThemMode()
        {
            currentMode = Mode.Them;
            ClearSanPhamTextBoxes();
            SetTextBoxReadOnly(false);
            btnaddfood.Text = "Lưu";
            btnsuafood.Text = "Sửa";
            btnxoafood.Text = "Xóa";
            btnShowFood.Enabled = true;
            txbFoodID.Focus();
        }

        private void SetSuaMode()
        {
            if (sanPhamDangChon == null)
            {
                MessageBox.Show("Vui lòng chọn sản phẩm cần sửa!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                SetXemMode();
                return;
            }
            currentMode = Mode.Sua;
            SetTextBoxReadOnly(false);
            btnaddfood.Text = "Thêm";
            btnsuafood.Text = "Lưu";
            btnxoafood.Text = "Xóa";
            btnShowFood.Enabled = true;
            txbfoodname.Focus();
        }

        private void SetXoaMode()
        {
            if (sanPhamDangChon == null)
            {
                MessageBox.Show("Vui lòng chọn sản phẩm cần xóa!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                SetXemMode();
                return;
            }
            currentMode = Mode.Xoa;
            SetTextBoxReadOnly(true);
            btnaddfood.Text = "Thêm";
            btnsuafood.Text = "Sửa";
            btnxoafood.Text = "Xóa";
            btnShowFood.Enabled = true;
        }

        private void SetTextBoxReadOnly(bool readOnly)
        {
            txbFoodID.ReadOnly = readOnly;
            txbfoodname.ReadOnly = readOnly;
            txbDanhMucFood.ReadOnly = readOnly;
            txbFoodPrice.ReadOnly = readOnly;
            txbSoLuong.ReadOnly = readOnly;
        }

        private void ClearSanPhamTextBoxes()
        {
            txbFoodID.Clear();
            txbfoodname.Clear();
            txbDanhMucFood.Clear();
            txbFoodPrice.Clear();
            txbSoLuong.Clear();
            sanPhamDangChon = null;
        }
        #endregion

        #region Tab Doanh Thu - Sử dụng ListView
        private void CauHinhListViewDoanhThu()
        {
            listViewDoanhThu.View = View.Details;
            listViewDoanhThu.FullRowSelect = true;
            listViewDoanhThu.GridLines = true;
            listViewDoanhThu.Font = new Font("Segoe UI", 11, FontStyle.Regular);
            listViewDoanhThu.BackColor = Color.White;
            listViewDoanhThu.ForeColor = Color.FromArgb(44, 62, 80);

            listViewDoanhThu.Columns.Clear();
            listViewDoanhThu.Columns.Add("Ngày", 120, HorizontalAlignment.Center);
            listViewDoanhThu.Columns.Add("Số đơn", 80, HorizontalAlignment.Center);
            listViewDoanhThu.Columns.Add("Doanh thu", 150, HorizontalAlignment.Right);
            listViewDoanhThu.Columns.Add("Trung bình/đơn", 150, HorizontalAlignment.Right);
            listViewDoanhThu.Columns.Add("Cao nhất", 130, HorizontalAlignment.Right);
            listViewDoanhThu.Columns.Add("Thấp nhất", 130, HorizontalAlignment.Right);

            listViewDoanhThu.OwnerDraw = true;
            listViewDoanhThu.DrawColumnHeader += ListViewDoanhThu_DrawColumnHeader;
            listViewDoanhThu.DrawSubItem += ListViewDoanhThu_DrawSubItem;
            listViewDoanhThu.AllowColumnReorder = false;
        }

        private void CauHinhListViewTopSanPham()
        {
            ListViewTopSanPhamBanChay.View = View.Details;
            ListViewTopSanPhamBanChay.FullRowSelect = true;
            ListViewTopSanPhamBanChay.GridLines = true;
            ListViewTopSanPhamBanChay.Font = new Font("Segoe UI", 11, FontStyle.Regular);
            ListViewTopSanPhamBanChay.BackColor = Color.White;
            ListViewTopSanPhamBanChay.ForeColor = Color.FromArgb(44, 62, 80);

            ListViewTopSanPhamBanChay.Columns.Clear();
            ListViewTopSanPhamBanChay.Columns.Add("Mã SP", 100, HorizontalAlignment.Center);
            ListViewTopSanPhamBanChay.Columns.Add("Tên sản phẩm", 280, HorizontalAlignment.Left);
            ListViewTopSanPhamBanChay.Columns.Add("Số lượng bán", 120, HorizontalAlignment.Center);
            ListViewTopSanPhamBanChay.Columns.Add("Doanh thu", 180, HorizontalAlignment.Right);

            ListViewTopSanPhamBanChay.OwnerDraw = true;
            ListViewTopSanPhamBanChay.DrawColumnHeader += ListViewTopSanPham_DrawColumnHeader;
            ListViewTopSanPhamBanChay.DrawSubItem += ListViewTopSanPham_DrawSubItem;
            ListViewTopSanPhamBanChay.AllowColumnReorder = false;
        }

        private void ListViewDoanhThu_DrawColumnHeader(object sender, DrawListViewColumnHeaderEventArgs e)
        {
            e.DrawBackground();
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(52, 73, 94)))
            {
                e.Graphics.FillRectangle(brush, e.Bounds);
            }

            using (SolidBrush fontBrush = new SolidBrush(Color.White))
            {
                StringFormat sf = new StringFormat();
                sf.Alignment = StringAlignment.Center;
                sf.LineAlignment = StringAlignment.Center;
                e.Graphics.DrawString(e.Header.Text, new Font("Segoe UI", 11, FontStyle.Bold), fontBrush, e.Bounds, sf);
            }
        }

        private void ListViewTopSanPham_DrawColumnHeader(object sender, DrawListViewColumnHeaderEventArgs e)
        {
            e.DrawBackground();
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(52, 73, 94)))
            {
                e.Graphics.FillRectangle(brush, e.Bounds);
            }

            using (SolidBrush fontBrush = new SolidBrush(Color.White))
            {
                StringFormat sf = new StringFormat();
                sf.Alignment = StringAlignment.Center;
                sf.LineAlignment = StringAlignment.Center;
                e.Graphics.DrawString(e.Header.Text, new Font("Segoe UI", 11, FontStyle.Bold), fontBrush, e.Bounds, sf);
            }
        }

        private void ListViewDoanhThu_DrawSubItem(object sender, DrawListViewSubItemEventArgs e)
        {
            e.DrawBackground();

            if (e.ItemIndex % 2 == 0)
            {
                e.Graphics.FillRectangle(new SolidBrush(Color.White), e.Bounds);
            }
            else
            {
                e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(245, 248, 250)), e.Bounds);
            }

            using (SolidBrush fontBrush = new SolidBrush(Color.FromArgb(44, 62, 80)))
            {
                StringFormat sf = new StringFormat();
                if (e.ColumnIndex == 0 || e.ColumnIndex == 1)
                {
                    sf.Alignment = StringAlignment.Center;
                }
                else
                {
                    sf.Alignment = StringAlignment.Far;
                }
                sf.LineAlignment = StringAlignment.Center;

                Font font = new Font("Segoe UI", 10, FontStyle.Regular);
                e.Graphics.DrawString(e.SubItem.Text, font, fontBrush, e.Bounds, sf);
            }
        }

        private void ListViewTopSanPham_DrawSubItem(object sender, DrawListViewSubItemEventArgs e)
        {
            e.DrawBackground();

            if (e.ItemIndex % 2 == 0)
            {
                e.Graphics.FillRectangle(new SolidBrush(Color.White), e.Bounds);
            }
            else
            {
                e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(245, 248, 250)), e.Bounds);
            }

            using (SolidBrush fontBrush = new SolidBrush(Color.FromArgb(44, 62, 80)))
            {
                StringFormat sf = new StringFormat();
                if (e.ColumnIndex == 0)
                {
                    sf.Alignment = StringAlignment.Center;
                }
                else if (e.ColumnIndex == 1)
                {
                    sf.Alignment = StringAlignment.Near;
                }
                else if (e.ColumnIndex == 2)
                {
                    sf.Alignment = StringAlignment.Center;
                }
                else
                {
                    sf.Alignment = StringAlignment.Far;
                }
                sf.LineAlignment = StringAlignment.Center;

                Font font = new Font("Segoe UI", 10, FontStyle.Regular);
                e.Graphics.DrawString(e.SubItem.Text, font, fontBrush, e.Bounds, sf);
            }
        }

        private void LoadDoanhThu()
        {
            try
            {
                DateTime tuNgay = dtpkFromday.Value.Date;
                DateTime denNgay = dtpkToday.Value.Date;

                var doanhThuList = thongKeBUS.BaoCaoDoanhThu(tuNgay, denNgay);

                listViewDoanhThu.Items.Clear();

                foreach (var item in doanhThuList)
                {
                    ListViewItem lvi = new ListViewItem(item.NgayText);
                    lvi.SubItems.Add(item.SoDon.ToString());
                    lvi.SubItems.Add(string.Format("{0:N0} đ", item.DoanhThu));
                    lvi.SubItems.Add(string.Format("{0:N0} đ", item.TrungBinhDon));
                    lvi.SubItems.Add(string.Format("{0:N0} đ", item.DonCaoNhat));
                    lvi.SubItems.Add(string.Format("{0:N0} đ", item.DonThapNhat));

                    if (item.DoanhThu > 1000000)
                    {
                        lvi.ForeColor = Color.Green;
                    }

                    listViewDoanhThu.Items.Add(lvi);
                }

                listViewDoanhThu.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);

                chartDoanhThu.Series.Clear();
                Series series = new Series("Doanh thu");
                series.ChartType = SeriesChartType.Column;

                for (int i = 0; i < doanhThuList.Count; i++)
                {
                    series.Points.AddXY(doanhThuList[i].NgayText, (double)doanhThuList[i].DoanhThu);
                }

                chartDoanhThu.Series.Add(series);
                chartDoanhThu.ChartAreas[0].AxisX.Title = "Ngày";
                chartDoanhThu.ChartAreas[0].AxisY.Title = "Doanh thu (VNĐ)";
                chartDoanhThu.ChartAreas[0].AxisX.Interval = 1;
                chartDoanhThu.ChartAreas[0].AxisX.LabelStyle.Angle = -30;
                chartDoanhThu.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Segoe UI", 8);
                chartDoanhThu.ChartAreas[0].AxisY.LabelStyle.Format = "#,##0";
            }
            catch (Exception ex)
            {
                LogHelper.LogLoi("LoadDoanhThu", ex.Message);
                MessageBox.Show("Lỗi tải doanh thu: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadTopSanPhamBanChay()
        {
            try
            {
                var topList = thongKeBUS.TopSanPhamBanChay(10);

                ListViewTopSanPhamBanChay.Items.Clear();

                foreach (var item in topList)
                {
                    ListViewItem lvi = new ListViewItem(item.MaSanPham);
                    lvi.SubItems.Add(item.TenSanPham);
                    lvi.SubItems.Add(item.SoLuongBan.ToString());
                    lvi.SubItems.Add(item.DoanhThuFormat);

                    ListViewTopSanPhamBanChay.Items.Add(lvi);
                }

                ListViewTopSanPhamBanChay.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            }
            catch (Exception ex)
            {
                LogHelper.LogLoi("LoadTopSanPhamBanChay", ex.Message);
                MessageBox.Show("Lỗi tải top sản phẩm: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnxemdoanhthu_Click(object sender, EventArgs e)
        {
            LogHelper.LogXemBaoCao("Doanh thu", dtpkFromday.Value, dtpkToday.Value);
            LoadDoanhThu();
            LoadTopSanPhamBanChay();
        }

        private void dtpkFromday_ValueChanged(object sender, EventArgs e)
        {
            if (dtpkFromday.Value > dtpkToday.Value)
            {
                dtpkToday.Value = dtpkFromday.Value;
            }
        }

        private void dtpkToday_ValueChanged(object sender, EventArgs e)
        {
            if (dtpkToday.Value < dtpkFromday.Value)
            {
                dtpkFromday.Value = dtpkToday.Value;
            }
        }

        private void btnxuatexecl_Click(object sender, EventArgs e)
        {
            LogHelper.LogXuatExcel("Báo cáo tổng hợp");
            ExportToExcel();
        }

        private void ExportToExcel()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Excel Files|*.xlsx";
            saveFileDialog.Title = "Xuất báo cáo ra Excel";
            saveFileDialog.FileName = $"BaoCaoQuanLy_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                Excel.Application excelApp = null;
                Excel.Workbook workbook = null;
                Excel.Worksheet worksheet = null;

                try
                {
                    excelApp = new Excel.Application();
                    excelApp.DisplayAlerts = false;
                    workbook = excelApp.Workbooks.Add();

                    // SHEET 1: BÁO CÁO DOANH THU
                    worksheet = (Excel.Worksheet)workbook.Worksheets[1];
                    worksheet.Name = "Báo cáo doanh thu";

                    worksheet.Cells[1, 1] = "BÁO CÁO DOANH THU";
                    Excel.Range titleRange = worksheet.Range[worksheet.Cells[1, 1], worksheet.Cells[1, 6]];
                    titleRange.Merge();
                    titleRange.Font.Bold = true;
                    titleRange.Font.Size = 16;
                    titleRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                    worksheet.Cells[2, 1] = $"Từ ngày: {dtpkFromday.Value:dd/MM/yyyy}";
                    worksheet.Cells[2, 2] = $"Đến ngày: {dtpkToday.Value:dd/MM/yyyy}";
                    worksheet.Cells[3, 1] = $"Ngày xuất: {DateTime.Now:dd/MM/yyyy HH:mm:ss}";

                    worksheet.Cells[5, 1] = "Ngày";
                    worksheet.Cells[5, 2] = "Số đơn";
                    worksheet.Cells[5, 3] = "Doanh thu";
                    worksheet.Cells[5, 4] = "Trung bình/đơn";
                    worksheet.Cells[5, 5] = "Cao nhất";
                    worksheet.Cells[5, 6] = "Thấp nhất";

                    Excel.Range headerRange = worksheet.Range[worksheet.Cells[5, 1], worksheet.Cells[5, 6]];
                    headerRange.Font.Bold = true;
                    headerRange.Interior.Color = System.Drawing.Color.LightGray.ToArgb();
                    headerRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;

                    int row = 6;
                    foreach (ListViewItem item in listViewDoanhThu.Items)
                    {
                        worksheet.Cells[row, 1] = item.Text;
                        worksheet.Cells[row, 2] = int.Parse(item.SubItems[1].Text);
                        worksheet.Cells[row, 3] = item.SubItems[2].Text;
                        worksheet.Cells[row, 4] = item.SubItems[3].Text;
                        worksheet.Cells[row, 5] = item.SubItems[4].Text;
                        worksheet.Cells[row, 6] = item.SubItems[5].Text;
                        row++;
                    }

                    Excel.Range dataRange = worksheet.Range[worksheet.Cells[5, 1], worksheet.Cells[row - 1, 6]];
                    dataRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                    worksheet.Columns.AutoFit();

                    // SHEET 2: TOP SẢN PHẨM BÁN CHẠY
                    worksheet = (Excel.Worksheet)workbook.Worksheets.Add();
                    worksheet.Name = "Top sản phẩm bán chạy";

                    worksheet.Cells[1, 1] = "TOP 10 SẢN PHẨM BÁN CHẠY";
                    titleRange = worksheet.Range[worksheet.Cells[1, 1], worksheet.Cells[1, 4]];
                    titleRange.Merge();
                    titleRange.Font.Bold = true;
                    titleRange.Font.Size = 16;
                    titleRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                    worksheet.Cells[3, 1] = "Mã SP";
                    worksheet.Cells[3, 2] = "Tên sản phẩm";
                    worksheet.Cells[3, 3] = "Số lượng bán";
                    worksheet.Cells[3, 4] = "Doanh thu";

                    headerRange = worksheet.Range[worksheet.Cells[3, 1], worksheet.Cells[3, 4]];
                    headerRange.Font.Bold = true;
                    headerRange.Interior.Color = System.Drawing.Color.LightGray.ToArgb();
                    headerRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;

                    row = 4;
                    foreach (ListViewItem item in ListViewTopSanPhamBanChay.Items)
                    {
                        worksheet.Cells[row, 1] = item.Text;
                        worksheet.Cells[row, 2] = item.SubItems[1].Text;
                        worksheet.Cells[row, 3] = int.Parse(item.SubItems[2].Text);
                        worksheet.Cells[row, 4] = item.SubItems[3].Text;
                        row++;
                    }

                    dataRange = worksheet.Range[worksheet.Cells[3, 1], worksheet.Cells[row - 1, 4]];
                    dataRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                    worksheet.Columns.AutoFit();

                    // SHEET 3: DANH SÁCH SẢN PHẨM
                    worksheet = (Excel.Worksheet)workbook.Worksheets.Add();
                    worksheet.Name = "Danh sách sản phẩm";

                    worksheet.Cells[1, 1] = "DANH SÁCH SẢN PHẨM";
                    titleRange = worksheet.Range[worksheet.Cells[1, 1], worksheet.Cells[1, 7]];
                    titleRange.Merge();
                    titleRange.Font.Bold = true;
                    titleRange.Font.Size = 16;
                    titleRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                    worksheet.Cells[3, 1] = "ID";
                    worksheet.Cells[3, 2] = "Mã SP";
                    worksheet.Cells[3, 3] = "Tên sản phẩm";
                    worksheet.Cells[3, 4] = "Danh mục";
                    worksheet.Cells[3, 5] = "Giá bán";
                    worksheet.Cells[3, 6] = "Tồn kho";
                    worksheet.Cells[3, 7] = "Trạng thái";

                    headerRange = worksheet.Range[worksheet.Cells[3, 1], worksheet.Cells[3, 7]];
                    headerRange.Font.Bold = true;
                    headerRange.Interior.Color = System.Drawing.Color.LightGray.ToArgb();
                    headerRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;

                    row = 4;
                    foreach (DataGridViewRow dgvRow in dgvQuanLyThucdon.Rows)
                    {
                        if (!dgvRow.IsNewRow)
                        {
                            worksheet.Cells[row, 1] = dgvRow.Cells["IDSanPham"].Value ?? 0;
                            worksheet.Cells[row, 2] = dgvRow.Cells["Mã SP"].Value?.ToString() ?? "";
                            worksheet.Cells[row, 3] = dgvRow.Cells["Tên sản phẩm"].Value?.ToString() ?? "";
                            worksheet.Cells[row, 4] = dgvRow.Cells["Danh mục"].Value?.ToString() ?? "";
                            worksheet.Cells[row, 5] = dgvRow.Cells["Giá bán"].Value?.ToString() ?? "";
                            worksheet.Cells[row, 6] = dgvRow.Cells["Tồn kho"].Value ?? 0;
                            worksheet.Cells[row, 7] = dgvRow.Cells["Trạng thái"].Value?.ToString() ?? "";
                            row++;
                        }
                    }

                    dataRange = worksheet.Range[worksheet.Cells[3, 1], worksheet.Cells[row - 1, 7]];
                    dataRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                    worksheet.Columns.AutoFit();

                    // SHEET 4: DANH SÁCH NHÂN VIÊN
                    worksheet = (Excel.Worksheet)workbook.Worksheets.Add();
                    worksheet.Name = "Danh sách nhân viên";

                    worksheet.Cells[1, 1] = "DANH SÁCH NHÂN VIÊN";
                    titleRange = worksheet.Range[worksheet.Cells[1, 1], worksheet.Cells[1, 5]];
                    titleRange.Merge();
                    titleRange.Font.Bold = true;
                    titleRange.Font.Size = 16;
                    titleRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                    worksheet.Cells[3, 1] = "ID";
                    worksheet.Cells[3, 2] = "Tên đăng nhập";
                    worksheet.Cells[3, 3] = "Họ tên";
                    worksheet.Cells[3, 4] = "Trạng thái";
                    worksheet.Cells[3, 5] = "Ngày tạo";

                    headerRange = worksheet.Range[worksheet.Cells[3, 1], worksheet.Cells[3, 5]];
                    headerRange.Font.Bold = true;
                    headerRange.Interior.Color = System.Drawing.Color.LightGray.ToArgb();
                    headerRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;

                    row = 4;
                    foreach (DataGridViewRow dgvRow in drgvnhanvien.Rows)
                    {
                        if (!dgvRow.IsNewRow)
                        {
                            worksheet.Cells[row, 1] = dgvRow.Cells["IDNguoiDung"].Value ?? 0;
                            worksheet.Cells[row, 2] = dgvRow.Cells["Tên đăng nhập"].Value?.ToString() ?? "";
                            worksheet.Cells[row, 3] = dgvRow.Cells["Họ tên"].Value?.ToString() ?? "";
                            worksheet.Cells[row, 4] = dgvRow.Cells["Trạng thái"].Value?.ToString() ?? "";
                            worksheet.Cells[row, 5] = dgvRow.Cells["Ngày tạo"].Value?.ToString() ?? "";
                            row++;
                        }
                    }

                    dataRange = worksheet.Range[worksheet.Cells[3, 1], worksheet.Cells[row - 1, 5]];
                    dataRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                    worksheet.Columns.AutoFit();

                    // SHEET 5: LỊCH SỬ HOẠT ĐỘNG
                    worksheet = (Excel.Worksheet)workbook.Worksheets.Add();
                    worksheet.Name = "Lịch sử hoạt động";

                    worksheet.Cells[1, 1] = "LỊCH SỬ HOẠT ĐỘNG";
                    titleRange = worksheet.Range[worksheet.Cells[1, 1], worksheet.Cells[1, 7]];
                    titleRange.Merge();
                    titleRange.Font.Bold = true;
                    titleRange.Font.Size = 16;
                    titleRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                    worksheet.Cells[3, 1] = "STT";
                    worksheet.Cells[3, 2] = "Thời gian";
                    worksheet.Cells[3, 3] = "Người thực hiện";
                    worksheet.Cells[3, 4] = "Hành động";
                    worksheet.Cells[3, 5] = "Đối tượng";
                    worksheet.Cells[3, 6] = "Chi tiết";
                    worksheet.Cells[3, 7] = "IP";

                    headerRange = worksheet.Range[worksheet.Cells[3, 1], worksheet.Cells[3, 7]];
                    headerRange.Font.Bold = true;
                    headerRange.Interior.Color = System.Drawing.Color.LightGray.ToArgb();
                    headerRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;

                    row = 4;
                    int stt = 1;
                    foreach (ListViewItem item in listViewHoatDong.Items)
                    {
                        if (item.SubItems.Count > 1 && item.SubItems[1].Text != "Không có dữ liệu")
                        {
                            worksheet.Cells[row, 1] = stt++;
                            worksheet.Cells[row, 2] = item.SubItems[1].Text;
                            worksheet.Cells[row, 3] = item.SubItems[2].Text;
                            worksheet.Cells[row, 4] = item.SubItems[3].Text;
                            worksheet.Cells[row, 5] = item.SubItems[4].Text;
                            worksheet.Cells[row, 6] = item.SubItems[5].Text;
                            worksheet.Cells[row, 7] = item.SubItems[6].Text;
                            row++;
                        }
                    }

                    dataRange = worksheet.Range[worksheet.Cells[3, 1], worksheet.Cells[row - 1, 7]];
                    dataRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                    worksheet.Columns.AutoFit();

                    Excel.Worksheet emptySheet = (Excel.Worksheet)workbook.Worksheets[1];
                    emptySheet.Delete();

                    workbook.SaveAs(saveFileDialog.FileName);

                    MessageBox.Show($"Xuất file Excel thành công!\nĐường dẫn: {saveFileDialog.FileName}",
                        "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    if (MessageBox.Show("Bạn có muốn mở file vừa xuất không?", "Thông báo",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        System.Diagnostics.Process.Start(saveFileDialog.FileName);
                    }
                }
                catch (Exception ex)
                {
                    LogHelper.LogLoi("ExportToExcel", ex.Message);
                    MessageBox.Show("Lỗi xuất Excel: " + ex.Message, "Lỗi",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if (workbook != null)
                    {
                        try
                        {
                            workbook.Close(false);
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                        }
                        catch { }
                    }
                    if (excelApp != null)
                    {
                        try
                        {
                            excelApp.Quit();
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                        }
                        catch { }
                    }
                }
            }
        }
        #endregion

        #region Tab Quản Lý Thực Đơn
        private void LoadDanhSachSanPham()
        {
            try
            {
                var danhSach = sanPhamBUS.LayTatCaSanPham();

                DataTable dt = new DataTable();
                dt.Columns.Add("IDSanPham", typeof(int));
                dt.Columns.Add("Mã SP", typeof(string));
                dt.Columns.Add("Tên sản phẩm", typeof(string));
                dt.Columns.Add("Danh mục", typeof(string));
                dt.Columns.Add("Giá bán", typeof(string));
                dt.Columns.Add("Tồn kho", typeof(int));
                dt.Columns.Add("Trạng thái", typeof(string));

                foreach (var sp in danhSach)
                {
                    dt.Rows.Add(
                        sp.IDSanPham,
                        sp.MaSanPham,
                        sp.TenSanPham,
                        sp.TenLoai,
                        string.Format("{0:N0} đ", sp.GiaBan),
                        sp.SoLuongTon,
                        sp.TrangThaiHienThi
                    );
                }

                dgvQuanLyThucdon.DataSource = dt;
                CauHinhDataGridViewThucDon();
            }
            catch (Exception ex)
            {
                LogHelper.LogLoi("LoadDanhSachSanPham", ex.Message);
                MessageBox.Show("Lỗi tải sản phẩm: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CauHinhDataGridViewThucDon()
        {
            if (dgvQuanLyThucdon.Columns.Count == 0) return;

            dgvQuanLyThucdon.Font = new Font("Segoe UI", 10, FontStyle.Regular);
            dgvQuanLyThucdon.RowTemplate.Height = 35;
            dgvQuanLyThucdon.ColumnHeadersHeight = 40;
            dgvQuanLyThucdon.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            dgvQuanLyThucdon.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvQuanLyThucdon.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            if (dgvQuanLyThucdon.Columns["IDSanPham"] != null)
                dgvQuanLyThucdon.Columns["IDSanPham"].Visible = false;

            dgvQuanLyThucdon.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(245, 248, 250);
            dgvQuanLyThucdon.BackgroundColor = Color.White;
            dgvQuanLyThucdon.BorderStyle = BorderStyle.None;
            dgvQuanLyThucdon.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvQuanLyThucdon.EnableHeadersVisualStyles = false;
            dgvQuanLyThucdon.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(52, 73, 94);
            dgvQuanLyThucdon.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvQuanLyThucdon.RowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(230, 240, 255);
        }

        private void dgvQuanLyThucdon_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvQuanLyThucdon.Rows[e.RowIndex];
                int idSanPham = Convert.ToInt32(row.Cells["IDSanPham"].Value);
                sanPhamDangChon = sanPhamBUS.LayTheoID(idSanPham);

                if (sanPhamDangChon != null)
                {
                    txbFoodID.Text = sanPhamDangChon.IDSanPham.ToString();
                    txbfoodname.Text = sanPhamDangChon.TenSanPham;
                    txbDanhMucFood.Text = sanPhamDangChon.TenLoai;
                    txbFoodPrice.Text = sanPhamDangChon.GiaBan.ToString();
                    txbSoLuong.Text = sanPhamDangChon.SoLuongTon.ToString();
                }
            }
        }

        private void btnShowFood_Click(object sender, EventArgs e)
        {
            SetXemMode();
            LoadDanhSachSanPham();
            ClearSanPhamTextBoxes();
        }

        private void btnaddfood_Click(object sender, EventArgs e)
        {
            if (currentMode != Mode.Them)
            {
                SetThemMode();
                return;
            }

            try
            {
                string maSanPham = txbFoodID.Text.Trim();
                string tenSanPham = txbfoodname.Text.Trim();
                string tenLoai = txbDanhMucFood.Text.Trim();
                decimal giaBan;
                int soLuongTon;

                if (string.IsNullOrWhiteSpace(maSanPham))
                {
                    MessageBox.Show("Vui lòng nhập mã sản phẩm!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txbFoodID.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(tenSanPham))
                {
                    MessageBox.Show("Vui lòng nhập tên sản phẩm!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txbfoodname.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(tenLoai))
                {
                    MessageBox.Show("Vui lòng nhập danh mục!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txbDanhMucFood.Focus();
                    return;
                }

                if (!decimal.TryParse(txbFoodPrice.Text, out giaBan) || giaBan < 0)
                {
                    MessageBox.Show("Giá bán không hợp lệ!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txbFoodPrice.Focus();
                    return;
                }

                if (!int.TryParse(txbSoLuong.Text, out soLuongTon) || soLuongTon < 0)
                {
                    MessageBox.Show("Số lượng tồn không hợp lệ!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txbSoLuong.Focus();
                    return;
                }

                var danhSachLoai = loaiSanPhamBUS.LayTatCa();
                var loai = danhSachLoai.FirstOrDefault(l => l.TenLoai == tenLoai);
                int? idLoai = null;

                if (loai == null)
                {
                    LoaiSanPhamDTO loaiMoi = new LoaiSanPhamDTO { TenLoai = tenLoai, KichHoat = true };
                    loaiSanPhamBUS.Them(loaiMoi);
                    loai = loaiSanPhamBUS.LayTatCa().FirstOrDefault(l => l.TenLoai == tenLoai);
                }
                if (loai != null) idLoai = loai.IDLoai;

                if (sanPhamBUS.LayTatCaSanPham().Any(sp => sp.MaSanPham == maSanPham))
                {
                    MessageBox.Show($"Mã sản phẩm '{maSanPham}' đã tồn tại!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txbFoodID.Focus();
                    return;
                }

                if (sanPhamBUS.LayTatCaSanPham().Any(sp => sp.TenSanPham == tenSanPham))
                {
                    MessageBox.Show($"Tên sản phẩm '{tenSanPham}' đã tồn tại!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txbfoodname.Focus();
                    return;
                }

                SanPhamDTO spMoi = new SanPhamDTO
                {
                    MaSanPham = maSanPham,
                    TenSanPham = tenSanPham,
                    IDLoai = idLoai,
                    GiaBan = giaBan,
                    SoLuongTon = soLuongTon,
                    TonToiThieu = 5,
                    KichHoat = true
                };

                if (sanPhamBUS.Them(spMoi))
                {
                    LogHelper.LogThemSanPham(spMoi.IDSanPham, tenSanPham, maSanPham);
                    MessageBox.Show("Thêm sản phẩm thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDanhSachSanPham();
                    SetXemMode();
                    ClearSanPhamTextBoxes();
                }
                else
                {
                    MessageBox.Show("Thêm sản phẩm thất bại!", "Lỗi",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                LogHelper.LogLoi("btnaddfood_Click", ex.Message);
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnsuafood_Click(object sender, EventArgs e)
        {
            if (currentMode != Mode.Sua)
            {
                SetSuaMode();
                return;
            }

            try
            {
                if (sanPhamDangChon == null)
                {
                    MessageBox.Show("Vui lòng chọn sản phẩm cần sửa!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    SetXemMode();
                    return;
                }

                string tenSanPham = txbfoodname.Text.Trim();
                string tenLoai = txbDanhMucFood.Text.Trim();
                decimal giaBan;
                int soLuongTon;

                if (string.IsNullOrWhiteSpace(tenSanPham))
                {
                    MessageBox.Show("Vui lòng nhập tên sản phẩm!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txbfoodname.Focus();
                    return;
                }

                if (!decimal.TryParse(txbFoodPrice.Text, out giaBan) || giaBan < 0)
                {
                    MessageBox.Show("Giá bán không hợp lệ!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txbFoodPrice.Focus();
                    return;
                }

                if (!int.TryParse(txbSoLuong.Text, out soLuongTon) || soLuongTon < 0)
                {
                    MessageBox.Show("Số lượng tồn không hợp lệ!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txbSoLuong.Focus();
                    return;
                }

                var danhSachLoai = loaiSanPhamBUS.LayTatCa();
                var loai = danhSachLoai.FirstOrDefault(l => l.TenLoai == tenLoai);
                int? idLoai = loai?.IDLoai;

                if (sanPhamBUS.LayTatCaSanPham().Any(sp => sp.TenSanPham == tenSanPham && sp.IDSanPham != sanPhamDangChon.IDSanPham))
                {
                    MessageBox.Show($"Tên sản phẩm '{tenSanPham}' đã tồn tại!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txbfoodname.Focus();
                    return;
                }

                string thayDoi = "";
                if (sanPhamDangChon.TenSanPham != tenSanPham) thayDoi += $"Tên: {sanPhamDangChon.TenSanPham} -> {tenSanPham}; ";
                if (sanPhamDangChon.GiaBan != giaBan) thayDoi += $"Giá: {sanPhamDangChon.GiaBan:N0} -> {giaBan:N0}; ";
                if (sanPhamDangChon.SoLuongTon != soLuongTon) thayDoi += $"Tồn: {sanPhamDangChon.SoLuongTon} -> {soLuongTon}; ";

                sanPhamDangChon.TenSanPham = tenSanPham;
                sanPhamDangChon.IDLoai = idLoai;
                sanPhamDangChon.GiaBan = giaBan;
                sanPhamDangChon.SoLuongTon = soLuongTon;

                if (sanPhamBUS.Sua(sanPhamDangChon))
                {
                    LogHelper.LogSuaSanPham(sanPhamDangChon.IDSanPham, tenSanPham, thayDoi);
                    MessageBox.Show("Sửa sản phẩm thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDanhSachSanPham();
                    SetXemMode();
                    ClearSanPhamTextBoxes();
                }
                else
                {
                    MessageBox.Show("Sửa sản phẩm thất bại!", "Lỗi",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                LogHelper.LogLoi("btnsuafood_Click", ex.Message);
                MessageBox.Show("Lỗi: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnxoafood_Click(object sender, EventArgs e)
        {
            if (currentMode != Mode.Xoa)
            {
                SetXoaMode();
                return;
            }

            DialogResult dr = MessageBox.Show($"Bạn có chắc chắn muốn xóa sản phẩm '{sanPhamDangChon?.TenSanPham}' không?",
                "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {
                try
                {
                    if (sanPhamBUS.Xoa(sanPhamDangChon.IDSanPham))
                    {
                        LogHelper.LogXoaSanPham(sanPhamDangChon.IDSanPham, sanPhamDangChon.TenSanPham);
                        MessageBox.Show("Xóa sản phẩm thành công!", "Thông báo",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDanhSachSanPham();
                        SetXemMode();
                        ClearSanPhamTextBoxes();
                    }
                    else
                    {
                        MessageBox.Show("Xóa sản phẩm thất bại!", "Lỗi",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    LogHelper.LogLoi("btnxoafood_Click", ex.Message);
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                SetXemMode();
            }
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            try
            {
                string tuKhoa = txbtimFoodName.Text.Trim();
                List<SanPhamDTO> ketQua = string.IsNullOrWhiteSpace(tuKhoa) ?
                    sanPhamBUS.LayTatCaSanPham() : sanPhamBUS.TimKiem(tuKhoa);

                DataTable dt = new DataTable();
                dt.Columns.Add("IDSanPham", typeof(int));
                dt.Columns.Add("Mã SP", typeof(string));
                dt.Columns.Add("Tên sản phẩm", typeof(string));
                dt.Columns.Add("Danh mục", typeof(string));
                dt.Columns.Add("Giá bán", typeof(string));
                dt.Columns.Add("Tồn kho", typeof(int));
                dt.Columns.Add("Trạng thái", typeof(string));

                foreach (var sp in ketQua)
                {
                    dt.Rows.Add(sp.IDSanPham, sp.MaSanPham, sp.TenSanPham, sp.TenLoai,
                        string.Format("{0:N0} đ", sp.GiaBan), sp.SoLuongTon, sp.TrangThaiHienThi);
                }

                dgvQuanLyThucdon.DataSource = dt;
                CauHinhDataGridViewThucDon();

                if (ketQua.Count == 0 && !string.IsNullOrWhiteSpace(tuKhoa))
                {
                    MessageBox.Show($"Không tìm thấy sản phẩm nào với từ khóa '{tuKhoa}'!", "Kết quả tìm kiếm",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                LogHelper.LogLoi("btnTimKiem_Click", ex.Message);
                MessageBox.Show("Lỗi tìm kiếm: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Tab Quản Lý Nhân Viên
        private void LoadDanhSachNhanVien()
        {
            try
            {
                var danhSach = nguoiDungBUS.LayDanhSachNhanVien();

                DataTable dt = new DataTable();
                dt.Columns.Add("IDNguoiDung", typeof(int));
                dt.Columns.Add("Tên đăng nhập", typeof(string));
                dt.Columns.Add("Họ tên", typeof(string));
                dt.Columns.Add("Trạng thái", typeof(string));
                dt.Columns.Add("Ngày tạo", typeof(string));

                foreach (var nv in danhSach)
                {
                    dt.Rows.Add(
                        nv.IDNguoiDung,
                        nv.TenDangNhap,
                        nv.HoTen,
                        nv.KichHoat ? "Hoạt động" : "Đã khóa",
                        nv.NgayTao.ToString("dd/MM/yyyy HH:mm")
                    );
                }

                drgvnhanvien.DataSource = dt;
                CauHinhDataGridViewNhanVien();

                drgvnhanvien.CellClick -= drgvnhanvien_CellClick;
                drgvnhanvien.CellClick += drgvnhanvien_CellClick;
            }
            catch (Exception ex)
            {
                LogHelper.LogLoi("LoadDanhSachNhanVien", ex.Message);
                MessageBox.Show("Lỗi tải nhân viên: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CauHinhDataGridViewNhanVien()
        {
            if (drgvnhanvien.Columns.Count == 0) return;

            drgvnhanvien.Font = new Font("Segoe UI", 10, FontStyle.Regular);
            drgvnhanvien.RowTemplate.Height = 35;
            drgvnhanvien.ColumnHeadersHeight = 40;
            drgvnhanvien.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            drgvnhanvien.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            drgvnhanvien.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            if (drgvnhanvien.Columns["IDNguoiDung"] != null)
                drgvnhanvien.Columns["IDNguoiDung"].Visible = false;

            drgvnhanvien.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(245, 248, 250);
            drgvnhanvien.BackgroundColor = Color.White;
            drgvnhanvien.BorderStyle = BorderStyle.None;
            drgvnhanvien.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            drgvnhanvien.EnableHeadersVisualStyles = false;
            drgvnhanvien.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(52, 73, 94);
            drgvnhanvien.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            drgvnhanvien.RowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(230, 240, 255);
        }

        private void drgvnhanvien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                try
                {
                    DataGridViewRow row = drgvnhanvien.Rows[e.RowIndex];
                    int idNhanVien = Convert.ToInt32(row.Cells["IDNguoiDung"].Value);
                    nhanVienDangChon = nguoiDungBUS.LayTheoID(idNhanVien);

                    if (nhanVienDangChon != null)
                    {
                        txbtentk.Text = nhanVienDangChon.TenDangNhap;
                        txbtenhienthitk.Text = nhanVienDangChon.HoTen;
                        txbtrangthainhanvien.Text = nhanVienDangChon.KichHoat ? "Hoạt động" : "Đã khóa";
                        txbmktk.Text = "********";

                        LoadThongKeNhanVien();
                    }
                }
                catch (Exception ex)
                {
                    LogHelper.LogLoi("drgvnhanvien_CellClick", ex.Message);
                    MessageBox.Show("Lỗi khi chọn nhân viên: " + ex.Message, "Lỗi",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadThongKeNhanVien()
        {
            if (nhanVienDangChon == null) return;

            try
            {
                DateTime tuNgay = dtpkFromdaynhanvien.Value.Date;
                DateTime denNgay = dtpkTodaynhanvien.Value.Date;
                var thongKe = thongKeDAL.ThongKeNhanVien(nhanVienDangChon.IDNguoiDung, tuNgay, denNgay);

                gbThongKeNhanVien.Controls.Clear();

                Panel pnlInfo = new Panel();
                pnlInfo.Dock = DockStyle.Fill;
                pnlInfo.AutoScroll = true;
                pnlInfo.Padding = new Padding(10);
                pnlInfo.BackColor = Color.White;

                Label lblThongTin = new Label();
                lblThongTin.Text = $"═══════════════════════════════════════\n" +
                                   $"      THÔNG TIN NHÂN VIÊN\n" +
                                   $"═══════════════════════════════════════\n\n" +
                                   $"📌 Họ tên: {nhanVienDangChon.HoTen}\n" +
                                   $"🔑 Tên đăng nhập: {nhanVienDangChon.TenDangNhap}\n" +
                                   $"📅 Ngày tạo: {nhanVienDangChon.NgayTao:dd/MM/yyyy HH:mm}\n" +
                                   $"📊 Trạng thái: {(nhanVienDangChon.KichHoat ? "🟢 Hoạt động" : "🔴 Đã khóa")}\n\n" +
                                   $"═══════════════════════════════════════\n" +
                                   $"      THỐNG KÊ (Từ {tuNgay:dd/MM/yyyy} - {denNgay:dd/MM/yyyy})\n" +
                                   $"═══════════════════════════════════════\n\n" +
                                   $"📋 Số đơn hoàn thành: {thongKe.SoDonHoanThanh}\n" +
                                   $"💰 Tổng doanh thu: {thongKe.TongDoanhThuFormat}\n" +
                                   $"📈 Trung bình/đơn: {thongKe.TrungBinhDonFormat}\n";
                lblThongTin.Font = new Font("Segoe UI", 11, FontStyle.Regular);
                lblThongTin.AutoSize = true;
                lblThongTin.Location = new Point(15, 15);
                lblThongTin.BackColor = Color.FromArgb(248, 249, 250);
                lblThongTin.Padding = new Padding(10);

                pnlInfo.Controls.Add(lblThongTin);
                gbThongKeNhanVien.Controls.Add(pnlInfo);
                gbThongKeNhanVien.Text = "📊 THỐNG KÊ NHÂN VIÊN";
                gbThongKeNhanVien.Font = new Font("Segoe UI", 10, FontStyle.Bold);
                gbThongKeNhanVien.ForeColor = Color.FromArgb(52, 73, 94);
            }
            catch (Exception ex)
            {
                LogHelper.LogLoi("LoadThongKeNhanVien", ex.Message);
                gbThongKeNhanVien.Controls.Clear();
                Label lblError = new Label();
                lblError.Text = $"Lỗi tải dữ liệu: {ex.Message}";
                lblError.ForeColor = Color.Red;
                lblError.Dock = DockStyle.Fill;
                lblError.TextAlign = ContentAlignment.MiddleCenter;
                lblError.Font = new Font("Segoe UI", 10);
                gbThongKeNhanVien.Controls.Add(lblError);
            }
        }

        private void btnlammoitk_Click(object sender, EventArgs e)
        {
            if (nhanVienDangChon != null)
            {
                LoadThongKeNhanVien();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn nhân viên để thống kê!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void dtpkFromdaynhanvien_ValueChanged(object sender, EventArgs e)
        {
            if (dtpkFromdaynhanvien.Value > dtpkTodaynhanvien.Value)
            {
                dtpkTodaynhanvien.Value = dtpkFromdaynhanvien.Value;
            }
            if (nhanVienDangChon != null)
            {
                LoadThongKeNhanVien();
            }
        }

        private void dtpkTodaynhanvien_ValueChanged(object sender, EventArgs e)
        {
            if (dtpkTodaynhanvien.Value < dtpkFromdaynhanvien.Value)
            {
                dtpkFromdaynhanvien.Value = dtpkTodaynhanvien.Value;
            }
            if (nhanVienDangChon != null)
            {
                LoadThongKeNhanVien();
            }
        }

        private void btnThemTK_Click(object sender, EventArgs e)
        {
            Form themNhanVienForm = new Form();
            themNhanVienForm.Text = "Thêm nhân viên mới";
            themNhanVienForm.Size = new Size(450, 350);
            themNhanVienForm.StartPosition = FormStartPosition.CenterParent;
            themNhanVienForm.FormBorderStyle = FormBorderStyle.FixedDialog;
            themNhanVienForm.MaximizeBox = false;
            themNhanVienForm.BackColor = Color.White;

            Label lblTenDN = new Label() { Text = "Tên đăng nhập:", Location = new Point(30, 30), Size = new Size(100, 25), Font = new Font("Segoe UI", 10) };
            TextBox txtTenDN = new TextBox() { Location = new Point(150, 30), Size = new Size(250, 25), Font = new Font("Segoe UI", 10) };

            Label lblHoTen = new Label() { Text = "Họ tên:", Location = new Point(30, 70), Size = new Size(100, 25), Font = new Font("Segoe UI", 10) };
            TextBox txtHoTen = new TextBox() { Location = new Point(150, 70), Size = new Size(250, 25), Font = new Font("Segoe UI", 10) };

            Label lblMatKhau = new Label() { Text = "Mật khẩu:", Location = new Point(30, 110), Size = new Size(100, 25), Font = new Font("Segoe UI", 10) };
            TextBox txtMatKhau = new TextBox() { Location = new Point(150, 110), Size = new Size(250, 25), PasswordChar = '*', Font = new Font("Segoe UI", 10) };

            Label lblXacNhan = new Label() { Text = "Xác nhận MK:", Location = new Point(30, 150), Size = new Size(100, 25), Font = new Font("Segoe UI", 10) };
            TextBox txtXacNhan = new TextBox() { Location = new Point(150, 150), Size = new Size(250, 25), PasswordChar = '*', Font = new Font("Segoe UI", 10) };

            Button btnLuu = new Button() { Text = "Lưu", Location = new Point(150, 210), Size = new Size(100, 35), BackColor = Color.FromArgb(46, 204, 113), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            Button btnHuy = new Button() { Text = "Hủy", Location = new Point(270, 210), Size = new Size(100, 35), BackColor = Color.FromArgb(231, 76, 60), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold) };

            btnLuu.Click += (s, ev) =>
            {
                try
                {
                    string tenDN = txtTenDN.Text.Trim();
                    string hoTen = txtHoTen.Text.Trim();
                    string matKhau = txtMatKhau.Text;

                    if (string.IsNullOrWhiteSpace(tenDN))
                    {
                        MessageBox.Show("Vui lòng nhập tên đăng nhập!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (tenDN.Length < 3)
                    {
                        MessageBox.Show("Tên đăng nhập phải có ít nhất 3 ký tự!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (string.IsNullOrWhiteSpace(hoTen))
                    {
                        MessageBox.Show("Vui lòng nhập họ tên!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (string.IsNullOrWhiteSpace(matKhau) || matKhau.Length < 6)
                    {
                        MessageBox.Show("Mật khẩu phải có ít nhất 6 ký tự!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (matKhau != txtXacNhan.Text)
                    {
                        MessageBox.Show("Mật khẩu xác nhận không khớp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (nguoiDungBUS.LayDanhSachNguoiDung().Any(nd => nd.TenDangNhap == tenDN))
                    {
                        MessageBox.Show("Tên đăng nhập đã tồn tại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (nguoiDungBUS.ThemNhanVien(tenDN, matKhau, hoTen))
                    {
                        LogHelper.LogThemNhanVien(nguoiDungBUS.LayDanhSachNhanVien().Last().IDNguoiDung, hoTen, tenDN);
                        MessageBox.Show("Thêm nhân viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDanhSachNhanVien();
                        themNhanVienForm.Close();
                    }
                    else
                    {
                        MessageBox.Show("Thêm nhân viên thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    LogHelper.LogLoi("ThemNhanVien", ex.Message);
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };
            btnHuy.Click += (s, ev) => themNhanVienForm.Close();

            themNhanVienForm.Controls.AddRange(new Control[] { lblTenDN, txtTenDN, lblHoTen, txtHoTen, lblMatKhau, txtMatKhau, lblXacNhan, txtXacNhan, btnLuu, btnHuy });
            themNhanVienForm.ShowDialog();
        }

        private void btnSuaTK_Click(object sender, EventArgs e)
        {
            if (nhanVienDangChon == null)
            {
                MessageBox.Show("Vui lòng chọn nhân viên cần sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Form suaNhanVienForm = new Form();
            suaNhanVienForm.Text = "Sửa thông tin nhân viên";
            suaNhanVienForm.Size = new Size(450, 280);
            suaNhanVienForm.StartPosition = FormStartPosition.CenterParent;
            suaNhanVienForm.FormBorderStyle = FormBorderStyle.FixedDialog;
            suaNhanVienForm.MaximizeBox = false;
            suaNhanVienForm.BackColor = Color.White;

            Label lblTenDN = new Label() { Text = "Tên đăng nhập:", Location = new Point(30, 30), Size = new Size(100, 25), Font = new Font("Segoe UI", 10) };
            TextBox txtTenDN = new TextBox() { Location = new Point(150, 30), Size = new Size(250, 25), Text = nhanVienDangChon.TenDangNhap, ReadOnly = true, BackColor = Color.FromArgb(240, 240, 240) };

            Label lblHoTen = new Label() { Text = "Họ tên:", Location = new Point(30, 70), Size = new Size(100, 25), Font = new Font("Segoe UI", 10) };
            TextBox txtHoTen = new TextBox() { Location = new Point(150, 70), Size = new Size(250, 25), Text = nhanVienDangChon.HoTen };

            Label lblTrangThai = new Label() { Text = "Trạng thái:", Location = new Point(30, 110), Size = new Size(100, 25), Font = new Font("Segoe UI", 10) };
            ComboBox cbTrangThai = new ComboBox() { Location = new Point(150, 110), Size = new Size(250, 25), DropDownStyle = ComboBoxStyle.DropDownList };
            cbTrangThai.Items.AddRange(new object[] { "Hoạt động", "Đã khóa" });
            cbTrangThai.SelectedIndex = nhanVienDangChon.KichHoat ? 0 : 1;

            Button btnLuu = new Button() { Text = "Cập nhật", Location = new Point(150, 170), Size = new Size(100, 35), BackColor = Color.FromArgb(52, 152, 219), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold) };
            Button btnHuy = new Button() { Text = "Hủy", Location = new Point(270, 170), Size = new Size(100, 35), BackColor = Color.FromArgb(231, 76, 60), ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Font = new Font("Segoe UI", 10, FontStyle.Bold) };

            btnLuu.Click += (s, ev) =>
            {
                try
                {
                    string hoTen = txtHoTen.Text.Trim();
                    bool kichHoat = cbTrangThai.SelectedIndex == 0;

                    if (string.IsNullOrWhiteSpace(hoTen))
                    {
                        MessageBox.Show("Họ tên không được để trống!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    string thayDoi = "";
                    if (nhanVienDangChon.HoTen != hoTen) thayDoi += $"Họ tên: {nhanVienDangChon.HoTen} -> {hoTen}; ";
                    if (nhanVienDangChon.KichHoat != kichHoat) thayDoi += $"Trạng thái: {(nhanVienDangChon.KichHoat ? "Hoạt động" : "Đã khóa")} -> {(kichHoat ? "Hoạt động" : "Đã khóa")}; ";

                    nhanVienDangChon.HoTen = hoTen;
                    nhanVienDangChon.KichHoat = kichHoat;

                    if (nguoiDungBUS.CapNhatNguoiDung(nhanVienDangChon))
                    {
                        if (!string.IsNullOrEmpty(thayDoi))
                            LogHelper.LogSuaNhanVien(nhanVienDangChon.IDNguoiDung, hoTen, thayDoi);
                        MessageBox.Show("Cập nhật thông tin thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadDanhSachNhanVien();
                        suaNhanVienForm.Close();
                    }
                    else
                    {
                        MessageBox.Show("Cập nhật thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    LogHelper.LogLoi("SuaNhanVien", ex.Message);
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };
            btnHuy.Click += (s, ev) => suaNhanVienForm.Close();

            suaNhanVienForm.Controls.AddRange(new Control[] { lblTenDN, txtTenDN, lblHoTen, txtHoTen, lblTrangThai, cbTrangThai, btnLuu, btnHuy });
            suaNhanVienForm.ShowDialog();
        }

        private void btnXoaTk_Click(object sender, EventArgs e)
        {
            if (nhanVienDangChon == null)
            {
                MessageBox.Show("Vui lòng chọn nhân viên cần khóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (nhanVienDangChon.IDNguoiDung == SessionManager.GetCurrentUserId())
            {
                MessageBox.Show("Bạn không thể khóa tài khoản đang đăng nhập!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string action = nhanVienDangChon.KichHoat ? "khóa" : "mở khóa";
            DialogResult dr = MessageBox.Show($"Bạn có chắc chắn muốn {action} tài khoản nhân viên '{nhanVienDangChon.HoTen}' không?",
                "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {
                try
                {
                    if (nhanVienDangChon.KichHoat)
                    {
                        nguoiDungBUS.KhoaTaiKhoan(nhanVienDangChon.IDNguoiDung);
                        LogHelper.LogKhoaNhanVien(nhanVienDangChon.IDNguoiDung, nhanVienDangChon.HoTen);
                        MessageBox.Show("KHÓA tài khoản thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        nguoiDungBUS.MoKhoaTaiKhoan(nhanVienDangChon.IDNguoiDung);
                        LogHelper.LogMoKhoaNhanVien(nhanVienDangChon.IDNguoiDung, nhanVienDangChon.HoTen);
                        MessageBox.Show("MỞ KHÓA tài khoản thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    LoadDanhSachNhanVien();
                    nhanVienDangChon = null;
                    txbtentk.Clear();
                    txbtenhienthitk.Clear();
                    txbtrangthainhanvien.Clear();
                    txbmktk.Clear();
                    gbThongKeNhanVien.Controls.Clear();
                }
                catch (Exception ex)
                {
                    LogHelper.LogLoi("KhoaMoKhoaNhanVien", ex.Message);
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnxemTk_Click(object sender, EventArgs e)
        {
            LoadDanhSachNhanVien();
            nhanVienDangChon = null;
            txbtentk.Clear();
            txbtenhienthitk.Clear();
            txbtrangthainhanvien.Clear();
            txbmktk.Clear();
            gbThongKeNhanVien.Controls.Clear();
        }

        private void bntThoat_Click(object sender, EventArgs e) => this.Close();
        #endregion

        #region Tab Quản Lý Hoạt Động

        private void CauHinhListViewHoatDong()
        {
            listViewHoatDong.View = View.Details;
            listViewHoatDong.FullRowSelect = true;
            listViewHoatDong.GridLines = true;
            listViewHoatDong.Font = new Font("Segoe UI", 10);
            listViewHoatDong.BackColor = Color.White;
            listViewHoatDong.ForeColor = Color.FromArgb(44, 62, 80);

            listViewHoatDong.Columns.Clear();

            listViewHoatDong.Columns.Add("STT", 45, HorizontalAlignment.Center);
            listViewHoatDong.Columns.Add("Thời gian", 150, HorizontalAlignment.Center);
            listViewHoatDong.Columns.Add("Người thực hiện", 140, HorizontalAlignment.Left);
            listViewHoatDong.Columns.Add("Hành động", 100, HorizontalAlignment.Center);
            listViewHoatDong.Columns.Add("Đối tượng", 120, HorizontalAlignment.Center);
            listViewHoatDong.Columns.Add("Chi tiết", 400, HorizontalAlignment.Left);
            listViewHoatDong.Columns.Add("IP", 110, HorizontalAlignment.Center);

            listViewHoatDong.OwnerDraw = true;
            listViewHoatDong.DrawColumnHeader += ListViewHoatDong_DrawColumnHeader;
            listViewHoatDong.DrawSubItem += ListViewHoatDong_DrawSubItem;

            listViewHoatDong.AllowColumnReorder = false;
            listViewHoatDong.MultiSelect = false;
            listViewHoatDong.FullRowSelect = true;
        }

        private void ListViewHoatDong_DrawColumnHeader(object sender, DrawListViewColumnHeaderEventArgs e)
        {
            e.DrawBackground();
            using (SolidBrush brush = new SolidBrush(Color.FromArgb(52, 73, 94)))
            {
                e.Graphics.FillRectangle(brush, e.Bounds);
            }

            using (SolidBrush fontBrush = new SolidBrush(Color.White))
            {
                StringFormat sf = new StringFormat();
                sf.Alignment = StringAlignment.Center;
                sf.LineAlignment = StringAlignment.Center;
                Font headerFont = new Font("Segoe UI", 10, FontStyle.Bold);
                e.Graphics.DrawString(e.Header.Text, headerFont, fontBrush, e.Bounds, sf);
            }
        }

        private void ListViewHoatDong_DrawSubItem(object sender, DrawListViewSubItemEventArgs e)
        {
            e.DrawBackground();

            if (e.ItemIndex % 2 == 0)
            {
                e.Graphics.FillRectangle(new SolidBrush(Color.White), e.Bounds);
            }
            else
            {
                e.Graphics.FillRectangle(new SolidBrush(Color.FromArgb(245, 248, 250)), e.Bounds);
            }

            Color textColor = Color.FromArgb(44, 62, 80);

            if (e.ColumnIndex == 3 && e.Item.SubItems.Count > 3)
            {
                string hanhDong = e.SubItem.Text;
                switch (hanhDong)
                {
                    case "ĐĂNG NHẬP":
                    case "ĐĂNG XUẤT":
                        textColor = Color.FromArgb(52, 152, 219);
                        break;
                    case "THÊM":
                        textColor = Color.FromArgb(46, 204, 113);
                        break;
                    case "SỬA":
                        textColor = Color.FromArgb(241, 196, 15);
                        break;
                    case "XÓA":
                    case "KHÓA":
                        textColor = Color.FromArgb(231, 76, 60);
                        break;
                    case "MỞ KHÓA":
                        textColor = Color.FromArgb(155, 89, 182);
                        break;
                    case "THANH TOÁN":
                        textColor = Color.FromArgb(142, 68, 173);
                        break;
                    case "DỌN BÀN":
                    case "CHUYỂN BÀN":
                        textColor = Color.FromArgb(26, 188, 156);
                        break;
                    case "NHẬP KHO":
                        textColor = Color.FromArgb(243, 156, 18);
                        break;
                    default:
                        textColor = Color.FromArgb(44, 62, 80);
                        break;
                }
            }

            using (SolidBrush fontBrush = new SolidBrush(textColor))
            {
                StringFormat sf = new StringFormat();
                sf.LineAlignment = StringAlignment.Center;

                if (e.ColumnIndex == 0 || e.ColumnIndex == 1 || e.ColumnIndex == 3 || e.ColumnIndex == 4 || e.ColumnIndex == 6)
                {
                    sf.Alignment = StringAlignment.Center;
                }
                else
                {
                    sf.Alignment = StringAlignment.Near;
                }

                Font itemFont = new Font("Segoe UI", 9);
                e.Graphics.DrawString(e.SubItem.Text, itemFont, fontBrush, e.Bounds, sf);
            }

            using (Pen pen = new Pen(Color.FromArgb(230, 230, 230)))
            {
                e.Graphics.DrawLine(pen, e.Bounds.Left, e.Bounds.Bottom - 1, e.Bounds.Right, e.Bounds.Bottom - 1);
            }
        }

        private void LoadDanhSachHoatDong()
        {
            try
            {
                DateTime tuNgay = dtpkFromdayHoatDong.Value.Date;
                DateTime denNgay = dtpkTodayHoatDong.Value.Date;

                string hanhDong = cmbTimKiemHoatDong.SelectedIndex > 0 ? cmbTimKiemHoatDong.SelectedItem.ToString() : null;
                string nguoiThucHien = string.IsNullOrWhiteSpace(txbTimKiemHoatDong.Text) ? null : txbTimKiemHoatDong.Text.Trim();

                var danhSach = lichSuBUS.LayDanhSach(tuNgay, denNgay, hanhDong, nguoiThucHien, null, 2000);

                listViewHoatDong.Items.Clear();

                int stt = 1;
                foreach (var item in danhSach)
                {
                    ListViewItem lvi = new ListViewItem(stt.ToString());
                    lvi.SubItems.Add(item.ThoiGianText);
                    lvi.SubItems.Add(item.NguoiThucHien);
                    lvi.SubItems.Add(item.HanhDong);
                    lvi.SubItems.Add(item.DoiTuong);
                    lvi.SubItems.Add(item.ChiTiet);
                    lvi.SubItems.Add(item.DiaChiIP);
                    lvi.Tag = item;

                    listViewHoatDong.Items.Add(lvi);
                    stt++;
                }

                CapNhatThongKeHoatDong(danhSach);
                listViewHoatDong.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);

                if (listViewHoatDong.Columns.Count > 5)
                {
                    listViewHoatDong.Columns[5].Width = 400;
                }

                if (danhSach.Count == 0)
                {
                    ListViewItem lviEmpty = new ListViewItem("");
                    lviEmpty.SubItems.Add("Không có dữ liệu");
                    lviEmpty.SubItems.Add("");
                    lviEmpty.SubItems.Add("");
                    lviEmpty.SubItems.Add("");
                    lviEmpty.SubItems.Add("");
                    lviEmpty.SubItems.Add("");
                    listViewHoatDong.Items.Add(lviEmpty);
                }
            }
            catch (Exception ex)
            {
                LogHelper.LogLoi("LoadDanhSachHoatDong", ex.Message);
                MessageBox.Show($"Lỗi tải lịch sử hoạt động: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // PHIÊN BẢN ĐƠN GIẢN - CHỈ CẬP NHẬT 2 TEXTBOX ĐÃ CÓ SẴN
        private void CapNhatThongKeHoatDong(List<LichSuHoatDongDTO> danhSach)
        {
            try
            {
                // Cập nhật 2 TextBox đã có sẵn trong Designer
                txbTongSoHoatDong.Text = danhSach.Count.ToString("N0");

                int homNay = danhSach.Count(x => x.ThoiGian.Date == DateTime.Today);
                txbHoatDongHomNay.Text = homNay.ToString("N0");
            }
            catch (Exception ex)
            {
                LogHelper.LogLoi("CapNhatThongKeHoatDong", ex.Message);
            }
        }

        private void LoadComboHanhDong()
        {
            cmbTimKiemHoatDong.Items.Clear();
            cmbTimKiemHoatDong.Items.Add("-- Tất cả --");
            cmbTimKiemHoatDong.Items.Add("ĐĂNG NHẬP");
            cmbTimKiemHoatDong.Items.Add("ĐĂNG XUẤT");
            cmbTimKiemHoatDong.Items.Add("THÊM");
            cmbTimKiemHoatDong.Items.Add("SỬA");
            cmbTimKiemHoatDong.Items.Add("XÓA");
            cmbTimKiemHoatDong.Items.Add("KHÓA");
            cmbTimKiemHoatDong.Items.Add("MỞ KHÓA");
            cmbTimKiemHoatDong.Items.Add("THANH TOÁN");
            cmbTimKiemHoatDong.Items.Add("DỌN BÀN");
            cmbTimKiemHoatDong.Items.Add("CHUYỂN BÀN");
            cmbTimKiemHoatDong.Items.Add("NHẬP KHO");
            cmbTimKiemHoatDong.Items.Add("XEM BÁO CÁO");
            cmbTimKiemHoatDong.Items.Add("XUẤT EXCEL");
            cmbTimKiemHoatDong.Items.Add("ĐỔI MẬT KHẨU");
            cmbTimKiemHoatDong.Items.Add("GHI CHÚ");
            cmbTimKiemHoatDong.Items.Add("LỖI HỆ THỐNG");

            cmbTimKiemHoatDong.SelectedIndex = 0;
            cmbTimKiemHoatDong.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        #endregion

        #region Các sự kiện trống và sự kiện tab Quản lý Hoạt động
        private void tpDoanhThu_Click(object sender, EventArgs e) { }
        private void panel2_Paint(object sender, PaintEventArgs e) { }
        private void panel1_Paint(object sender, PaintEventArgs e) { }
        private void panel11_Paint(object sender, PaintEventArgs e) { }
        private void panel12_Paint(object seller, PaintEventArgs e) { }
        private void chartDoanhThu_Click(object sender, EventArgs e) { }
        private void tpQuanLyThucDon_Click(object sender, EventArgs e) { }
        private void panel5_Paint(object sender, PaintEventArgs e) { }
        private void txbtimFoodName_TextChanged(object sender, EventArgs e) { }
        private void panel6_Paint(object sender, PaintEventArgs e) { }
        private void dgvQuanLyThucdon_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
        private void panel4_Paint(object sender, PaintEventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void panel7_Paint(object sender, PaintEventArgs e) { }
        private void txbFoodID_TextChanged(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void txbfoodname_TextChanged(object sender, EventArgs e) { }
        private void panel8_Paint(object sender, PaintEventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void panel9_Paint(object sender, PaintEventArgs e) { }
        private void txbDanhMucFood_TextChanged(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void panel10_Paint(object sender, PaintEventArgs e) { }
        private void txbFoodPrice_TextChanged(object sender, EventArgs e) { }
        private void panel14_Paint(object sender, PaintEventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void txbSoLuong_TextChanged(object sender, EventArgs e) { }
        private void tpquanlynhanvien_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void panel28_Paint(object sender, PaintEventArgs e) { }
        private void drgvnhanvien_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
        private void panel13_Paint(object sender, PaintEventArgs e) { }
        private void gbThongKeNhanVien_Enter(object sender, EventArgs e) { }
        private void panel27_Paint(object sender, PaintEventArgs e) { }
        private void panel16_Paint(object sender, PaintEventArgs e) { }
        private void panel23_Paint(object sender, PaintEventArgs e) { }
        private void panel26_Paint(object sender, PaintEventArgs e) { }
        private void label12_Click(object sender, EventArgs e) { }
        private void txbtentk_TextChanged(object sender, EventArgs e) { }
        private void label11_Click(object sender, EventArgs e) { }
        private void txbtenhienthitk_TextChanged(object sender, EventArgs e) { }
        private void panel24_Paint(object sender, PaintEventArgs e) { }
        private void label10_Click(object sender, EventArgs e) { }
        private void txbtrangthainhanvien_TextChanged(object sender, EventArgs e) { }
        private void label13_Click(object sender, EventArgs e) { }
        private void txbmktk_TextChanged(object sender, EventArgs e) { }
        private void listViewDoanhThu_SelectedIndexChanged(object sender, EventArgs e) { }
        private void ListViewTopSanPhamBanChay_SelectedIndexChanged(object sender, EventArgs e) { }
        private void panel3_Paint(object sender, PaintEventArgs e) { }
        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void panel29_Paint(object sender, PaintEventArgs e) { }
        private void panel25_Paint(object sender, PaintEventArgs e) { }
        private void listViewHoatDong_SelectedIndexChanged(object sender, EventArgs e) { }

        // Sự kiện cho Tab Quản Lý Hoạt Động
        private void tpQuanLyHoatDong_Click(object sender, EventArgs e)
        {
            LoadDanhSachHoatDong();
        }

        private void btnTimKiemHoatDong_Click(object sender, EventArgs e)
        {
            LoadDanhSachHoatDong();
        }

        private void btnlammoi_Click(object sender, EventArgs e)
        {
            dtpkFromdayHoatDong.Value = DateTime.Today.AddDays(-7);
            dtpkTodayHoatDong.Value = DateTime.Today;
            cmbTimKiemHoatDong.SelectedIndex = 0;
            txbTimKiemHoatDong.Clear();
            LoadDanhSachHoatDong();
        }

        private void dtpkFromdayHoatDong_ValueChanged(object sender, EventArgs e)
        {
            if (dtpkFromdayHoatDong.Value > dtpkTodayHoatDong.Value)
            {
                dtpkTodayHoatDong.Value = dtpkFromdayHoatDong.Value;
            }
            LoadDanhSachHoatDong();
        }

        private void dtpkTodayHoatDong_ValueChanged(object sender, EventArgs e)
        {
            if (dtpkTodayHoatDong.Value < dtpkFromdayHoatDong.Value)
            {
                dtpkFromdayHoatDong.Value = dtpkTodayHoatDong.Value;
            }
            LoadDanhSachHoatDong();
        }

        private void cmbTimKiemHoatDong_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoadDanhSachHoatDong();
        }

        private void txbTimKiemHoatDong_TextChanged(object sender, EventArgs e)
        {
            LoadDanhSachHoatDong();
        }

        private void panel15_Paint(object sender, PaintEventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void panel17_Paint(object sender, PaintEventArgs e) { }
        private void panel18_Paint(object sender, PaintEventArgs e) { }
        private void panel19_Paint(object sender, PaintEventArgs e) { }
        private void label8_Click(object sender, EventArgs e) { }
        private void label9_Click(object sender, EventArgs e) { }
        private void txbHoatDongHomNay_TextChanged(object sender, EventArgs e) { }
        private void txbTongSoHoatDong_TextChanged(object sender, EventArgs e) { }

        #endregion

        private void btnQuanLyFile_Click(object sender, EventArgs e)
        {
            // Ẩn form hiện tại
            this.Hide();

            // Mở form mới
            quanlyxuatfile frm = quanlyxuatfile.GetInstance();
            frm.ShowDialog();  // Chờ đến khi form mới đóng

            // Sau khi form mới đóng, hiện lại form cũ
            this.Show();
        }
    }
}
