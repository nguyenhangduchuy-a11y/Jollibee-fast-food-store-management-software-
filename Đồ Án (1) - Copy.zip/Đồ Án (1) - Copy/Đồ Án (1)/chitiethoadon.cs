﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Đồ_Án__1_.BUS;
using Đồ_Án__1_.DAL;
using Đồ_Án__1_.DTO;
using Excel = Microsoft.Office.Interop.Excel;

namespace Đồ_Án__1_
{
    public partial class chitiethoadon : Form
    {
        private readonly int idHoaDon;
        private readonly string maHoaDon;
        private readonly HoaDonDAL hoaDonDAL = new HoaDonDAL();
        private List<HoaDonChiTietDTO> chiTietHoaDon;

        public chitiethoadon(int idHoaDon, string maHoaDon)
        {
            InitializeComponent();
            this.idHoaDon = idHoaDon;
            this.maHoaDon = maHoaDon;
            this.Load += Chitiethoadon_Load;
        }

        private void Chitiethoadon_Load(object sender, EventArgs e)
        {
            SetControlsReadOnly();
            LoadChiTietHoaDon();
        }

        private void SetControlsReadOnly()
        {
            // Thiết lập TextBox ở chế độ chỉ đọc
            txbMaHoaDon.ReadOnly = true;
            txtNgayLap.ReadOnly = true;
            txbLoaiDon.ReadOnly = true;
            txbNhanVien.ReadOnly = true;
            txbTongTien.ReadOnly = true;
            txbGhiChu.ReadOnly = true;

            // Đổi màu nền cho TextBox
            System.Drawing.Color readOnlyColor = System.Drawing.Color.FromArgb(245, 245, 245);
            txbMaHoaDon.BackColor = readOnlyColor;
            txtNgayLap.BackColor = readOnlyColor;
            txbLoaiDon.BackColor = readOnlyColor;
            txbNhanVien.BackColor = readOnlyColor;
            txbTongTien.BackColor = readOnlyColor;
            txbGhiChu.BackColor = readOnlyColor;

            // Thiết lập DataGridView ở chế độ chỉ đọc
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToOrderColumns = false;
            dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;

            // Thiết lập chế độ chọn toàn bộ dòng
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;
        }

        private void LoadChiTietHoaDon()
        {
            try
            {
                chiTietHoaDon = hoaDonDAL.LayChiTietHoaDon(idHoaDon);

                if (chiTietHoaDon == null || chiTietHoaDon.Count == 0)
                {
                    MessageBox.Show("Không có dữ liệu chi tiết hóa đơn!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var firstItem = chiTietHoaDon.FirstOrDefault();
                if (firstItem != null)
                {
                    txbMaHoaDon.Text = firstItem.MaHoaDon;
                    txtNgayLap.Text = firstItem.NgayLapFormat;
                    txbLoaiDon.Text = firstItem.TenLoaiDon;
                    txbNhanVien.Text = string.IsNullOrEmpty(firstItem.TenNhanVien) ? "Khách vãng lai" : firstItem.TenNhanVien;
                    txbTongTien.Text = firstItem.TongTienFormat;
                    txbGhiChu.Text = string.IsNullOrEmpty(firstItem.GhiChu) ? "Không có ghi chú" : firstItem.GhiChu;
                }

                DisplayChiTietSanPham();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tải chi tiết hóa đơn: {ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Lấy phần trăm giảm giá từ chuỗi ghi chú
        /// </summary>
        /// <param name="ghiChu">Chuỗi ghi chú (ví dụ: "Giảm 20%" hoặc "Món A, giảm 15%")</param>
        /// <returns>Phần trăm giảm giá (0 nếu không có)</returns>
        private decimal LayPhanTramGiamTuGhiChu(string ghiChu)
        {
            if (string.IsNullOrEmpty(ghiChu))
                return 0;

            // Tìm số % giảm trong ghi chú: "giảm 20%", "giảm 15.5%"
            var match = Regex.Match(ghiChu, @"giảm\s*(\d+(?:\.\d+)?)%", RegexOptions.IgnoreCase);
            if (match.Success)
            {
                return decimal.Parse(match.Groups[1].Value);
            }
            return 0;
        }

        /// <summary>
        /// Tính giá thực tế sau khi giảm giá
        /// </summary>
        private decimal TinhGiaThucTe(decimal giaGoc, decimal phanTramGiam)
        {
            return giaGoc * (1 - phanTramGiam / 100);
        }

        private void DisplayChiTietSanPham()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("STT", typeof(int));
            dt.Columns.Add("Mã SP", typeof(string));
            dt.Columns.Add("Tên sản phẩm", typeof(string));
            dt.Columns.Add("Số lượng", typeof(int));
            dt.Columns.Add("Đơn giá", typeof(string));
            dt.Columns.Add("Thành tiền", typeof(string));
            dt.Columns.Add("Ghi chú", typeof(string));

            int stt = 1;
            decimal tongTienThucTe = 0;

            foreach (var item in chiTietHoaDon)
            {
                if (item.IDSanPham > 0)
                {
                    // Lấy phần trăm giảm giá từ ghi chú
                    decimal phanTramGiam = LayPhanTramGiamTuGhiChu(item.GhiChuCT);

                    // Tính giá thực tế sau khi giảm
                    decimal donGiaThucTe = TinhGiaThucTe(item.DonGia, phanTramGiam);
                    decimal thanhTienThucTe = donGiaThucTe * item.SoLuong;
                    tongTienThucTe += thanhTienThucTe;

                    dt.Rows.Add(
                        stt++,
                        item.MaSanPham,
                        item.TenSanPham,
                        item.SoLuong,
                        string.Format("{0:N0} đ", donGiaThucTe),
                        string.Format("{0:N0} đ", thanhTienThucTe),
                        string.IsNullOrEmpty(item.GhiChuCT) ? "" : item.GhiChuCT
                    );
                }
            }

            dataGridView1.DataSource = dt;

            // Cập nhật lại tổng tiền hiển thị (nếu có giảm giá)
            if (tongTienThucTe > 0 && tongTienThucTe != (chiTietHoaDon.FirstOrDefault()?.TongTien ?? 0))
            {
                txbTongTien.Text = string.Format("{0:N0} đ", tongTienThucTe);
            }
        }

        private void bntXuatExcel_Click(object sender, EventArgs e)
        {
            if (chiTietHoaDon == null || chiTietHoaDon.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu để xuất!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Excel Files|*.xlsx";
            saveFileDialog.Title = "Xuất hóa đơn ra Excel";
            saveFileDialog.FileName = $"HoaDon_{maHoaDon}_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                Excel.Application excelApp = null;
                Excel.Workbook workbook = null;
                Excel.Worksheet worksheet = null;

                try
                {
                    excelApp = new Excel.Application();
                    excelApp.DisplayAlerts = false;
                    workbook = excelApp.Workbooks.Add();
                    worksheet = (Excel.Worksheet)workbook.Worksheets[1];
                    worksheet.Name = $"HoaDon_{maHoaDon}";

                    var firstItem = chiTietHoaDon.FirstOrDefault();

                    // Header - JOLLIBEE VIETNAM
                    worksheet.Cells[1, 1] = "JOLLIBEE VIETNAM";
                    Excel.Range titleRange = worksheet.Range[worksheet.Cells[1, 1], worksheet.Cells[1, 6]];
                    titleRange.Merge();
                    titleRange.Font.Bold = true;
                    titleRange.Font.Size = 20;
                    titleRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                    // Header - HÓA ĐƠN BÁN HÀNG
                    worksheet.Cells[2, 1] = "HÓA ĐƠN BÁN HÀNG";
                    titleRange = worksheet.Range[worksheet.Cells[2, 1], worksheet.Cells[2, 6]];
                    titleRange.Merge();
                    titleRange.Font.Bold = true;
                    titleRange.Font.Size = 16;
                    titleRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                    // Thông tin hóa đơn
                    worksheet.Cells[3, 1] = $"Mã HD: {maHoaDon}";
                    worksheet.Cells[4, 1] = $"Ngày lập: {(firstItem != null ? firstItem.NgayLapFormat : DateTime.Now.ToString("dd/MM/yyyy HH:mm"))}";
                    worksheet.Cells[5, 1] = $"Nhân viên: {(firstItem != null && !string.IsNullOrEmpty(firstItem.TenNhanVien) ? firstItem.TenNhanVien : "Khách vãng lai")}";
                    worksheet.Cells[6, 1] = $"Loại đơn: {(firstItem != null ? firstItem.TenLoaiDon : "")}";
                    worksheet.Cells[7, 1] = $"Thanh toán: {(firstItem != null ? firstItem.PhuongThucThanhToan : "Tiền mặt")}";

                    // Header bảng chi tiết
                    int row = 9;
                    worksheet.Cells[row, 1] = "STT";
                    worksheet.Cells[row, 2] = "Mã SP";
                    worksheet.Cells[row, 3] = "Tên sản phẩm";
                    worksheet.Cells[row, 4] = "Số lượng";
                    worksheet.Cells[row, 5] = "Đơn giá (VNĐ)";
                    worksheet.Cells[row, 6] = "Thành tiền (VNĐ)";

                    Excel.Range headerRange = worksheet.Range[worksheet.Cells[row, 1], worksheet.Cells[row, 6]];
                    headerRange.Font.Bold = true;
                    headerRange.Interior.Color = System.Drawing.Color.LightGray.ToArgb();
                    headerRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                    headerRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                    // Xuất danh sách sản phẩm
                    int stt = 1;
                    row++;
                    decimal tongTienThucTe = 0;

                    foreach (var item in chiTietHoaDon)
                    {
                        if (item.IDSanPham > 0)
                        {
                            // Tính giá thực tế sau khi giảm giá từ ghi chú
                            decimal phanTramGiam = LayPhanTramGiamTuGhiChu(item.GhiChuCT);
                            decimal donGiaThucTe = TinhGiaThucTe(item.DonGia, phanTramGiam);
                            decimal thanhTienThucTe = donGiaThucTe * item.SoLuong;
                            tongTienThucTe += thanhTienThucTe;

                            worksheet.Cells[row, 1] = stt++;
                            worksheet.Cells[row, 2] = item.MaSanPham;
                            worksheet.Cells[row, 3] = item.TenSanPham;
                            worksheet.Cells[row, 4] = item.SoLuong;
                            worksheet.Cells[row, 5] = donGiaThucTe;
                            worksheet.Cells[row, 6] = thanhTienThucTe;

                            // Nếu có ghi chú giảm giá, thêm vào cột ghi chú (cột 7)
                            if (phanTramGiam > 0)
                            {
                                worksheet.Cells[row, 7] = item.GhiChuCT;
                            }
                            row++;
                        }
                    }

                    // Tổng cộng
                    row++;
                    worksheet.Cells[row, 4] = "TỔNG CỘNG:";
                    worksheet.Cells[row, 6] = tongTienThucTe;

                    Excel.Range totalRange = worksheet.Range[worksheet.Cells[row, 4], worksheet.Cells[row, 6]];
                    totalRange.Font.Bold = true;
                    totalRange.Interior.Color = System.Drawing.Color.LightYellow.ToArgb();
                    totalRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;

                    // Định dạng số tiền
                    Excel.Range priceRange = worksheet.Range[worksheet.Cells[10, 5], worksheet.Cells[row, 6]];
                    priceRange.NumberFormat = "#,##0";

                    // Lời cảm ơn
                    row += 2;
                    worksheet.Cells[row, 1] = "Cảm ơn quý khách! Hẹn gặp lại!";
                    Excel.Range thanksRange = worksheet.Range[worksheet.Cells[row, 1], worksheet.Cells[row, 6]];
                    thanksRange.Merge();
                    thanksRange.Font.Italic = true;
                    thanksRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                    // Kẻ khung
                    Excel.Range dataRange = worksheet.Range[worksheet.Cells[9, 1], worksheet.Cells[row - 3, 7]];
                    dataRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;

                    // Tự động chỉnh độ rộng cột
                    worksheet.Columns.AutoFit();

                    // Lưu file
                    workbook.SaveAs(saveFileDialog.FileName);

                    MessageBox.Show($"Xuất hóa đơn thành công!\nĐường dẫn: {saveFileDialog.FileName}",
                        "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    if (MessageBox.Show("Bạn có muốn mở file vừa xuất không?", "Thông báo",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        System.Diagnostics.Process.Start(saveFileDialog.FileName);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi xuất Excel: {ex.Message}", "Lỗi",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if (workbook != null)
                    {
                        try
                        {
                            workbook.Close(false);
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                        }
                        catch { }
                    }
                    if (excelApp != null)
                    {
                        try
                        {
                            excelApp.Quit();
                            System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                        }
                        catch { }
                    }
                }
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Các sự kiện giữ nguyên
        private void panel1_Paint(object sender, PaintEventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void panel2_Paint(object sender, PaintEventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void txbMaHoaDon_TextChanged(object sender, EventArgs e) { }
        private void txbNhanVien_TextChanged(object sender, EventArgs e) { }
        private void txtNgayLap_TextChanged(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void txbLoaiDon_TextChanged(object sender, EventArgs e) { }
        private void txbGhiChu_TextChanged(object sender, EventArgs e) { }
        private void panel3_Paint(object sender, PaintEventArgs e) { }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void txbTongTien_TextChanged(object sender, EventArgs e) { }
        private void panel4_Paint(object sender, PaintEventArgs e) { }
    }
}