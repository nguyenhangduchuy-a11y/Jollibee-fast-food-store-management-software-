﻿// BUS/NguoiDungBUS.cs
using System;
using System.Collections.Generic;
using Đồ_Án__1_.DAL;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.BUS
{
    public class NguoiDungBUS
    {
        private readonly NguoiDungDAL nguoiDungDAL = new NguoiDungDAL();

        public NguoiDungDTO DangNhap(string tenDangNhap, string matKhau)
        {
            tenDangNhap = ChuanHoa(tenDangNhap);

            if (string.IsNullOrWhiteSpace(tenDangNhap))
                throw new ArgumentException("Tên đăng nhập không được để trống.");

            if (string.IsNullOrWhiteSpace(matKhau))
                throw new ArgumentException("Mật khẩu không được để trống.");

            return nguoiDungDAL.DangNhap(tenDangNhap, matKhau);
        }

        public int DangKyKhachHang(string tenDangNhap, string matKhau, string hoTen)
        {
            KiemTraThongTinTaiKhoan(tenDangNhap, matKhau, hoTen);

            tenDangNhap = ChuanHoa(tenDangNhap);
            hoTen = ChuanHoa(hoTen);

            if (nguoiDungDAL.TonTaiTenDangNhap(tenDangNhap))
                throw new InvalidOperationException("Tên đăng nhập đã tồn tại.");

            int idMoi = nguoiDungDAL.DangKyKhachHang(tenDangNhap, matKhau, hoTen);

            if (idMoi <= 0)
                throw new InvalidOperationException("Đăng ký không thành công.");

            return idMoi;
        }

        public bool ThemNhanVien(string tenDangNhap, string matKhau, string hoTen)
        {
            KiemTraThongTinTaiKhoan(tenDangNhap, matKhau, hoTen);

            tenDangNhap = ChuanHoa(tenDangNhap);
            hoTen = ChuanHoa(hoTen);

            if (nguoiDungDAL.TonTaiTenDangNhap(tenDangNhap))
                throw new InvalidOperationException("Tên đăng nhập đã tồn tại.");

            return nguoiDungDAL.ThemNhanVien(tenDangNhap, matKhau, hoTen);
        }

        public bool DoiMatKhau(int idNguoiDung, string matKhauCu, string matKhauMoi)
        {
            if (idNguoiDung <= 0)
                throw new ArgumentException("ID người dùng không hợp lệ.");

            if (string.IsNullOrWhiteSpace(matKhauCu))
                throw new ArgumentException("Mật khẩu cũ không được để trống.");

            if (string.IsNullOrWhiteSpace(matKhauMoi) || matKhauMoi.Length < 6)
                throw new ArgumentException("Mật khẩu mới phải có ít nhất 6 ký tự.");

            if (matKhauCu == matKhauMoi)
                throw new ArgumentException("Mật khẩu mới phải khác mật khẩu cũ.");

            if (!nguoiDungDAL.TonTaiNguoiDung(idNguoiDung))
                throw new InvalidOperationException("Người dùng không tồn tại.");

            return nguoiDungDAL.DoiMatKhau(idNguoiDung, matKhauCu, matKhauMoi);
        }

        public List<NguoiDungDTO> LayDanhSachNguoiDung()
        {
            return nguoiDungDAL.LayDanhSachNguoiDung();
        }

        public List<NguoiDungDTO> LayDanhSachNhanVien()
        {
            return nguoiDungDAL.LayDanhSachNhanVien();
        }

        public List<NguoiDungDTO> LayDanhSachKhachHang()
        {
            return nguoiDungDAL.LayDanhSachKhachHang();
        }

        public NguoiDungDTO LayTheoID(int idNguoiDung)
        {
            if (idNguoiDung <= 0)
                throw new ArgumentException("ID người dùng không hợp lệ.");

            return nguoiDungDAL.LayTheoID(idNguoiDung);
        }

        public bool CapNhatNguoiDung(NguoiDungDTO nguoiDung)
        {
            if (nguoiDung == null)
                throw new ArgumentNullException("nguoiDung");

            if (nguoiDung.IDNguoiDung <= 0)
                throw new ArgumentException("ID người dùng không hợp lệ.");

            if (!nguoiDungDAL.TonTaiNguoiDung(nguoiDung.IDNguoiDung))
                throw new InvalidOperationException("Người dùng không tồn tại.");

            if (string.IsNullOrWhiteSpace(nguoiDung.HoTen))
                throw new ArgumentException("Họ tên không được để trống.");

            if (nguoiDung.VaiTro < 1 || nguoiDung.VaiTro > 3)
                throw new ArgumentException("Vai trò không hợp lệ.");

            nguoiDung.HoTen = ChuanHoa(nguoiDung.HoTen);

            return nguoiDungDAL.CapNhatNguoiDung(nguoiDung);
        }

        public bool KhoaTaiKhoan(int idNguoiDung)
        {
            return KhoaMoTaiKhoan(idNguoiDung, false);
        }

        public bool MoKhoaTaiKhoan(int idNguoiDung)
        {
            return KhoaMoTaiKhoan(idNguoiDung, true);
        }

        private bool KhoaMoTaiKhoan(int idNguoiDung, bool kichHoat)
        {
            if (idNguoiDung <= 0)
                throw new ArgumentException("ID người dùng không hợp lệ.");

            if (!nguoiDungDAL.TonTaiNguoiDung(idNguoiDung))
                throw new InvalidOperationException("Người dùng không tồn tại.");

            return nguoiDungDAL.KhoaMoTaiKhoan(idNguoiDung, kichHoat);
        }

        private void KiemTraThongTinTaiKhoan(string tenDangNhap, string matKhau, string hoTen)
        {
            if (string.IsNullOrWhiteSpace(tenDangNhap) || tenDangNhap.Trim().Length < 3)
                throw new ArgumentException("Tên đăng nhập phải có ít nhất 3 ký tự.");

            if (tenDangNhap.Trim().Length > 50)
                throw new ArgumentException("Tên đăng nhập không được vượt quá 50 ký tự.");

            if (string.IsNullOrWhiteSpace(matKhau) || matKhau.Length < 6)
                throw new ArgumentException("Mật khẩu phải có ít nhất 6 ký tự.");

            if (string.IsNullOrWhiteSpace(hoTen))
                throw new ArgumentException("Họ tên không được để trống.");

            if (hoTen.Trim().Length > 100)
                throw new ArgumentException("Họ tên không được vượt quá 100 ký tự.");
        }

        private string ChuanHoa(string value)
        {
            if (value == null)
                return string.Empty;
            return value.Trim();
        }
    }
}