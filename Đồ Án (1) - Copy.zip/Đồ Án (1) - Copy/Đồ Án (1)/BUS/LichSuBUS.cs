﻿// BUS/LichSuBUS.cs
using System;
using System.Collections.Generic;
using Đồ_Án__1_.DAL;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.BUS
{
    public class LichSuBUS
    {
        private readonly LichSuDAL lichSuDAL = new LichSuDAL();
        private readonly ChiTietHoaDonDAL chiTietDAL = new ChiTietHoaDonDAL();

        public List<HoaDonDTO> LayTheoNhanVien(int idNhanVien, DateTime? ngay = null)
        {
            if (idNhanVien <= 0)
                throw new ArgumentException("ID nhân viên không hợp lệ.");

            return lichSuDAL.LayTheoNhanVien(idNhanVien, ngay);
        }

        public List<HoaDonDTO> LayHomNayTheoNhanVien(int idNhanVien)
        {
            return LayTheoNhanVien(idNhanVien, DateTime.Today);
        }

        public List<HoaDonDTO> LayTheoKhachHang(int idKhachHang)
        {
            if (idKhachHang <= 0)
                throw new ArgumentException("ID khách hàng không hợp lệ.");

            return lichSuDAL.LayTheoKhachHang(idKhachHang);
        }

        public List<HoaDonDTO> LayTheoThoiGian(DateTime tuNgay, DateTime denNgay)
        {
            if (tuNgay.Date > denNgay.Date)
                throw new ArgumentException("Từ ngày không được lớn hơn đến ngày.");

            return lichSuDAL.LayTheoThoiGian(tuNgay, denNgay);
        }

        public List<HoaDonDTO> LayHomNay()
        {
            return LayTheoThoiGian(DateTime.Today, DateTime.Today);
        }

        public List<HoaDonDTO> LayTuanNay()
        {
            DateTime dauTuan = LayNgayDauTuan(DateTime.Today);
            DateTime cuoiTuan = dauTuan.AddDays(6);

            return LayTheoThoiGian(dauTuan, cuoiTuan);
        }

        public List<HoaDonDTO> LayThangNay()
        {
            DateTime dauThang = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            DateTime cuoiThang = dauThang.AddMonths(1).AddDays(-1);

            return LayTheoThoiGian(dauThang, cuoiThang);
        }

        public List<ChiTietHoaDonDTO> LayChiTietHoaDon(int idHoaDon)
        {
            if (idHoaDon <= 0)
                throw new ArgumentException("ID hóa đơn không hợp lệ.");

            return chiTietDAL.LayTheoHoaDon(idHoaDon);
        }

        private DateTime LayNgayDauTuan(DateTime ngay)
        {
            int diff = ((int)ngay.DayOfWeek + 6) % 7;
            return ngay.Date.AddDays(-diff);
        }
    }
}