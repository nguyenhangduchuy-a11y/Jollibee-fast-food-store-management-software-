﻿// BUS/BanAnBUS.cs
using System;
using System.Collections.Generic;
using Đồ_Án__1_.DAL;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.BUS
{
    public class BanAnBUS
    {
        private readonly BanAnDAL banAnDAL = new BanAnDAL();

        public List<BanAnDTO> LayDanhSachBan()
        {
            return banAnDAL.LayDanhSachBan();
        }

        public List<BanAnDTO> LayBanTrong()
        {
            return banAnDAL.LayBanTrong();
        }

        public List<BanAnDTO> LayBanDangDung()
        {
            List<BanAnDTO> danhSach = LayDanhSachBan();
            List<BanAnDTO> ketQua = new List<BanAnDTO>();

            foreach (BanAnDTO ban in danhSach)
            {
                if (ban.TrangThai == 1)
                {
                    ketQua.Add(ban);
                }
            }

            return ketQua;
        }

        public List<BanAnDTO> LayBanCanDon()
        {
            List<BanAnDTO> danhSach = LayDanhSachBan();
            List<BanAnDTO> ketQua = new List<BanAnDTO>();

            foreach (BanAnDTO ban in danhSach)
            {
                if (ban.TrangThai == 2)
                {
                    ketQua.Add(ban);
                }
            }

            return ketQua;
        }

        public BanAnDTO LayTheoID(int idBan)
        {
            if (idBan <= 0)
                throw new ArgumentException("ID bàn không hợp lệ.");

            return banAnDAL.LayTheoID(idBan);
        }

        public bool Them(BanAnDTO ban)
        {
            KiemTraBan(ban, true);

            ban.TenBan = ban.TenBan.Trim();
            ban.TrangThai = 0;

            if (banAnDAL.TonTaiTenBan(ban.TenBan))
                throw new InvalidOperationException("Tên bàn đã tồn tại.");

            return banAnDAL.Them(ban);
        }

        public bool Sua(BanAnDTO ban)
        {
            KiemTraBan(ban, false);

            ban.TenBan = ban.TenBan.Trim();

            if (banAnDAL.LayTheoID(ban.IDBan) == null)
                throw new InvalidOperationException("Bàn không tồn tại.");

            if (banAnDAL.TonTaiTenBan(ban.TenBan, ban.IDBan))
                throw new InvalidOperationException("Tên bàn đã tồn tại.");

            if (ban.TrangThai < 0 || ban.TrangThai > 2)
                throw new ArgumentException("Trạng thái bàn không hợp lệ.");

            return banAnDAL.Sua(ban);
        }

        public bool Xoa(int idBan)
        {
            if (idBan <= 0)
                throw new ArgumentException("ID bàn không hợp lệ.");

            BanAnDTO ban = banAnDAL.LayTheoID(idBan);

            if (ban == null)
                throw new InvalidOperationException("Bàn không tồn tại.");

            if (ban.TrangThai != 0)
                throw new InvalidOperationException("Chỉ được xóa bàn đang trống.");

            return banAnDAL.Xoa(idBan);
        }

        public bool CapNhatTrangThai(int idBan, int trangThai)
        {
            if (idBan <= 0)
                throw new ArgumentException("ID bàn không hợp lệ.");

            if (trangThai < 0 || trangThai > 2)
                throw new ArgumentException("Trạng thái bàn không hợp lệ.");

            if (banAnDAL.LayTheoID(idBan) == null)
                throw new InvalidOperationException("Bàn không tồn tại.");

            return banAnDAL.CapNhatTrangThai(idBan, trangThai);
        }

        public bool DonBan(int idBan)
        {
            BanAnDTO ban = LayTheoID(idBan);

            if (ban == null)
                throw new InvalidOperationException("Bàn không tồn tại.");

            if (ban.TrangThai != 2)
                throw new InvalidOperationException("Bàn không ở trạng thái cần dọn.");

            return banAnDAL.DonBan(idBan);
        }

        public int DemBanTrong()
        {
            return LayBanTrong().Count;
        }

        public int DemBanDangDung()
        {
            return LayBanDangDung().Count;
        }

        public int DemBanCanDon()
        {
            return LayBanCanDon().Count;
        }

        private void KiemTraBan(BanAnDTO ban, bool laThemMoi)
        {
            if (ban == null)
                throw new ArgumentNullException("ban");

            if (!laThemMoi && ban.IDBan <= 0)
                throw new ArgumentException("ID bàn không hợp lệ.");

            if (string.IsNullOrWhiteSpace(ban.TenBan))
                throw new ArgumentException("Tên bàn không được để trống.");

            if (ban.TenBan.Trim().Length > 20)
                throw new ArgumentException("Tên bàn không được vượt quá 20 ký tự.");
        }
    }
}