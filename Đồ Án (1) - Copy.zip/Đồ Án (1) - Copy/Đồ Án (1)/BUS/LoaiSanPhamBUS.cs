﻿// BUS/LoaiSanPhamBUS.cs
using System;
using System.Collections.Generic;
using Đồ_Án__1_.DAL;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.BUS
{
    public class LoaiSanPhamBUS
    {
        private readonly LoaiSanPhamDAL loaiSanPhamDAL = new LoaiSanPhamDAL();

        public List<LoaiSanPhamDTO> LayDanhSach(bool chiLayDangHoatDong = true)
        {
            return loaiSanPhamDAL.LayDanhSach(chiLayDangHoatDong);
        }

        public List<LoaiSanPhamDTO> LayDanhSachDangHoatDong()
        {
            return LayDanhSach(true);
        }

        public List<LoaiSanPhamDTO> LayTatCa()
        {
            return LayDanhSach(false);
        }

        public LoaiSanPhamDTO LayTheoID(int idLoai)
        {
            if (idLoai <= 0)
                throw new ArgumentException("ID loại sản phẩm không hợp lệ.");

            List<LoaiSanPhamDTO> danhSach = LayTatCa();

            foreach (LoaiSanPhamDTO loai in danhSach)
            {
                if (loai.IDLoai == idLoai)
                {
                    return loai;
                }
            }

            return null;
        }

        public bool Them(LoaiSanPhamDTO loai)
        {
            KiemTraLoaiSanPham(loai, true);

            loai.TenLoai = loai.TenLoai.Trim();

            if (loaiSanPhamDAL.TonTaiTenLoai(loai.TenLoai))
                throw new InvalidOperationException("Tên loại sản phẩm đã tồn tại.");

            loai.KichHoat = true;

            return loaiSanPhamDAL.Them(loai);
        }

        public bool Sua(LoaiSanPhamDTO loai)
        {
            KiemTraLoaiSanPham(loai, false);

            if (loai.IDLoai <= 0)
                throw new ArgumentException("ID loại sản phẩm không hợp lệ.");

            loai.TenLoai = loai.TenLoai.Trim();

            if (loaiSanPhamDAL.TonTaiTenLoai(loai.TenLoai, loai.IDLoai))
                throw new InvalidOperationException("Tên loại sản phẩm đã tồn tại.");

            return loaiSanPhamDAL.Sua(loai);
        }

        public bool Xoa(int idLoai)
        {
            if (idLoai <= 0)
                throw new ArgumentException("ID loại sản phẩm không hợp lệ.");

            LoaiSanPhamDTO loai = LayTheoID(idLoai);

            if (loai == null)
                throw new InvalidOperationException("Loại sản phẩm không tồn tại.");

            if (!loai.KichHoat)
                throw new InvalidOperationException("Loại sản phẩm đã bị khóa trước đó.");

            return loaiSanPhamDAL.Xoa(idLoai);
        }

        public bool KichHoat(int idLoai, bool kichHoat)
        {
            if (idLoai <= 0)
                throw new ArgumentException("ID loại sản phẩm không hợp lệ.");

            LoaiSanPhamDTO loai = LayTheoID(idLoai);

            if (loai == null)
                throw new InvalidOperationException("Loại sản phẩm không tồn tại.");

            loai.KichHoat = kichHoat;

            return loaiSanPhamDAL.Sua(loai);
        }

        public bool Khoa(int idLoai)
        {
            return KichHoat(idLoai, false);
        }

        public bool MoKhoa(int idLoai)
        {
            return KichHoat(idLoai, true);
        }

        public bool TonTaiLoaiSanPham(int idLoai)
        {
            if (idLoai <= 0)
                return false;

            return LayTheoID(idLoai) != null;
        }

        public bool TonTaiTenLoai(string tenLoai, int? boQuaID = null)
        {
            if (string.IsNullOrWhiteSpace(tenLoai))
                return false;

            tenLoai = tenLoai.Trim();

            return loaiSanPhamDAL.TonTaiTenLoai(tenLoai, boQuaID);
        }

        public int DemSoLuong()
        {
            return LayTatCa().Count;
        }

        public int DemSoLuongDangHoatDong()
        {
            return LayDanhSachDangHoatDong().Count;
        }

        private void KiemTraLoaiSanPham(LoaiSanPhamDTO loai, bool laThemMoi)
        {
            if (loai == null)
                throw new ArgumentNullException("loai");

            if (!laThemMoi && loai.IDLoai <= 0)
                throw new ArgumentException("ID loại sản phẩm không hợp lệ.");

            if (string.IsNullOrWhiteSpace(loai.TenLoai))
                throw new ArgumentException("Tên loại sản phẩm không được để trống.");

            if (loai.TenLoai.Trim().Length > 50)
                throw new ArgumentException("Tên loại sản phẩm không được vượt quá 50 ký tự.");
        }
    }
}