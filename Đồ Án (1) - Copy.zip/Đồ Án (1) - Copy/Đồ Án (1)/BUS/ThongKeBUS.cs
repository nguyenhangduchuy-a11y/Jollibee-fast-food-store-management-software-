﻿// BUS/ThongKeBUS.cs
using System;
using System.Collections.Generic;
using Đồ_Án__1_.DAL;
using Đồ_Án__1_.DAL;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.BUS
{
    public class ThongKeBUS
    {
        private readonly ThongKeDAL thongKeDAL = new ThongKeDAL();
        private readonly SanPhamDAL sanPhamDAL = new SanPhamDAL();

        public List<DoanhThuDTO> BaoCaoDoanhThu(DateTime tuNgay, DateTime denNgay)
        {
            KiemTraKhoangNgay(tuNgay, denNgay);
            return thongKeDAL.BaoCaoDoanhThu(tuNgay, denNgay);
        }

        public List<TopSanPhamBanChayDTO> TopSanPhamBanChay(int top = 5)
        {
            if (top <= 0)
                throw new ArgumentException("Số lượng top phải lớn hơn 0.");

            if (top > 100)
                top = 100;

            return thongKeDAL.TopSanPhamBanChay(top);
        }

        public List<CanhBaoTonKhoDTO> CanhBaoTonKho()
        {
            return sanPhamDAL.CanhBaoTonKho();
        }

        public decimal TinhTongDoanhThu(DateTime tuNgay, DateTime denNgay)
        {
            List<DoanhThuDTO> doanhThuList = BaoCaoDoanhThu(tuNgay, denNgay);
            decimal tong = 0;

            foreach (DoanhThuDTO dt in doanhThuList)
            {
                tong += dt.DoanhThu;
            }

            return tong;
        }

        public int TinhTongSoDon(DateTime tuNgay, DateTime denNgay)
        {
            List<DoanhThuDTO> doanhThuList = BaoCaoDoanhThu(tuNgay, denNgay);
            int tong = 0;

            foreach (DoanhThuDTO dt in doanhThuList)
            {
                tong += dt.SoDon;
            }

            return tong;
        }

        public List<DoanhThuDTO> BaoCaoDoanhThuTheoQuy(int nam, int quy)
        {
            if (quy < 1 || quy > 4)
                throw new ArgumentException("Quý không hợp lệ.");

            DateTime tuNgay = new DateTime(nam, (quy - 1) * 3 + 1, 1);
            DateTime denNgay = tuNgay.AddMonths(3).AddDays(-1);

            return BaoCaoDoanhThu(tuNgay, denNgay);
        }

        public List<DoanhThuDTO> BaoCaoDoanhThuTheoNam(int nam)
        {
            if (nam < 2000 || nam > DateTime.Now.Year + 10)
                throw new ArgumentException("Năm không hợp lệ.");

            return BaoCaoDoanhThu(new DateTime(nam, 1, 1), new DateTime(nam, 12, 31));
        }

        private void KiemTraKhoangNgay(DateTime tuNgay, DateTime denNgay)
        {
            if (tuNgay.Date > denNgay.Date)
                throw new ArgumentException("Từ ngày không được lớn hơn đến ngày.");
        }
    }
}