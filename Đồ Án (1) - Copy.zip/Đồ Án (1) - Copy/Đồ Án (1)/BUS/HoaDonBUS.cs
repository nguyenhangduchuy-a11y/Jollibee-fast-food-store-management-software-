﻿// BUS/HoaDonBUS.cs
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Đồ_Án__1_.DAL;
using Đồ_Án__1_.DTO;
using Đồ_Án__1_.Utils;

namespace Đồ_Án__1_.BUS
{
    public class HoaDonBUS
    {
        private readonly HoaDonDAL hoaDonDAL = new HoaDonDAL();
        private readonly BanAnDAL banAnDAL = new BanAnDAL();

        // =====================================================
        // CÁC PHƯƠNG THỨC HIỆN CÓ (GIỮ NGUYÊN)
        // =====================================================

        public int TaoHoaDon(HoaDonDTO hoaDon, List<ChiTietHoaDonDTO> chiTietList, out string maHoaDon)
        {
            KiemTraHoaDon(hoaDon, chiTietList);

            hoaDon.PhuongThucThanhToan = string.IsNullOrWhiteSpace(hoaDon.PhuongThucThanhToan)
                ? "Tiền mặt"
                : hoaDon.PhuongThucThanhToan.Trim();

            hoaDon.GhiChu = string.IsNullOrWhiteSpace(hoaDon.GhiChu) ? null : hoaDon.GhiChu.Trim();

            List<ChiTietHoaDonDTO> chiTietDaGop = GopChiTietTrungSanPham(chiTietList);

            return hoaDonDAL.TaoHoaDon(hoaDon, chiTietDaGop, out maHoaDon);
        }

        public bool HoanTatThanhToan(int idHoaDon, string phuongThucThanhToan)
        {
            if (idHoaDon <= 0)
                throw new ArgumentException("ID hóa đơn không hợp lệ.");

            if (string.IsNullOrWhiteSpace(phuongThucThanhToan))
                throw new ArgumentException("Phương thức thanh toán không được để trống.");

            HoaDonDTO hoaDon = hoaDonDAL.LayTheoID(idHoaDon);

            if (hoaDon == null)
                throw new InvalidOperationException("Hóa đơn không tồn tại.");

            if (hoaDon.TrangThai == 1)
                throw new InvalidOperationException("Hóa đơn đã được thanh toán.");

            bool ok = hoaDonDAL.HoanTatThanhToan(idHoaDon, phuongThucThanhToan.Trim());

            if (!ok)
                throw new InvalidOperationException("Không thể thanh toán hóa đơn.");

            return true;
        }

        // =====================================================
        // PHƯƠNG THỨC MỚI CHO ĐẶT HÀNG CỦA KHÁCH
        // =====================================================

        /// <summary>
        /// Tạo đơn hàng chờ (khách hàng order)
        /// </summary>
        public int TaoDonHangCho(HoaDonDTO hoaDon, List<ChiTietHoaDonDTO> chiTietList, out string maHoaDon)
        {
            if (hoaDon == null)
                throw new ArgumentNullException("hoaDon");

            if (chiTietList == null || chiTietList.Count == 0)
                throw new ArgumentException("Đơn hàng phải có ít nhất một sản phẩm.");

            if (hoaDon.LoaiDon != 3)
                throw new ArgumentException("Phương thức này chỉ dùng cho đơn tự order (LoaiDon=3).");

            if (!hoaDon.IDKhachHang.HasValue || hoaDon.IDKhachHang.Value <= 0)
                throw new ArgumentException("Đơn tự order phải có khách hàng.");

            // Tạo đơn hàng chờ
            int idHoaDon = hoaDonDAL.TaoDonHangCho(hoaDon, out maHoaDon);

            // Thêm chi tiết đơn hàng
            foreach (ChiTietHoaDonDTO ct in chiTietList)
            {
                hoaDonDAL.ThemChiTietDonCho(idHoaDon, ct);
            }

            return idHoaDon;
        }

        /// <summary>
        /// Lấy danh sách đơn hàng chờ xác nhận
        /// </summary>
        public List<HoaDonDTO> LayDonChoXacNhan()
        {
            return hoaDonDAL.LayDonChoXacNhan();
        }

        /// <summary>
        /// Xác nhận đơn hàng (nhân viên duyệt)
        /// ✅ ĐÃ SỬA: Bỏ tham số idNhanVien, chỉ truyền ghi chú
        /// </summary>
        public bool XacNhanDonHang(int idHoaDon, string ghiChu = null)
        {
            if (idHoaDon <= 0)
                throw new ArgumentException("ID đơn hàng không hợp lệ.");

            // Ghi log trước khi xác nhận
            LogHelper.LogNhanh($"Nhân viên {SessionManager.GetCurrentUserName()} đang xác nhận đơn hàng #{idHoaDon}");

            // Gọi DAL với 2 tham số (idHoaDon, ghiChu)
            bool ketQua = hoaDonDAL.XacNhanDonHang(idHoaDon, ghiChu);

            if (ketQua)
            {
                LogHelper.LogNhanh($"Nhân viên {SessionManager.GetCurrentUserName()} đã xác nhận thành công đơn hàng #{idHoaDon}");
            }
            else
            {
                LogHelper.LogNhanh($"Nhân viên {SessionManager.GetCurrentUserName()} xác nhận đơn hàng #{idHoaDon} thất bại");
            }

            return ketQua;
        }

        /// <summary>
        /// Từ chối/Hủy đơn hàng
        /// ✅ ĐÃ SỬA: Bỏ tham số idNhanVien, chỉ truyền lý do
        /// </summary>
        public bool TuChoiDonHang(int idHoaDon, string lyDo)
        {
            if (idHoaDon <= 0)
                throw new ArgumentException("ID đơn hàng không hợp lệ.");

            if (string.IsNullOrWhiteSpace(lyDo))
                throw new ArgumentException("Vui lòng nhập lý do từ chối.");

            // Ghi log trước khi từ chối
            LogHelper.LogNhanh($"Nhân viên {SessionManager.GetCurrentUserName()} đang từ chối đơn hàng #{idHoaDon} - Lý do: {lyDo}");

            // Gọi DAL với 2 tham số (idHoaDon, lyDo)
            bool ketQua = hoaDonDAL.TuChoiDonHang(idHoaDon, lyDo);

            if (ketQua)
            {
                LogHelper.LogNhanh($"Nhân viên {SessionManager.GetCurrentUserName()} đã từ chối đơn hàng #{idHoaDon} - Lý do: {lyDo}");
            }
            else
            {
                LogHelper.LogNhanh($"Nhân viên {SessionManager.GetCurrentUserName()} từ chối đơn hàng #{idHoaDon} thất bại");
            }

            return ketQua;
        }

        /// <summary>
        /// Lấy lịch sử đơn hàng của khách
        /// </summary>
        public DataTable LayLichSuDonHangKhachHang(int idKhachHang, DateTime? tuNgay = null, DateTime? denNgay = null)
        {
            if (idKhachHang <= 0)
                throw new ArgumentException("ID khách hàng không hợp lệ.");

            return hoaDonDAL.LayLichSuDonHangKhachHang(idKhachHang, tuNgay, denNgay);
        }

        /// <summary>
        /// Đếm số đơn hàng chờ xác nhận
        /// </summary>
        public int DemDonChoXacNhan()
        {
            return hoaDonDAL.DemDonChoXacNhan();
        }

        // =====================================================
        // CÁC PHƯƠNG THỨC HIỆN CÓ (GIỮ NGUYÊN)
        // =====================================================

        public HoaDonDTO LayTheoID(int idHoaDon)
        {
            if (idHoaDon <= 0)
                throw new ArgumentException("ID hóa đơn không hợp lệ.");

            return hoaDonDAL.LayTheoID(idHoaDon);
        }

        public List<HoaDonDTO> LayTatCa()
        {
            return hoaDonDAL.LayTatCa();
        }

        public List<HoaDonDTO> LayTheoNgay(DateTime tuNgay, DateTime denNgay)
        {
            if (tuNgay.Date > denNgay.Date)
                throw new ArgumentException("Từ ngày không được lớn hơn đến ngày.");

            return hoaDonDAL.LayTheoNgay(tuNgay, denNgay);
        }

        public List<HoaDonDTO> LayHoaDonHomNay()
        {
            return LayTheoNgay(DateTime.Today, DateTime.Today);
        }

        public decimal TinhTongDoanhThuHomNay()
        {
            List<HoaDonDTO> ds = LayHoaDonHomNay();
            decimal tong = 0;

            foreach (HoaDonDTO hd in ds)
            {
                if (hd.TrangThai == 1)
                {
                    tong += hd.TongTien;
                }
            }

            return tong;
        }

        public int DemSoDonHomNay()
        {
            List<HoaDonDTO> ds = LayHoaDonHomNay();
            int dem = 0;

            foreach (HoaDonDTO hd in ds)
            {
                if (hd.TrangThai == 1)
                {
                    dem++;
                }
            }

            return dem;
        }

        public List<HoaDonChiTietDTO> LayChiTietHoaDon(int idHoaDon)
        {
            if (idHoaDon <= 0)
                throw new ArgumentException("ID hóa đơn không hợp lệ.");

            return hoaDonDAL.LayChiTietHoaDon(idHoaDon);
        }

        private void KiemTraHoaDon(HoaDonDTO hoaDon, List<ChiTietHoaDonDTO> chiTietList)
        {
            if (hoaDon == null)
                throw new ArgumentNullException("hoaDon");

            if (chiTietList == null || chiTietList.Count == 0)
                throw new ArgumentException("Hóa đơn phải có ít nhất một sản phẩm.");

            if (hoaDon.LoaiDon < 1 || hoaDon.LoaiDon > 3)
                throw new ArgumentException("Loại đơn không hợp lệ.");

            if (hoaDon.LoaiDon == 1)
            {
                if (!hoaDon.IDBan.HasValue || hoaDon.IDBan.Value <= 0)
                    throw new ArgumentException("Đơn ăn tại bàn phải chọn bàn.");

                BanAnDTO ban = banAnDAL.LayTheoID(hoaDon.IDBan.Value);

                if (ban == null)
                    throw new InvalidOperationException("Bàn không tồn tại.");

                if (!hoaDon.IDNhanVien.HasValue || hoaDon.IDNhanVien.Value <= 0)
                    throw new ArgumentException("Đơn ăn tại bàn phải có nhân viên.");
            }

            if (hoaDon.LoaiDon == 2)
            {
                if (hoaDon.IDBan.HasValue)
                    throw new ArgumentException("Đơn mang về không được chọn bàn.");

                if (!hoaDon.IDNhanVien.HasValue || hoaDon.IDNhanVien.Value <= 0)
                    throw new ArgumentException("Đơn mang về phải có nhân viên.");
            }

            if (hoaDon.LoaiDon == 3)
            {
                if (hoaDon.IDBan.HasValue)
                    throw new ArgumentException("Đơn tự order không được chọn bàn.");

                if (!hoaDon.IDKhachHang.HasValue || hoaDon.IDKhachHang.Value <= 0)
                    throw new ArgumentException("Đơn tự order phải có khách hàng.");
            }

            foreach (ChiTietHoaDonDTO ct in chiTietList)
            {
                if (ct.IDSanPham <= 0)
                    throw new ArgumentException("ID sản phẩm không hợp lệ.");

                if (ct.SoLuong <= 0)
                    throw new ArgumentException("Số lượng sản phẩm phải lớn hơn 0.");
            }
        }

        private List<ChiTietHoaDonDTO> GopChiTietTrungSanPham(List<ChiTietHoaDonDTO> chiTietList)
        {
            var groups = new Dictionary<string, ChiTietHoaDonDTO>();

            foreach (ChiTietHoaDonDTO ct in chiTietList)
            {
                string key = ct.IDSanPham.ToString() + "|" + (ct.GhiChu?.Trim() ?? "");

                if (groups.ContainsKey(key))
                {
                    groups[key].SoLuong += ct.SoLuong;
                }
                else
                {
                    groups[key] = new ChiTietHoaDonDTO
                    {
                        IDSanPham = ct.IDSanPham,
                        GhiChu = string.IsNullOrWhiteSpace(ct.GhiChu) ? null : ct.GhiChu.Trim(),
                        SoLuong = ct.SoLuong
                    };
                }
            }

            List<ChiTietHoaDonDTO> result = new List<ChiTietHoaDonDTO>();
            foreach (ChiTietHoaDonDTO item in groups.Values)
            {
                result.Add(item);
            }

            return result;
        }
    }
}