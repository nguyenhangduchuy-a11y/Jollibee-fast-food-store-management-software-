﻿// BUS/LichSuHoatDongBUS.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using Đồ_Án__1_.DAL;
using Đồ_Án__1_.DTO;
using Đồ_Án__1_.Utils;

namespace Đồ_Án__1_.BUS
{
    /// <summary>
    /// BUS cho bảng LichSuHoatDong - Xử lý nghiệp vụ và ghi log
    /// </summary>
    public class LichSuHoatDongBUS
    {
        private readonly LichSuHoatDongDAL lichSuDAL = new LichSuHoatDongDAL();

        #region Ghi log cơ bản

        /// <summary>
        /// Ghi log một hoạt động bất kỳ
        /// </summary>
        /// <param name="hanhDong">Hành động (dùng hằng số từ HanhDongHeThong)</param>
        /// <param name="doiTuong">Đối tượng (dùng hằng số từ DoiTuongHeThong)</param>
        /// <param name="idDoiTuong">ID của đối tượng (có thể null)</param>
        /// <param name="chiTiet">Chi tiết hành động</param>
        /// <returns>ID của bản ghi vừa thêm (0 nếu thất bại)</returns>
        public int GhiLog(string hanhDong, string doiTuong, int? idDoiTuong = null, string chiTiet = null)
        {
            try
            {
                LichSuHoatDongDTO log = new LichSuHoatDongDTO
                {
                    HanhDong = hanhDong,
                    DoiTuong = doiTuong,
                    IDDoiTuong = idDoiTuong,
                    ChiTiet = chiTiet ?? string.Empty,
                    DiaChiIP = LayDiaChiIP(),
                    ThietBi = LayThongTinThietBi()
                };

                if (SessionManager.IsLoggedIn)
                {
                    log.NguoiThucHien = SessionManager.GetCurrentUserName();
                    log.IDNguoiDung = SessionManager.GetCurrentUserId();
                }
                else
                {
                    log.NguoiThucHien = "HỆ THỐNG";
                    log.IDNguoiDung = null;
                }

                return lichSuDAL.Them(log);
            }
            catch (Exception ex)
            {
                // Không throw exception để tránh ảnh hưởng đến chức năng chính
                System.Diagnostics.Debug.WriteLine($"Lỗi ghi log: {ex.Message}");
                return 0;
            }
        }

        /// <summary>
        /// Ghi log cho hành động THÊM
        /// </summary>
        /// <param name="doiTuong">Đối tượng được thêm</param>
        /// <param name="idDoiTuong">ID của đối tượng vừa thêm</param>
        /// <param name="tenDoiTuong">Tên đối tượng</param>
        /// <param name="chiTietBoSung">Thông tin bổ sung</param>
        public void GhiLogThem(string doiTuong, int idDoiTuong, string tenDoiTuong, string chiTietBoSung = "")
        {
            string chiTiet = $"Đã thêm {doiTuong}: {tenDoiTuong}";
            if (!string.IsNullOrEmpty(chiTietBoSung))
                chiTiet += $" - {chiTietBoSung}";
            GhiLog(HanhDongHeThong.THEM, doiTuong, idDoiTuong, chiTiet);
        }

        /// <summary>
        /// Ghi log cho hành động SỬA
        /// </summary>
        /// <param name="doiTuong">Đối tượng được sửa</param>
        /// <param name="idDoiTuong">ID của đối tượng</param>
        /// <param name="tenDoiTuong">Tên đối tượng</param>
        /// <param name="thayDoi">Những thay đổi cụ thể</param>
        public void GhiLogSua(string doiTuong, int idDoiTuong, string tenDoiTuong, string thayDoi = "")
        {
            string chiTiet = $"Đã sửa {doiTuong}: {tenDoiTuong}";
            if (!string.IsNullOrEmpty(thayDoi))
                chiTiet += $" - {thayDoi}";
            GhiLog(HanhDongHeThong.SUA, doiTuong, idDoiTuong, chiTiet);
        }

        /// <summary>
        /// Ghi log cho hành động XÓA
        /// </summary>
        /// <param name="doiTuong">Đối tượng bị xóa</param>
        /// <param name="idDoiTuong">ID của đối tượng</param>
        /// <param name="tenDoiTuong">Tên đối tượng</param>
        public void GhiLogXoa(string doiTuong, int idDoiTuong, string tenDoiTuong)
        {
            GhiLog(HanhDongHeThong.XOA, doiTuong, idDoiTuong, $"Đã xóa {doiTuong}: {tenDoiTuong}");
        }

        /// <summary>
        /// Ghi log cho hành động KHÓA tài khoản
        /// </summary>
        /// <param name="doiTuong">Đối tượng bị khóa</param>
        /// <param name="idDoiTuong">ID của đối tượng</param>
        /// <param name="tenDoiTuong">Tên đối tượng</param>
        public void GhiLogKhoa(string doiTuong, int idDoiTuong, string tenDoiTuong)
        {
            GhiLog(HanhDongHeThong.KHOA, doiTuong, idDoiTuong, $"Đã khóa {doiTuong}: {tenDoiTuong}");
        }

        /// <summary>
        /// Ghi log cho hành động MỞ KHÓA tài khoản
        /// </summary>
        /// <param name="doiTuong">Đối tượng được mở khóa</param>
        /// <param name="idDoiTuong">ID của đối tượng</param>
        /// <param name="tenDoiTuong">Tên đối tượng</param>
        public void GhiLogMoKhoa(string doiTuong, int idDoiTuong, string tenDoiTuong)
        {
            GhiLog(HanhDongHeThong.MO_KHOA, doiTuong, idDoiTuong, $"Đã mở khóa {doiTuong}: {tenDoiTuong}");
        }

        #endregion

        #region Ghi log cho các chức năng đặc biệt

        /// <summary>
        /// Ghi log ĐĂNG NHẬP (xử lý đặc biệt vì chưa có session)
        /// </summary>
        /// <param name="tenNguoiDung">Tên người dùng</param>
        /// <param name="idNguoiDung">ID người dùng</param>
        public void GhiLogDangNhap(string tenNguoiDung, int idNguoiDung)
        {
            try
            {
                LichSuHoatDongDTO log = new LichSuHoatDongDTO
                {
                    NguoiThucHien = tenNguoiDung,
                    IDNguoiDung = idNguoiDung,
                    HanhDong = HanhDongHeThong.DANG_NHAP,
                    DoiTuong = DoiTuongHeThong.TAI_KHOAN,
                    IDDoiTuong = idNguoiDung,
                    ChiTiet = $"{tenNguoiDung} đã đăng nhập vào hệ thống",
                    DiaChiIP = LayDiaChiIP(),
                    ThietBi = LayThongTinThietBi()
                };
                lichSuDAL.Them(log);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Lỗi ghi log đăng nhập: {ex.Message}");
            }
        }

        /// <summary>
        /// Ghi log ĐĂNG XUẤT
        /// </summary>
        public void GhiLogDangXuat()
        {
            if (SessionManager.IsLoggedIn)
            {
                GhiLog(HanhDongHeThong.DANG_XUAT, DoiTuongHeThong.TAI_KHOAN,
                    SessionManager.GetCurrentUserId(),
                    $"{SessionManager.GetCurrentUserName()} đã đăng xuất khỏi hệ thống");
            }
        }

        /// <summary>
        /// Ghi log THANH TOÁN hóa đơn
        /// </summary>
        /// <param name="idHoaDon">ID hóa đơn</param>
        /// <param name="maHoaDon">Mã hóa đơn</param>
        /// <param name="tongTien">Tổng tiền thanh toán</param>
        /// <param name="tenBan">Tên bàn (nếu có)</param>
        public void GhiLogThanhToan(int idHoaDon, string maHoaDon, decimal tongTien, string tenBan = null)
        {
            string chiTiet = $"Thanh toán hóa đơn {maHoaDon} - Tổng tiền: {tongTien:N0}đ";
            if (!string.IsNullOrEmpty(tenBan))
                chiTiet += $" - Bàn: {tenBan}";
            GhiLog(HanhDongHeThong.THANH_TOAN, DoiTuongHeThong.HOA_DON, idHoaDon, chiTiet);
        }

        /// <summary>
        /// Ghi log DỌN BÀN
        /// </summary>
        /// <param name="idBan">ID bàn</param>
        /// <param name="tenBan">Tên bàn</param>
        public void GhiLogDonBan(int idBan, string tenBan)
        {
            GhiLog(HanhDongHeThong.DON_BAN, DoiTuongHeThong.BAN_AN, idBan, $"Đã dọn bàn {tenBan}");
        }

        /// <summary>
        /// Ghi log CHUYỂN TRẠNG THÁI BÀN
        /// </summary>
        /// <param name="idBan">ID bàn</param>
        /// <param name="tenBan">Tên bàn</param>
        /// <param name="trangThaiMoi">Trạng thái mới (1: Đang dùng, 2: Cần dọn)</param>
        public void GhiLogChuyenBan(int idBan, string tenBan, int trangThaiMoi)
        {
            string trangThaiStr = trangThaiMoi == 1 ? "ĐANG DÙNG" : "CẦN DỌN";
            GhiLog(HanhDongHeThong.CHUYEN_BAN, DoiTuongHeThong.BAN_AN, idBan,
                $"Chuyển bàn {tenBan} sang trạng thái {trangThaiStr}");
        }

        /// <summary>
        /// Ghi log NHẬP KHO
        /// </summary>
        /// <param name="idSanPham">ID sản phẩm</param>
        /// <param name="maSanPham">Mã sản phẩm</param>
        /// <param name="tenSanPham">Tên sản phẩm</param>
        /// <param name="soLuongNhap">Số lượng nhập</param>
        public void GhiLogNhapKho(int idSanPham, string maSanPham, string tenSanPham, int soLuongNhap)
        {
            GhiLog(HanhDongHeThong.NHAP_KHO, DoiTuongHeThong.SAN_PHAM, idSanPham,
                $"Nhập kho {soLuongNhap} sản phẩm {tenSanPham} (Mã: {maSanPham})");
        }

        /// <summary>
        /// Ghi log XEM BÁO CÁO
        /// </summary>
        /// <param name="loaiBaoCao">Loại báo cáo (Doanh thu, Top sản phẩm, v.v.)</param>
        /// <param name="tuNgay">Từ ngày</param>
        /// <param name="denNgay">Đến ngày</param>
        public void GhiLogXemBaoCao(string loaiBaoCao, DateTime? tuNgay = null, DateTime? denNgay = null)
        {
            string chiTiet = $"Xem báo cáo {loaiBaoCao}";
            if (tuNgay.HasValue && denNgay.HasValue)
                chiTiet += $" từ {tuNgay.Value:dd/MM/yyyy} đến {denNgay.Value:dd/MM/yyyy}";
            GhiLog(HanhDongHeThong.XEM_BAO_CAO, DoiTuongHeThong.BAO_CAO, null, chiTiet);
        }

        /// <summary>
        /// Ghi log XUẤT EXCEL
        /// </summary>
        /// <param name="loaiBaoCao">Loại báo cáo được xuất</param>
        public void GhiLogXuatExcel(string loaiBaoCao)
        {
            GhiLog(HanhDongHeThong.XUAT_EXCEL, DoiTuongHeThong.BAO_CAO, null, $"Xuất file Excel báo cáo {loaiBaoCao}");
        }

        /// <summary>
        /// Ghi log ĐỔI MẬT KHẨU
        /// </summary>
        public void GhiLogDoiMatKhau()
        {
            if (SessionManager.IsLoggedIn)
            {
                GhiLog(HanhDongHeThong.DOI_MAT_KHAU, DoiTuongHeThong.TAI_KHOAN,
                    SessionManager.GetCurrentUserId(),
                    $"{SessionManager.GetCurrentUserName()} đã đổi mật khẩu");
            }
        }

        /// <summary>
        /// Ghi log CẬP NHẬT THÔNG TIN CÁ NHÂN
        /// </summary>
        /// <param name="thayDoi">Những thay đổi</param>
        public void GhiLogCapNhatThongTin(string thayDoi = "")
        {
            if (SessionManager.IsLoggedIn)
            {
                string chiTiet = $"{SessionManager.GetCurrentUserName()} đã cập nhật thông tin cá nhân";
                if (!string.IsNullOrEmpty(thayDoi))
                    chiTiet += $": {thayDoi}";
                GhiLog(HanhDongHeThong.CAP_NHAT_THONG_TIN, DoiTuongHeThong.TAI_KHOAN,
                    SessionManager.GetCurrentUserId(), chiTiet);
            }
        }

        #endregion

        #region Lấy dữ liệu lịch sử

        /// <summary>
        /// Lấy danh sách lịch sử hoạt động với bộ lọc
        /// </summary>
        public List<LichSuHoatDongDTO> LayDanhSach(
            DateTime? tuNgay = null,
            DateTime? denNgay = null,
            string hanhDong = null,
            string nguoiThucHien = null,
            string doiTuong = null,
            int top = 1000)
        {
            return lichSuDAL.LayDanhSach(tuNgay, denNgay, hanhDong, nguoiThucHien, doiTuong, top);
        }

        /// <summary>
        /// Lấy lịch sử theo ID
        /// </summary>
        public LichSuHoatDongDTO LayTheoID(int idLichSu)
        {
            if (idLichSu <= 0)
                throw new ArgumentException("ID lịch sử không hợp lệ");
            return lichSuDAL.LayTheoID(idLichSu);
        }

        /// <summary>
        /// Lấy lịch sử theo người dùng
        /// </summary>
        public List<LichSuHoatDongDTO> LayTheoNguoiDung(int idNguoiDung, int top = 100)
        {
            if (idNguoiDung <= 0)
                throw new ArgumentException("ID người dùng không hợp lệ");
            return lichSuDAL.LayTheoNguoiDung(idNguoiDung, top);
        }

        /// <summary>
        /// Lấy lịch sử hôm nay
        /// </summary>
        public List<LichSuHoatDongDTO> LayHomNay()
        {
            return lichSuDAL.LayHomNay();
        }

        /// <summary>
        /// Lấy lịch sử theo hành động
        /// </summary>
        public List<LichSuHoatDongDTO> LayTheoHanhDong(string hanhDong, DateTime? tuNgay = null, DateTime? denNgay = null)
        {
            if (string.IsNullOrWhiteSpace(hanhDong))
                throw new ArgumentException("Hành động không được để trống");
            return lichSuDAL.LayTheoHanhDong(hanhDong, tuNgay, denNgay);
        }

        /// <summary>
        /// Lấy lịch sử theo đối tượng
        /// </summary>
        public List<LichSuHoatDongDTO> LayTheoDoiTuong(string doiTuong, int? idDoiTuong = null, DateTime? tuNgay = null, DateTime? denNgay = null)
        {
            if (string.IsNullOrWhiteSpace(doiTuong))
                throw new ArgumentException("Đối tượng không được để trống");
            return lichSuDAL.LayTheoDoiTuong(doiTuong, idDoiTuong, tuNgay, denNgay);
        }

        #endregion

        #region Thống kê

        /// <summary>
        /// Đếm tổng số bản ghi lịch sử
        /// </summary>
        public int DemTongSo(DateTime? tuNgay = null, DateTime? denNgay = null)
        {
            return lichSuDAL.DemTongSo(tuNgay, denNgay);
        }

        /// <summary>
        /// Đếm số bản ghi hôm nay
        /// </summary>
        public int DemHomNay()
        {
            return lichSuDAL.DemHomNay();
        }

        /// <summary>
        /// Thống kê số lượng theo hành động
        /// </summary>
        public Dictionary<string, int> ThongKeTheoHanhDong(DateTime? tuNgay = null, DateTime? denNgay = null)
        {
            var ds = LayDanhSach(tuNgay, denNgay, null, null, null, 10000);
            var result = new Dictionary<string, int>();

            foreach (var item in ds)
            {
                if (result.ContainsKey(item.HanhDong))
                    result[item.HanhDong]++;
                else
                    result[item.HanhDong] = 1;
            }

            return result;
        }

        /// <summary>
        /// Thống kê số lượng theo người thực hiện
        /// </summary>
        public Dictionary<string, int> ThongKeTheoNguoiThucHien(DateTime? tuNgay = null, DateTime? denNgay = null, int top = 10)
        {
            var ds = LayDanhSach(tuNgay, denNgay, null, null, null, 10000);
            var result = new Dictionary<string, int>();

            foreach (var item in ds)
            {
                if (result.ContainsKey(item.NguoiThucHien))
                    result[item.NguoiThucHien]++;
                else
                    result[item.NguoiThucHien] = 1;
            }

            // Sắp xếp và lấy top
            var sorted = new Dictionary<string, int>();
            int count = 0;
            foreach (var item in result.OrderByDescending(x => x.Value))
            {
                if (count >= top) break;
                sorted[item.Key] = item.Value;
                count++;
            }
            return sorted;
        }

        #endregion

        #region Xóa lịch sử

        /// <summary>
        /// Xóa lịch sử cũ (quá số ngày chỉ định)
        /// </summary>
        /// <param name="soNgayToiThieu">Giữ lại lịch sử trong vòng bao nhiêu ngày (mặc định 90)</param>
        /// <returns>Số bản ghi đã xóa</returns>
        public int XoaLichSuCu(int soNgayToiThieu = 90)
        {
            if (soNgayToiThieu < 30)
                throw new ArgumentException("Số ngày tối thiểu phải từ 30 ngày trở lên để đảm bảo an toàn dữ liệu");
            return lichSuDAL.XoaLichSuCu(soNgayToiThieu);
        }

        /// <summary>
        /// Xóa toàn bộ lịch sử (chỉ dùng khi có xác nhận)
        /// </summary>
        /// <returns>Số bản ghi đã xóa</returns>
        public int XoaToanBo()
        {
            return lichSuDAL.XoaToanBo();
        }

        #endregion

        #region Helper methods

        /// <summary>
        /// Lấy địa chỉ IP của máy tính (ưu tiên IPv4)
        /// </summary>
        private string LayDiaChiIP()
        {
            try
            {
                string hostName = Dns.GetHostName();
                IPHostEntry host = Dns.GetHostEntry(hostName);

                foreach (IPAddress ip in host.AddressList)
                {
                    if (ip.AddressFamily == AddressFamily.InterNetwork)
                        return ip.ToString();
                }
                return "127.0.0.1";
            }
            catch
            {
                return "Không xác định";
            }
        }

        /// <summary>
        /// Lấy thông tin thiết bị (Computer Name + OS + .NET Version)
        /// </summary>
        private string LayThongTinThietBi()
        {
            try
            {
                string os = Environment.OSVersion.ToString();
                string machine = Environment.MachineName;
                string dotnet = Environment.Version.ToString();
                return $"{machine} - {os} - .NET {dotnet}";
            }
            catch
            {
                return "Không xác định";
            }
        }

        #endregion
    }
}