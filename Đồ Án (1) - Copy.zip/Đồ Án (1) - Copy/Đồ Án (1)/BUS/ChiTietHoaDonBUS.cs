﻿// BUS/ChiTietHoaDonBUS.cs - Version đúng với thực tế
using System;
using System.Collections.Generic;
using Đồ_Án__1_.DAL;
using Đồ_Án__1_.DTO;  // Sửa typo: Đồ_Án__1

namespace Đồ_Án__1_.BUS
{
    public class ChiTietHoaDonBUS
    {
        private readonly ChiTietHoaDonDAL chiTietDAL = new ChiTietHoaDonDAL();

        public List<ChiTietHoaDonDTO> LayTheoHoaDon(int idHoaDon)
        {
            if (idHoaDon <= 0)
                throw new ArgumentException("ID hóa đơn không hợp lệ.");

            return chiTietDAL.LayTheoHoaDon(idHoaDon);
        }
    }
}