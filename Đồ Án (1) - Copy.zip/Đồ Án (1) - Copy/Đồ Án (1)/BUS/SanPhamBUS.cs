﻿// BUS/SanPhamBUS.cs
using System;
using System.Collections.Generic;
using Đồ_Án__1_.DAL;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.BUS
{
    public class SanPhamBUS
    {
        private readonly SanPhamDAL sanPhamDAL = new SanPhamDAL();

        public List<SanPhamDTO> LayDanhSachSanPham()
        {
            return sanPhamDAL.LayDanhSachSanPham(true);
        }

        public List<SanPhamDTO> LayTatCaSanPham()
        {
            return sanPhamDAL.LayDanhSachSanPham(false);
        }

        public SanPhamDTO LayTheoID(int idSanPham)
        {
            if (idSanPham <= 0)
                throw new ArgumentException("ID sản phẩm không hợp lệ.");

            return sanPhamDAL.LayTheoID(idSanPham);
        }

        public List<SanPhamDTO> TimKiem(string tuKhoa)
        {
            if (string.IsNullOrWhiteSpace(tuKhoa))
                return LayDanhSachSanPham();

            return sanPhamDAL.TimKiem(tuKhoa.Trim());
        }

        public List<SanPhamDTO> LayTheoLoai(int idLoai)
        {
            if (idLoai <= 0)
                throw new ArgumentException("ID loại sản phẩm không hợp lệ.");

            List<SanPhamDTO> danhSach = LayTatCaSanPham();
            List<SanPhamDTO> ketQua = new List<SanPhamDTO>();

            foreach (SanPhamDTO sp in danhSach)
            {
                if (sp.IDLoai == idLoai)
                {
                    ketQua.Add(sp);
                }
            }

            return ketQua;
        }

        public List<SanPhamDTO> LaySanPhamConTon()
        {
            List<SanPhamDTO> danhSach = LayTatCaSanPham();
            List<SanPhamDTO> ketQua = new List<SanPhamDTO>();

            foreach (SanPhamDTO sp in danhSach)
            {
                if (sp.KichHoat && sp.SoLuongTon > 0)
                {
                    ketQua.Add(sp);
                }
            }

            return ketQua;
        }

        public List<SanPhamDTO> LaySanPhamHetHang()
        {
            List<SanPhamDTO> danhSach = LayTatCaSanPham();
            List<SanPhamDTO> ketQua = new List<SanPhamDTO>();

            foreach (SanPhamDTO sp in danhSach)
            {
                if (sp.KichHoat && sp.SoLuongTon <= 0)
                {
                    ketQua.Add(sp);
                }
            }

            return ketQua;
        }

        public bool Them(SanPhamDTO sp)
        {
            KiemTraSanPham(sp, true);
            ChuanHoaSanPham(sp);

            if (sanPhamDAL.TonTaiMaSanPham(sp.MaSanPham))
                throw new InvalidOperationException("Mã sản phẩm đã tồn tại.");

            sp.KichHoat = true;

            return sanPhamDAL.Them(sp);
        }

        public bool Sua(SanPhamDTO sp)
        {
            KiemTraSanPham(sp, false);
            ChuanHoaSanPham(sp);

            if (!sanPhamDAL.TonTaiSanPham(sp.IDSanPham))
                throw new InvalidOperationException("Sản phẩm không tồn tại.");

            if (sanPhamDAL.TonTaiMaSanPham(sp.MaSanPham, sp.IDSanPham))
                throw new InvalidOperationException("Mã sản phẩm đã tồn tại.");

            return sanPhamDAL.Sua(sp);
        }

        public bool Xoa(int idSanPham)
        {
            if (idSanPham <= 0)
                throw new ArgumentException("ID sản phẩm không hợp lệ.");

            if (!sanPhamDAL.TonTaiSanPham(idSanPham))
                throw new InvalidOperationException("Sản phẩm không tồn tại.");

            return sanPhamDAL.Xoa(idSanPham);
        }

        public bool NhapKho(int idSanPham, int soLuongNhap)
        {
            if (idSanPham <= 0)
                throw new ArgumentException("ID sản phẩm không hợp lệ.");

            if (soLuongNhap <= 0)
                throw new ArgumentException("Số lượng nhập phải lớn hơn 0.");

            if (!sanPhamDAL.TonTaiSanPham(idSanPham))
                throw new InvalidOperationException("Sản phẩm không tồn tại.");

            return sanPhamDAL.NhapKho(idSanPham, soLuongNhap);
        }

        public List<CanhBaoTonKhoDTO> CanhBaoTonKho()
        {
            return sanPhamDAL.CanhBaoTonKho();
        }

        private void KiemTraSanPham(SanPhamDTO sp, bool laThemMoi)
        {
            if (sp == null)
                throw new ArgumentNullException("sp");

            if (!laThemMoi && sp.IDSanPham <= 0)
                throw new ArgumentException("ID sản phẩm không hợp lệ.");

            if (string.IsNullOrWhiteSpace(sp.MaSanPham))
                throw new ArgumentException("Mã sản phẩm không được để trống.");

            if (sp.MaSanPham.Trim().Length > 20)
                throw new ArgumentException("Mã sản phẩm không được vượt quá 20 ký tự.");

            if (string.IsNullOrWhiteSpace(sp.TenSanPham))
                throw new ArgumentException("Tên sản phẩm không được để trống.");

            if (sp.TenSanPham.Trim().Length > 100)
                throw new ArgumentException("Tên sản phẩm không được vượt quá 100 ký tự.");

            if (sp.GiaBan < 0)
                throw new ArgumentException("Giá bán không được âm.");

            if (sp.SoLuongTon < 0)
                throw new ArgumentException("Số lượng tồn không được âm.");

            if (sp.TonToiThieu < 0)
                throw new ArgumentException("Tồn tối thiểu không được âm.");
        }

        private void ChuanHoaSanPham(SanPhamDTO sp)
        {
            sp.MaSanPham = sp.MaSanPham.Trim();
            sp.TenSanPham = sp.TenSanPham.Trim();
            sp.DuongDanAnh = string.IsNullOrWhiteSpace(sp.DuongDanAnh) ? null : sp.DuongDanAnh.Trim();
        }
    }
}