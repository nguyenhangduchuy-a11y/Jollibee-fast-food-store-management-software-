﻿namespace Đồ_Án__1_
{
    partial class chitietsanpham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnDoiMK = new System.Windows.Forms.Button();
            this.btnDangXuat = new System.Windows.Forms.Button();
            this.btnLichSu = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnGuiYeuCau = new System.Windows.Forms.Button();
            this.btnXoaMon = new System.Windows.Forms.Button();
            this.txbTimKiemMonAn = new System.Windows.Forms.TextBox();
            this.cmbDanhMucMonAn = new System.Windows.Forms.ComboBox();
            this.btnTimKiem = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.listViewMonAn = new System.Windows.Forms.ListView();
            this.label2 = new System.Windows.Forms.Label();
            this.tbxTongTien = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.listViewGioHang = new System.Windows.Forms.ListView();
            this.txbDanhMuc = new System.Windows.Forms.TextBox();
            this.txbGia = new System.Windows.Forms.TextBox();
            this.txbTonKho = new System.Windows.Forms.TextBox();
            this.txbTen = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.numericUpDownTang = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownGiam = new System.Windows.Forms.NumericUpDown();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGiam)).BeginInit();
            this.SuspendLayout();
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.btnLichSu);
            this.panel5.Controls.Add(this.btnDangXuat);
            this.panel5.Controls.Add(this.btnDoiMK);
            this.panel5.Location = new System.Drawing.Point(12, 12);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1042, 50);
            this.panel5.TabIndex = 3;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // btnDoiMK
            // 
            this.btnDoiMK.BackColor = System.Drawing.Color.LightGray;
            this.btnDoiMK.Location = new System.Drawing.Point(803, 3);
            this.btnDoiMK.Name = "btnDoiMK";
            this.btnDoiMK.Size = new System.Drawing.Size(109, 44);
            this.btnDoiMK.TabIndex = 3;
            this.btnDoiMK.Text = "Đổi Mật Khẩu";
            this.btnDoiMK.UseVisualStyleBackColor = false;
            this.btnDoiMK.Click += new System.EventHandler(this.btnDoiMK_Click);
            // 
            // btnDangXuat
            // 
            this.btnDangXuat.BackColor = System.Drawing.Color.LightGray;
            this.btnDangXuat.Location = new System.Drawing.Point(929, 0);
            this.btnDangXuat.Name = "btnDangXuat";
            this.btnDangXuat.Size = new System.Drawing.Size(107, 44);
            this.btnDangXuat.TabIndex = 2;
            this.btnDangXuat.Text = "Đăng Xuất";
            this.btnDangXuat.UseVisualStyleBackColor = false;
            this.btnDangXuat.Click += new System.EventHandler(this.btnDangXuat_Click);
            // 
            // btnLichSu
            // 
            this.btnLichSu.BackColor = System.Drawing.Color.LightGray;
            this.btnLichSu.Location = new System.Drawing.Point(678, 3);
            this.btnLichSu.Name = "btnLichSu";
            this.btnLichSu.Size = new System.Drawing.Size(107, 44);
            this.btnLichSu.TabIndex = 1;
            this.btnLichSu.Text = "Lịch Sử";
            this.btnLichSu.UseVisualStyleBackColor = false;
            this.btnLichSu.Click += new System.EventHandler(this.btnLichSu_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(488, 23);
            this.label1.TabIndex = 4;
            this.label1.Text = "Chào Mừng Quý Khách Đến Với Jollibee Việt Nam🍔";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel8);
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Location = new System.Drawing.Point(524, 68);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(530, 388);
            this.panel1.TabIndex = 4;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.listViewMonAn);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(12, 68);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(506, 388);
            this.panel2.TabIndex = 5;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.numericUpDownGiam);
            this.panel4.Controls.Add(this.numericUpDownTang);
            this.panel4.Controls.Add(this.tbxTongTien);
            this.panel4.Controls.Add(this.label2);
            this.panel4.Controls.Add(this.btnThem);
            this.panel4.Controls.Add(this.btnGuiYeuCau);
            this.panel4.Controls.Add(this.btnXoaMon);
            this.panel4.Location = new System.Drawing.Point(4, 462);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1057, 50);
            this.panel4.TabIndex = 7;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // btnThem
            // 
            this.btnThem.BackColor = System.Drawing.Color.LightGray;
            this.btnThem.Location = new System.Drawing.Point(580, 3);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(107, 44);
            this.btnThem.TabIndex = 1;
            this.btnThem.Text = "Thêm Món";
            this.btnThem.UseVisualStyleBackColor = false;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnGuiYeuCau
            // 
            this.btnGuiYeuCau.BackColor = System.Drawing.Color.LightGray;
            this.btnGuiYeuCau.Location = new System.Drawing.Point(929, 0);
            this.btnGuiYeuCau.Name = "btnGuiYeuCau";
            this.btnGuiYeuCau.Size = new System.Drawing.Size(107, 44);
            this.btnGuiYeuCau.TabIndex = 2;
            this.btnGuiYeuCau.Text = "Gửi Yêu Cầu";
            this.btnGuiYeuCau.UseVisualStyleBackColor = false;
            this.btnGuiYeuCau.Click += new System.EventHandler(this.btnGuiYeuCau_Click);
            // 
            // btnXoaMon
            // 
            this.btnXoaMon.BackColor = System.Drawing.Color.LightGray;
            this.btnXoaMon.Location = new System.Drawing.Point(803, 3);
            this.btnXoaMon.Name = "btnXoaMon";
            this.btnXoaMon.Size = new System.Drawing.Size(109, 44);
            this.btnXoaMon.TabIndex = 3;
            this.btnXoaMon.Text = "Xóa Món";
            this.btnXoaMon.UseVisualStyleBackColor = false;
            this.btnXoaMon.Click += new System.EventHandler(this.btnXoaMon_Click);
            // 
            // txbTimKiemMonAn
            // 
            this.txbTimKiemMonAn.Location = new System.Drawing.Point(217, 10);
            this.txbTimKiemMonAn.Name = "txbTimKiemMonAn";
            this.txbTimKiemMonAn.Size = new System.Drawing.Size(271, 22);
            this.txbTimKiemMonAn.TabIndex = 5;
            // 
            // cmbDanhMucMonAn
            // 
            this.cmbDanhMucMonAn.FormattingEnabled = true;
            this.cmbDanhMucMonAn.Location = new System.Drawing.Point(108, 10);
            this.cmbDanhMucMonAn.Name = "cmbDanhMucMonAn";
            this.cmbDanhMucMonAn.Size = new System.Drawing.Size(96, 24);
            this.cmbDanhMucMonAn.TabIndex = 4;
            // 
            // btnTimKiem
            // 
            this.btnTimKiem.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnTimKiem.Location = new System.Drawing.Point(4, 6);
            this.btnTimKiem.Name = "btnTimKiem";
            this.btnTimKiem.Size = new System.Drawing.Size(98, 30);
            this.btnTimKiem.TabIndex = 2;
            this.btnTimKiem.Text = "Tìm Kiếm";
            this.btnTimKiem.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.txbTimKiemMonAn);
            this.panel3.Controls.Add(this.cmbDanhMucMonAn);
            this.panel3.Controls.Add(this.btnTimKiem);
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(497, 39);
            this.panel3.TabIndex = 8;
            // 
            // listViewMonAn
            // 
            this.listViewMonAn.HideSelection = false;
            this.listViewMonAn.Location = new System.Drawing.Point(6, 48);
            this.listViewMonAn.Name = "listViewMonAn";
            this.listViewMonAn.Size = new System.Drawing.Size(497, 173);
            this.listViewMonAn.TabIndex = 9;
            this.listViewMonAn.UseCompatibleStateImageBehavior = false;
            this.listViewMonAn.SelectedIndexChanged += new System.EventHandler(this.listViewMonAn_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(141, 36);
            this.label2.TabIndex = 5;
            this.label2.Text = "Tổng Tiền :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // tbxTongTien
            // 
            this.tbxTongTien.Location = new System.Drawing.Point(158, 17);
            this.tbxTongTien.Name = "tbxTongTien";
            this.tbxTongTien.Size = new System.Drawing.Size(121, 22);
            this.tbxTongTien.TabIndex = 6;
            this.tbxTongTien.TextChanged += new System.EventHandler(this.tbxTongTien_TextChanged);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.listViewGioHang);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Location = new System.Drawing.Point(3, 227);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(500, 158);
            this.panel6.TabIndex = 0;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 21);
            this.label3.TabIndex = 6;
            this.label3.Text = "Thực Đơn:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.pictureBox1);
            this.panel7.Location = new System.Drawing.Point(3, 188);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(520, 197);
            this.panel7.TabIndex = 0;
            this.panel7.Paint += new System.Windows.Forms.PaintEventHandler(this.panel7_Paint);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.button4);
            this.panel8.Controls.Add(this.button3);
            this.panel8.Controls.Add(this.button2);
            this.panel8.Controls.Add(this.button1);
            this.panel8.Controls.Add(this.txbTen);
            this.panel8.Controls.Add(this.txbTonKho);
            this.panel8.Controls.Add(this.txbGia);
            this.panel8.Controls.Add(this.txbDanhMuc);
            this.panel8.Location = new System.Drawing.Point(3, 3);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(520, 179);
            this.panel8.TabIndex = 1;
            this.panel8.Paint += new System.Windows.Forms.PaintEventHandler(this.panel8_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(520, 197);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // listViewGioHang
            // 
            this.listViewGioHang.HideSelection = false;
            this.listViewGioHang.Location = new System.Drawing.Point(7, 23);
            this.listViewGioHang.Name = "listViewGioHang";
            this.listViewGioHang.Size = new System.Drawing.Size(493, 132);
            this.listViewGioHang.TabIndex = 9;
            this.listViewGioHang.UseCompatibleStateImageBehavior = false;
            this.listViewGioHang.SelectedIndexChanged += new System.EventHandler(this.listViewGioHang_SelectedIndexChanged);
            // 
            // txbDanhMuc
            // 
            this.txbDanhMuc.Location = new System.Drawing.Point(163, 60);
            this.txbDanhMuc.Name = "txbDanhMuc";
            this.txbDanhMuc.Size = new System.Drawing.Size(290, 22);
            this.txbDanhMuc.TabIndex = 0;
            this.txbDanhMuc.TextChanged += new System.EventHandler(this.txbDanhMuc_TextChanged);
            // 
            // txbGia
            // 
            this.txbGia.Location = new System.Drawing.Point(163, 107);
            this.txbGia.Name = "txbGia";
            this.txbGia.Size = new System.Drawing.Size(290, 22);
            this.txbGia.TabIndex = 1;
            this.txbGia.TextChanged += new System.EventHandler(this.txbGia_TextChanged);
            // 
            // txbTonKho
            // 
            this.txbTonKho.Location = new System.Drawing.Point(163, 145);
            this.txbTonKho.Name = "txbTonKho";
            this.txbTonKho.Size = new System.Drawing.Size(290, 22);
            this.txbTonKho.TabIndex = 2;
            this.txbTonKho.TextChanged += new System.EventHandler(this.txbTonKho_TextChanged);
            // 
            // txbTen
            // 
            this.txbTen.Location = new System.Drawing.Point(163, 17);
            this.txbTen.Name = "txbTen";
            this.txbTen.Size = new System.Drawing.Size(290, 22);
            this.txbTen.TabIndex = 3;
            this.txbTen.TextChanged += new System.EventHandler(this.txbTen_TextChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.NavajoWhite;
            this.button1.Location = new System.Drawing.Point(43, 13);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(98, 30);
            this.button1.TabIndex = 4;
            this.button1.Text = "TÊN:";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.NavajoWhite;
            this.button2.Location = new System.Drawing.Point(43, 56);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(98, 30);
            this.button2.TabIndex = 5;
            this.button2.Text = "DANH MỤC";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.NavajoWhite;
            this.button3.Location = new System.Drawing.Point(43, 99);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(98, 30);
            this.button3.TabIndex = 6;
            this.button3.Text = "GIÁ:";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.NavajoWhite;
            this.button4.Location = new System.Drawing.Point(43, 137);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(98, 30);
            this.button4.TabIndex = 7;
            this.button4.Text = "CÒN LẠI:";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // numericUpDownTang
            // 
            this.numericUpDownTang.Location = new System.Drawing.Point(482, 12);
            this.numericUpDownTang.Name = "numericUpDownTang";
            this.numericUpDownTang.Size = new System.Drawing.Size(92, 22);
            this.numericUpDownTang.TabIndex = 7;
            this.numericUpDownTang.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownTang.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownTang.ValueChanged += new System.EventHandler(this.numericUpDownTang_ValueChanged);
            // 
            // numericUpDownGiam
            // 
            this.numericUpDownGiam.Location = new System.Drawing.Point(705, 12);
            this.numericUpDownGiam.Name = "numericUpDownGiam";
            this.numericUpDownGiam.Size = new System.Drawing.Size(92, 22);
            this.numericUpDownGiam.TabIndex = 8;
            this.numericUpDownGiam.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownGiam.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownGiam.ValueChanged += new System.EventHandler(this.numericUpDownGiam_ValueChanged);
            // 
            // chitietsanpham
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1059, 513);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel5);
            this.Name = "chitietsanpham";
            this.Text = "chitietsanpham";
            this.panel5.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGiam)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnDoiMK;
        private System.Windows.Forms.Button btnDangXuat;
        private System.Windows.Forms.Button btnLichSu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnGuiYeuCau;
        private System.Windows.Forms.Button btnXoaMon;
        private System.Windows.Forms.TextBox txbTimKiemMonAn;
        private System.Windows.Forms.ComboBox cmbDanhMucMonAn;
        private System.Windows.Forms.Button btnTimKiem;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ListView listViewMonAn;
        private System.Windows.Forms.TextBox tbxTongTien;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ListView listViewGioHang;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txbTen;
        private System.Windows.Forms.TextBox txbTonKho;
        private System.Windows.Forms.TextBox txbGia;
        private System.Windows.Forms.TextBox txbDanhMuc;
        private System.Windows.Forms.NumericUpDown numericUpDownGiam;
        private System.Windows.Forms.NumericUpDown numericUpDownTang;
    }
}