﻿namespace Đồ_Án__1_
{
    partial class nhanvienxacnhan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel5 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.listViewKhachHang = new System.Windows.Forms.ListView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txbTongTien = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnTuChoi = new System.Windows.Forms.Button();
            this.btnxacnhan = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.listViewChiTietDonHang = new System.Windows.Forms.ListView();
            this.txbSoDonCho = new System.Windows.Forms.TextBox();
            this.panel5.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.txbSoDonCho);
            this.panel5.Controls.Add(this.label2);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Location = new System.Drawing.Point(12, 12);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(740, 42);
            this.panel5.TabIndex = 4;
            this.panel5.Paint += new System.Windows.Forms.PaintEventHandler(this.panel5_Paint);
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(468, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(184, 23);
            this.label2.TabIndex = 5;
            this.label2.Text = "SỐ ĐƠN CHỜ:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(293, 23);
            this.label1.TabIndex = 4;
            this.label1.Text = "ĐƠN HÀNG CHỜ THANH TOÁN";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.listViewKhachHang);
            this.panel1.Location = new System.Drawing.Point(12, 60);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(740, 201);
            this.panel1.TabIndex = 6;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // listViewKhachHang
            // 
            this.listViewKhachHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listViewKhachHang.HideSelection = false;
            this.listViewKhachHang.Location = new System.Drawing.Point(0, 0);
            this.listViewKhachHang.Name = "listViewKhachHang";
            this.listViewKhachHang.Size = new System.Drawing.Size(740, 201);
            this.listViewKhachHang.TabIndex = 0;
            this.listViewKhachHang.UseCompatibleStateImageBehavior = false;
            this.listViewKhachHang.SelectedIndexChanged += new System.EventHandler(this.listViewKhachHang_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.btnThoat);
            this.panel2.Controls.Add(this.btnTuChoi);
            this.panel2.Controls.Add(this.btnxacnhan);
            this.panel2.Location = new System.Drawing.Point(12, 532);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(740, 58);
            this.panel2.TabIndex = 8;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txbTongTien);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Location = new System.Drawing.Point(9, 13);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(276, 42);
            this.panel4.TabIndex = 5;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // txbTongTien
            // 
            this.txbTongTien.Location = new System.Drawing.Point(123, 10);
            this.txbTongTien.Name = "txbTongTien";
            this.txbTongTien.Size = new System.Drawing.Size(136, 22);
            this.txbTongTien.TabIndex = 6;
            this.txbTongTien.TextChanged += new System.EventHandler(this.txbTongTien_TextChanged);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 23);
            this.label3.TabIndex = 5;
            this.label3.Text = "TỔNG TIỀN:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnThoat.Location = new System.Drawing.Point(591, 15);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(128, 30);
            this.btnThoat.TabIndex = 5;
            this.btnThoat.Text = "THOÁT";
            this.btnThoat.UseVisualStyleBackColor = false;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // btnTuChoi
            // 
            this.btnTuChoi.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnTuChoi.Location = new System.Drawing.Point(440, 15);
            this.btnTuChoi.Name = "btnTuChoi";
            this.btnTuChoi.Size = new System.Drawing.Size(128, 30);
            this.btnTuChoi.TabIndex = 4;
            this.btnTuChoi.Text = "TỪ CHỐI";
            this.btnTuChoi.UseVisualStyleBackColor = false;
            this.btnTuChoi.Click += new System.EventHandler(this.btnTuChoi_Click);
            // 
            // btnxacnhan
            // 
            this.btnxacnhan.BackColor = System.Drawing.Color.NavajoWhite;
            this.btnxacnhan.Location = new System.Drawing.Point(285, 15);
            this.btnxacnhan.Name = "btnxacnhan";
            this.btnxacnhan.Size = new System.Drawing.Size(133, 30);
            this.btnxacnhan.TabIndex = 3;
            this.btnxacnhan.Text = "XÁC NHẬN";
            this.btnxacnhan.UseVisualStyleBackColor = false;
            this.btnxacnhan.Click += new System.EventHandler(this.btnxacnhan_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.listViewChiTietDonHang);
            this.panel3.Location = new System.Drawing.Point(14, 267);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(740, 259);
            this.panel3.TabIndex = 9;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // listViewChiTietDonHang
            // 
            this.listViewChiTietDonHang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listViewChiTietDonHang.HideSelection = false;
            this.listViewChiTietDonHang.Location = new System.Drawing.Point(0, 0);
            this.listViewChiTietDonHang.Name = "listViewChiTietDonHang";
            this.listViewChiTietDonHang.Size = new System.Drawing.Size(740, 259);
            this.listViewChiTietDonHang.TabIndex = 0;
            this.listViewChiTietDonHang.UseCompatibleStateImageBehavior = false;
            this.listViewChiTietDonHang.SelectedIndexChanged += new System.EventHandler(this.listViewChiTietDonHang_SelectedIndexChanged);
            // 
            // txbSoDonCho
            // 
            this.txbSoDonCho.Location = new System.Drawing.Point(639, 11);
            this.txbSoDonCho.Name = "txbSoDonCho";
            this.txbSoDonCho.Size = new System.Drawing.Size(80, 22);
            this.txbSoDonCho.TabIndex = 7;
            this.txbSoDonCho.TextChanged += new System.EventHandler(this.txbSoDonCho_TextChanged);
            // 
            // nhanvienxacnhan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(769, 614);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel5);
            this.Name = "nhanvienxacnhan";
            this.Text = "nhanvienxacnhan";
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListView listViewKhachHang;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ListView listViewChiTietDonHang;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnTuChoi;
        private System.Windows.Forms.Button btnxacnhan;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox txbTongTien;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txbSoDonCho;
    }
}