﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Windows.Forms;
using Đồ_Án__1_.BUS;
using Đồ_Án__1_.DTO;
using Đồ_Án__1_.Utils;
using Đồ_Án__1_.DAL;
using System.Data.SqlClient;

namespace Đồ_Án__1_
{
    public partial class chitietsanpham : Form
    {
        #region Khai báo BUS
        private readonly SanPhamBUS sanPhamBUS = new SanPhamBUS();
        private readonly LoaiSanPhamBUS loaiSanPhamBUS = new LoaiSanPhamBUS();
        private readonly HoaDonBUS hoaDonBUS = new HoaDonBUS();
        #endregion

        #region Biến giỏ hàng
        private class GioHangItem
        {
            public SanPhamDTO SanPham { get; set; }
            public int SoLuong { get; set; }
            public string GhiChu { get; set; }
            public decimal ThanhTien => SanPham.GiaBan * SoLuong;
        }
        private List<GioHangItem> gioHang = new List<GioHangItem>();
        private List<SanPhamDTO> danhSachSanPhamGoc = new List<SanPhamDTO>();
        private List<LoaiSanPhamDTO> danhSachLoaiGoc = new List<LoaiSanPhamDTO>();
        private bool daLoadDanhMuc = false;
        private bool daGanSuKien = false;
        #endregion

        public chitietsanpham()
        {
            InitializeComponent();
            this.Load += Chitietsanpham_Load;
        }

        private void Chitietsanpham_Load(object sender, EventArgs e)
        {
            // Kiểm tra đăng nhập
            if (!SessionManager.IsLoggedIn)
            {
                MessageBox.Show("Vui lòng đăng nhập để mua hàng!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
                return;
            }

            // Cấu hình ListView
            CauHinhListView();

            // Đặt TextBox ở chế độ chỉ đọc
            SetTextBoxReadOnly();

            // Cấu hình NumericUpDown
            SetupNumericUpDown();

            // Load dữ liệu
            LoadDanhMuc();
            LoadSanPham();

            // Gắn sự kiện (chỉ gán một lần)
            GanSuKien();

            // Cập nhật giỏ hàng
            CapNhatGioHang();
        }

        #region Cấu hình giao diện

        private void SetTextBoxReadOnly()
        {
            txbTen.ReadOnly = true;
            txbDanhMuc.ReadOnly = true;
            txbGia.ReadOnly = true;
            txbTonKho.ReadOnly = true;

            Color readOnlyColor = Color.FromArgb(245, 245, 245);
            txbTen.BackColor = readOnlyColor;
            txbDanhMuc.BackColor = readOnlyColor;
            txbGia.BackColor = readOnlyColor;
            txbTonKho.BackColor = readOnlyColor;
        }

        private void SetupNumericUpDown()
        {
            numericUpDownTang.Minimum = 1;
            numericUpDownTang.Maximum = 100;
            numericUpDownTang.Value = 1;

            numericUpDownGiam.Minimum = 1;
            numericUpDownGiam.Maximum = 100;
            numericUpDownGiam.Value = 1;
        }

        private void CauHinhListView()
        {
            // ListView sản phẩm
            listViewMonAn.View = View.Details;
            listViewMonAn.FullRowSelect = true;
            listViewMonAn.GridLines = true;
            listViewMonAn.Columns.Clear();
            listViewMonAn.Columns.Add("Mã SP", 80);
            listViewMonAn.Columns.Add("Tên sản phẩm", 200);
            listViewMonAn.Columns.Add("Giá", 100, HorizontalAlignment.Right);
            listViewMonAn.Columns.Add("Tồn kho", 80, HorizontalAlignment.Center);

            // ListView giỏ hàng
            listViewGioHang.View = View.Details;
            listViewGioHang.FullRowSelect = true;
            listViewGioHang.GridLines = true;
            listViewGioHang.Columns.Clear();
            listViewGioHang.Columns.Add("Tên sản phẩm", 180);
            listViewGioHang.Columns.Add("Số lượng", 70, HorizontalAlignment.Center);
            listViewGioHang.Columns.Add("Đơn giá", 100, HorizontalAlignment.Right);
            listViewGioHang.Columns.Add("Thành tiền", 120, HorizontalAlignment.Right);
        }

        #endregion

        #region Load dữ liệu

        private void LoadDanhMuc()
        {
            // Chỉ load một lần duy nhất
            if (daLoadDanhMuc) return;

            try
            {
                cmbDanhMucMonAn.Items.Clear();
                cmbDanhMucMonAn.Items.Add("-- Tất cả --");

                danhSachLoaiGoc = loaiSanPhamBUS.LayDanhSachDangHoatDong();

                foreach (var dm in danhSachLoaiGoc)
                {
                    // Kiểm tra tránh trùng lặp
                    if (!cmbDanhMucMonAn.Items.Contains(dm.TenLoai))
                    {
                        cmbDanhMucMonAn.Items.Add(dm.TenLoai);
                    }
                }

                cmbDanhMucMonAn.SelectedIndex = 0;
                daLoadDanhMuc = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tải danh mục: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadSanPham()
        {
            try
            {
                danhSachSanPhamGoc = sanPhamBUS.LayDanhSachSanPham();
                HienThiSanPham(danhSachSanPhamGoc);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tải sản phẩm: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void HienThiSanPham(List<SanPhamDTO> danhSach)
        {
            listViewMonAn.Items.Clear();

            foreach (var sp in danhSach)
            {
                ListViewItem lvi = new ListViewItem(sp.MaSanPham);
                lvi.SubItems.Add(sp.TenSanPham);
                lvi.SubItems.Add(string.Format("{0:N0} đ", sp.GiaBan));
                lvi.SubItems.Add(sp.SoLuongTon.ToString());
                lvi.Tag = sp;

                // Màu sắc theo tồn kho
                if (sp.SoLuongTon <= 0)
                    lvi.ForeColor = Color.Red;
                else if (sp.SoLuongTon <= sp.TonToiThieu)
                    lvi.ForeColor = Color.Orange;
                else
                    lvi.ForeColor = Color.Black;

                listViewMonAn.Items.Add(lvi);
            }

            if (listViewMonAn.Items.Count > 0)
            {
                listViewMonAn.Items[0].Selected = true;
            }
        }

        private void LoadAnhSanPham(string duongDanAnh)
        {
            try
            {
                if (string.IsNullOrEmpty(duongDanAnh))
                {
                    pictureBox1.Image = null;
                    return;
                }

                if (duongDanAnh.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                    duongDanAnh.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
                {
                    using (WebClient client = new WebClient())
                    {
                        byte[] imageData = client.DownloadData(duongDanAnh);
                        using (var ms = new System.IO.MemoryStream(imageData))
                        {
                            pictureBox1.Image = Image.FromStream(ms);
                        }
                    }
                }
                else if (System.IO.File.Exists(duongDanAnh))
                {
                    pictureBox1.Image = Image.FromFile(duongDanAnh);
                }
                else
                {
                    pictureBox1.Image = null;
                }

                pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            }
            catch
            {
                pictureBox1.Image = null;
            }
        }

        private void GanSuKien()
        {
            if (daGanSuKien) return;

            // Gắn sự kiện cho ComboBox
            cmbDanhMucMonAn.SelectedIndexChanged -= cmbDanhMucMonAn_SelectedIndexChanged;
            cmbDanhMucMonAn.SelectedIndexChanged += cmbDanhMucMonAn_SelectedIndexChanged;

            // Gắn sự kiện cho TextBox tìm kiếm
            txbTimKiemMonAn.TextChanged -= txbTimKiemMonAn_TextChanged;
            txbTimKiemMonAn.TextChanged += txbTimKiemMonAn_TextChanged;

            // Gắn sự kiện cho nút tìm kiếm
            btnTimKiem.Click -= btnTimKiem_Click;
            btnTimKiem.Click += btnTimKiem_Click;

            daGanSuKien = true;
        }

        #endregion

        #region Tìm kiếm và lọc (ĐÃ SỬA)

        private void TimKiemVaLoc()
        {
            try
            {
                string tuKhoa = txbTimKiemMonAn.Text.Trim().ToLower();
                string tenDanhMuc = cmbDanhMucMonAn.SelectedIndex > 0 ? cmbDanhMucMonAn.SelectedItem.ToString() : null;

                // Load lại danh sách từ database mỗi khi tìm kiếm
                List<SanPhamDTO> danhSach = sanPhamBUS.LayDanhSachSanPham();

                // Lọc theo từ khóa
                if (!string.IsNullOrEmpty(tuKhoa))
                {
                    danhSach = danhSach.Where(sp =>
                        sp.TenSanPham.ToLower().Contains(tuKhoa) ||
                        sp.MaSanPham.ToLower().Contains(tuKhoa)).ToList();
                }

                // Lọc theo danh mục
                if (!string.IsNullOrEmpty(tenDanhMuc))
                {
                    danhSach = danhSach.Where(sp => sp.TenLoai == tenDanhMuc).ToList();
                }

                // Hiển thị kết quả
                listViewMonAn.Items.Clear();

                foreach (var sp in danhSach)
                {
                    ListViewItem lvi = new ListViewItem(sp.MaSanPham);
                    lvi.SubItems.Add(sp.TenSanPham);
                    lvi.SubItems.Add(string.Format("{0:N0} đ", sp.GiaBan));
                    lvi.SubItems.Add(sp.SoLuongTon.ToString());
                    lvi.Tag = sp;

                    if (sp.SoLuongTon <= 0)
                        lvi.ForeColor = Color.Red;
                    else if (sp.SoLuongTon <= sp.TonToiThieu)
                        lvi.ForeColor = Color.Orange;
                    else
                        lvi.ForeColor = Color.Black;

                    listViewMonAn.Items.Add(lvi);
                }

                // Cập nhật lại danh sách gốc
                danhSachSanPhamGoc = danhSach;

                if (listViewMonAn.Items.Count == 0 && (!string.IsNullOrEmpty(tuKhoa) || !string.IsNullOrEmpty(tenDanhMuc)))
                {
                    MessageBox.Show($"Không tìm thấy sản phẩm nào!\n\nTừ khóa: {tuKhoa}\nDanh mục: {tenDanhMuc}",
                        "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (listViewMonAn.Items.Count > 0)
                {
                    listViewMonAn.Items[0].Selected = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tìm kiếm: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            TimKiemVaLoc();
        }

        private void cmbDanhMucMonAn_SelectedIndexChanged(object sender, EventArgs e)
        {
            TimKiemVaLoc();
        }

        private void txbTimKiemMonAn_TextChanged(object sender, EventArgs e)
        {
            TimKiemVaLoc();
        }

        #endregion

        #region Giỏ hàng

        private void listViewMonAn_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listViewMonAn.SelectedItems.Count > 0)
            {
                var sp = listViewMonAn.SelectedItems[0].Tag as SanPhamDTO;
                if (sp != null)
                {
                    txbTen.Text = sp.TenSanPham;
                    txbDanhMuc.Text = sp.TenLoai;
                    txbGia.Text = sp.GiaBanFormat;
                    txbTonKho.Text = sp.SoLuongTon.ToString();
                    LoadAnhSanPham(sp.DuongDanAnh);
                }
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (listViewMonAn.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn sản phẩm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var sp = listViewMonAn.SelectedItems[0].Tag as SanPhamDTO;
            int soLuong = (int)numericUpDownTang.Value;

            if (soLuong <= 0)
            {
                MessageBox.Show("Số lượng phải lớn hơn 0!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (sp.SoLuongTon < soLuong)
            {
                MessageBox.Show($"Sản phẩm '{sp.TenSanPham}' chỉ còn {sp.SoLuongTon} sản phẩm!",
                    "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var existing = gioHang.FirstOrDefault(item => item.SanPham.IDSanPham == sp.IDSanPham);
            if (existing != null)
            {
                if (sp.SoLuongTon < existing.SoLuong + soLuong)
                {
                    MessageBox.Show($"Không thể thêm {soLuong} sản phẩm. Sản phẩm '{sp.TenSanPham}' chỉ còn {sp.SoLuongTon} sản phẩm!",
                        "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                existing.SoLuong += soLuong;
            }
            else
            {
                gioHang.Add(new GioHangItem
                {
                    SanPham = sp,
                    SoLuong = soLuong,
                    GhiChu = ""
                });
            }

            CapNhatGioHang();
            numericUpDownTang.Value = 1;

            MessageBox.Show($"Đã thêm {soLuong} {sp.TenSanPham} vào giỏ hàng!", "Thông báo",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnXoaMon_Click(object sender, EventArgs e)
        {
            if (listViewGioHang.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn món cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int index = listViewGioHang.SelectedIndices[0];
            var item = gioHang[index];
            int soLuongXoa = (int)numericUpDownGiam.Value;

            if (soLuongXoa <= 0)
            {
                MessageBox.Show("Số lượng xóa phải lớn hơn 0!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (item.SoLuong <= soLuongXoa)
            {
                DialogResult dr = MessageBox.Show($"Xóa '{item.SanPham.TenSanPham}' khỏi giỏ hàng?",
                    "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (dr == DialogResult.Yes)
                {
                    gioHang.RemoveAt(index);
                }
            }
            else
            {
                item.SoLuong -= soLuongXoa;
            }

            CapNhatGioHang();
            numericUpDownGiam.Value = 1;
        }

        private void CapNhatGioHang()
        {
            listViewGioHang.Items.Clear();
            decimal tongTien = 0;

            foreach (var item in gioHang)
            {
                ListViewItem lvi = new ListViewItem(item.SanPham.TenSanPham);
                lvi.SubItems.Add(item.SoLuong.ToString());
                lvi.SubItems.Add(string.Format("{0:N0} đ", item.SanPham.GiaBan));
                lvi.SubItems.Add(string.Format("{0:N0} đ", item.ThanhTien));
                lvi.Tag = item;

                listViewGioHang.Items.Add(lvi);
                tongTien += item.ThanhTien;
            }

            tbxTongTien.Text = string.Format("{0:N0} đ", tongTien);
        }

        private void listViewGioHang_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listViewGioHang.SelectedItems.Count > 0)
            {
                int index = listViewGioHang.SelectedIndices[0];
                var item = gioHang[index];
                numericUpDownTang.Value = item.SoLuong;
                numericUpDownGiam.Value = 1;
            }
        }

        private void numericUpDownTang_ValueChanged(object sender, EventArgs e)
        {
            if (listViewGioHang.SelectedItems.Count > 0)
            {
                int index = listViewGioHang.SelectedIndices[0];
                var item = gioHang[index];
                int soLuongMoi = (int)numericUpDownTang.Value;

                if (soLuongMoi <= 0)
                {
                    numericUpDownTang.Value = 1;
                    return;
                }

                if (item.SanPham.SoLuongTon < soLuongMoi)
                {
                    MessageBox.Show($"Sản phẩm '{item.SanPham.TenSanPham}' chỉ còn {item.SanPham.SoLuongTon} sản phẩm!",
                        "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    numericUpDownTang.Value = item.SoLuong;
                    return;
                }

                item.SoLuong = soLuongMoi;
                CapNhatGioHang();
            }
        }

        private void numericUpDownGiam_ValueChanged(object sender, EventArgs e) { }

        #endregion

        #region Gửi yêu cầu đặt hàng

        private void btnGuiYeuCau_Click(object sender, EventArgs e)
        {
            if (gioHang.Count == 0)
            {
                MessageBox.Show("Giỏ hàng trống! Vui lòng thêm sản phẩm.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Kiểm tra tồn kho lần cuối
                foreach (var item in gioHang)
                {
                    var sp = sanPhamBUS.LayTheoID(item.SanPham.IDSanPham);
                    if (sp == null || sp.SoLuongTon < item.SoLuong)
                    {
                        MessageBox.Show($"Sản phẩm '{item.SanPham.TenSanPham}' hiện chỉ còn {(sp != null ? sp.SoLuongTon : 0)} sản phẩm!\nVui lòng cập nhật giỏ hàng.",
                            "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                // Tạo danh sách chi tiết đơn hàng
                List<ChiTietHoaDonDTO> chiTietList = new List<ChiTietHoaDonDTO>();
                foreach (var item in gioHang)
                {
                    chiTietList.Add(new ChiTietHoaDonDTO
                    {
                        IDSanPham = item.SanPham.IDSanPham,
                        SoLuong = item.SoLuong,
                        GhiChu = item.GhiChu
                    });
                }

                // Tạo hóa đơn
                HoaDonDTO hoaDon = new HoaDonDTO
                {
                    LoaiDon = 3, // Tự order
                    IDKhachHang = SessionManager.GetCurrentUserId(),
                    PhuongThucThanhToan = "Tiền mặt",
                    GhiChu = ""
                };

                string maHoaDon;
                int idHoaDon = hoaDonBUS.TaoDonHangCho(hoaDon, chiTietList, out maHoaDon);

                if (idHoaDon > 0)
                {
                    LogHelper.LogNhanh($"Khách hàng {SessionManager.GetCurrentUserName()} đã đặt đơn #{maHoaDon}");

                    MessageBox.Show($"Đặt hàng thành công!\n\nMã đơn hàng: {maHoaDon}\n" +
                        $"Tổng tiền: {tbxTongTien.Text}\n\n" +
                        $"Đơn hàng của bạn đang được xử lý. Nhân viên sẽ xác nhận trong giây lát!",
                        "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Xóa giỏ hàng
                    gioHang.Clear();
                    CapNhatGioHang();
                }
                else
                {
                    MessageBox.Show("Đặt hàng thất bại! Vui lòng thử lại.", "Lỗi",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Lịch sử đơn hàng

        private void btnLichSu_Click(object sender, EventArgs e)
        {
            try
            {
                int idKhach = SessionManager.GetCurrentUserId();

                DataTable dt = new DataTable();
                string sql = "EXEC sp_LichSuDonHangKhachHang @IDKhachHang, @TuNgay, @DenNgay";

                using (SqlConnection conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        cmd.Parameters.AddWithValue("@IDKhachHang", idKhach);
                        cmd.Parameters.AddWithValue("@TuNgay", DBNull.Value);
                        cmd.Parameters.AddWithValue("@DenNgay", DBNull.Value);
                        da.Fill(dt);
                    }
                    conn.Close();
                }

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Bạn chưa có đơn hàng nào!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                Form frmLichSu = new Form();
                frmLichSu.Text = "Lịch sử đơn hàng";
                frmLichSu.Size = new Size(900, 500);
                frmLichSu.StartPosition = FormStartPosition.CenterParent;

                DataGridView dgv = new DataGridView();
                dgv.Dock = DockStyle.Fill;
                dgv.DataSource = dt;
                dgv.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                dgv.ReadOnly = true;
                dgv.AllowUserToAddRows = false;

                dgv.CellDoubleClick += (s, ev) =>
                {
                    if (ev.RowIndex >= 0)
                    {
                        int idHoaDon = Convert.ToInt32(dgv.Rows[ev.RowIndex].Cells["IDHoaDon"].Value);
                        string maHoaDon = dgv.Rows[ev.RowIndex].Cells["MaHoaDon"].Value.ToString();
                        chitiethoadon frmChiTiet = new chitiethoadon(idHoaDon, maHoaDon);
                        frmChiTiet.ShowDialog();
                    }
                };

                frmLichSu.Controls.Add(dgv);
                frmLichSu.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi tải lịch sử: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Đổi mật khẩu

        private void btnDoiMK_Click(object sender, EventArgs e)
        {
            doimatkhau frmDoiMK = new doimatkhau();
            frmDoiMK.ShowDialog();
        }

        #endregion

        #region Đăng xuất (PHÂN BIỆT VAI TRÒ)

        private void btnDangXuat_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muốn đăng xuất?",
                "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {
                // Lưu lại thông tin vai trò TRƯỚC KHI đăng xuất
                bool laNhanVienHoacAdmin = SessionManager.IsNhanVien || SessionManager.IsAdmin;

                // Ghi log đăng xuất
                LogHelper.LogDangXuat();

                if (laNhanVienHoacAdmin)
                {
                    // NHÂN VIÊN HOẶC ADMIN: Chỉ đóng form, KHÔNG đăng xuất khỏi session
                    this.Close();

                    // Tìm form bán hàng đang mở hoặc mở mới
                    nhanvienbanhang frmBanHang = null;
                    foreach (Form form in Application.OpenForms)
                    {
                        if (form is nhanvienbanhang && !form.IsDisposed)
                        {
                            frmBanHang = form as nhanvienbanhang;
                            break;
                        }
                    }

                    if (frmBanHang != null && !frmBanHang.IsDisposed)
                    {
                        frmBanHang.Show();
                        frmBanHang.BringToFront();
                    }
                    else
                    {
                        nhanvienbanhang frmMoi = new nhanvienbanhang();
                        frmMoi.Show();
                    }
                }
                else
                {
                    // KHÁCH HÀNG: Đăng xuất hoàn toàn và về form đăng nhập
                    SessionManager.DangXuat();
                    this.Close();

                    dangnhap frmDangNhap = new dangnhap();
                    frmDangNhap.Show();
                }
            }
        }

        #endregion

        #region Các sự kiện khác (giữ nguyên)

        private void tbxTongTien_TextChanged(object sender, EventArgs e) { }
        private void panel5_Paint(object sender, PaintEventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void pictureBox1_Click(object sender, EventArgs e) { }
        private void button1_Click(object sender, EventArgs e) { }
        private void button2_Click(object sender, EventArgs e) { }
        private void button3_Click(object sender, EventArgs e) { }
        private void button4_Click(object sender, EventArgs e) { }
        private void txbTen_TextChanged(object sender, EventArgs e) { }
        private void txbDanhMuc_TextChanged(object sender, EventArgs e) { }
        private void txbGia_TextChanged(object sender, EventArgs e) { }
        private void txbTonKho_TextChanged(object sender, EventArgs e) { }
        private void panel17_Paint(object sender, PaintEventArgs e) { }
        private void panel4_Paint(object sender, PaintEventArgs e) { }
        private void listView1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void panel7_Paint(object sender, PaintEventArgs e) { }
        private void panel1_Paint(object sender, PaintEventArgs e) { }
        private void panel8_Paint(object sender, PaintEventArgs e) { }
        private void panel2_Paint(object sender, PaintEventArgs e) { }
        private void panel6_Paint(object sender, PaintEventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }

        #endregion
    }
}