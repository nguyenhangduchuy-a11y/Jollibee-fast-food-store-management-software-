﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Đồ_Án__1_.BUS;
using Đồ_Án__1_.DTO;
using Đồ_Án__1_.Utils;
using Excel = Microsoft.Office.Interop.Excel;

namespace Đồ_Án__1_
{
    public partial class nhanvienxacnhan : Form
    {
        #region Khai báo BUS và biến
        private readonly HoaDonBUS hoaDonBUS = new HoaDonBUS();
        private readonly ChiTietHoaDonBUS chiTietHoaDonBUS = new ChiTietHoaDonBUS();
        private readonly SanPhamBUS sanPhamBUS = new SanPhamBUS();
        private readonly NguoiDungBUS nguoiDungBUS = new NguoiDungBUS();

        private Timer refreshTimer;
        private int lastSoDonCho = -1;
        private NotifyIcon notifyIcon;
        private Form formChiTietHoaDon = null;
        #endregion

        public nhanvienxacnhan()
        {
            InitializeComponent();
            this.Load += Nhanvienxacnhan_Load;
            this.FormClosing += Nhanvienxacnhan_FormClosing;
        }

        #region Khởi tạo và cấu hình

        private void Nhanvienxacnhan_Load(object sender, EventArgs e)
        {
            // Kiểm tra quyền
            if (!SessionManager.IsNhanVien && !SessionManager.IsAdmin)
            {
                MessageBox.Show("Bạn không có quyền truy cập chức năng này!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
                return;
            }

            // Cấu hình ListView
            CauHinhListViewKhachHang();
            CauHinhListViewChiTiet();

            // Thiết lập TextBox chỉ đọc
            txbTongTien.ReadOnly = true;
            txbTongTien.BackColor = Color.FromArgb(245, 245, 245);
            txbSoDonCho.ReadOnly = true;
            txbSoDonCho.BackColor = Color.FromArgb(245, 245, 245);

            // Khởi tạo NotifyIcon cho thông báo
            KhoiTaoNotifyIcon();

            // Khởi tạo Timer refresh
            KhoiTaoTimer();

            // Load dữ liệu lần đầu
            LoadDanhSachDonCho();
        }

        private void CauHinhListViewKhachHang()
        {
            listViewKhachHang.View = View.Details;
            listViewKhachHang.FullRowSelect = true;
            listViewKhachHang.GridLines = true;
            listViewKhachHang.Columns.Clear();
            listViewKhachHang.Columns.Add("ID", 50, HorizontalAlignment.Center);
            listViewKhachHang.Columns.Add("Mã đơn", 120, HorizontalAlignment.Center);
            listViewKhachHang.Columns.Add("Khách hàng", 180, HorizontalAlignment.Left);
            listViewKhachHang.Columns.Add("Thời gian", 150, HorizontalAlignment.Center);
            listViewKhachHang.Columns.Add("Tổng tiền", 120, HorizontalAlignment.Right);
            listViewKhachHang.Columns.Add("Số món", 80, HorizontalAlignment.Center);
            listViewKhachHang.MultiSelect = false;
        }

        private void CauHinhListViewChiTiet()
        {
            listViewChiTietDonHang.View = View.Details;
            listViewChiTietDonHang.FullRowSelect = true;
            listViewChiTietDonHang.GridLines = true;
            listViewChiTietDonHang.Columns.Clear();
            listViewChiTietDonHang.Columns.Add("Mã SP", 80, HorizontalAlignment.Center);
            listViewChiTietDonHang.Columns.Add("Tên sản phẩm", 250, HorizontalAlignment.Left);
            listViewChiTietDonHang.Columns.Add("Số lượng", 70, HorizontalAlignment.Center);
            listViewChiTietDonHang.Columns.Add("Đơn giá", 100, HorizontalAlignment.Right);
            listViewChiTietDonHang.Columns.Add("Thành tiền", 120, HorizontalAlignment.Right);
            listViewChiTietDonHang.MultiSelect = false;
        }

        private void KhoiTaoNotifyIcon()
        {
            notifyIcon = new NotifyIcon();
            notifyIcon.Icon = SystemIcons.Information;
            notifyIcon.Visible = true;
            notifyIcon.BalloonTipTitle = "Jollibee - Đơn hàng mới";
            notifyIcon.BalloonTipIcon = ToolTipIcon.Info;
            notifyIcon.BalloonTipClicked += (s, e) =>
            {
                this.BringToFront();
                this.WindowState = FormWindowState.Normal;
            };
        }

        private void KhoiTaoTimer()
        {
            refreshTimer = new Timer();
            refreshTimer.Interval = 5000; // 5 giây
            refreshTimer.Tick += RefreshTimer_Tick;
            refreshTimer.Start();
        }

        private void RefreshTimer_Tick(object sender, EventArgs e)
        {
            LoadDanhSachDonCho();
        }

        #endregion

        #region Load dữ liệu

        private void LoadDanhSachDonCho()
        {
            try
            {
                var danhSach = hoaDonBUS.LayDonChoXacNhan();
                int soDonHienTai = danhSach.Count;

                // Cập nhật số đơn chờ
                txbSoDonCho.Text = soDonHienTai.ToString();
                txbSoDonCho.ForeColor = soDonHienTai > 0 ? Color.Red : Color.Green;

                // Kiểm tra có đơn mới không
                if (lastSoDonCho != -1 && soDonHienTai > lastSoDonCho)
                {
                    int soDonMoi = soDonHienTai - lastSoDonCho;
                    ShowNotification($"Có {soDonMoi} đơn hàng mới cần xác nhận!");
                }

                lastSoDonCho = soDonHienTai;

                // Làm mới hiển thị
                listViewKhachHang.Items.Clear();

                if (soDonHienTai == 0)
                {
                    ListViewItem emptyItem = new ListViewItem("");
                    emptyItem.SubItems.Add("Không có đơn hàng chờ xác nhận");
                    emptyItem.SubItems.Add("");
                    emptyItem.SubItems.Add("");
                    emptyItem.SubItems.Add("");
                    emptyItem.SubItems.Add("");
                    listViewKhachHang.Items.Add(emptyItem);

                    listViewChiTietDonHang.Items.Clear();
                    txbTongTien.Text = "0 đ";
                    return;
                }

                foreach (var hd in danhSach)
                {
                    ListViewItem lvi = new ListViewItem(hd.IDHoaDon.ToString());
                    lvi.SubItems.Add(hd.MaHoaDon);
                    lvi.SubItems.Add(hd.TenKhachHang);
                    lvi.SubItems.Add(hd.NgayLap.ToString("dd/MM/yyyy HH:mm"));
                    lvi.SubItems.Add(string.Format("{0:N0} đ", hd.TongTien));
                    lvi.SubItems.Add(hd.SoLuongMon.ToString());
                    lvi.Tag = hd;
                    listViewKhachHang.Items.Add(lvi);
                }

                if (listViewKhachHang.Items.Count > 0 && listViewKhachHang.SelectedItems.Count == 0)
                {
                    listViewKhachHang.Items[0].Selected = true;
                }
            }
            catch (Exception ex)
            {
                LogHelper.LogLoi("LoadDanhSachDonCho", ex.Message);
                txbSoDonCho.Text = "0";
            }
        }

        private void LoadChiTietDonHang(int idHoaDon)
        {
            try
            {
                var chiTietList = chiTietHoaDonBUS.LayTheoHoaDon(idHoaDon);
                listViewChiTietDonHang.Items.Clear();

                if (chiTietList == null || chiTietList.Count == 0)
                {
                    ListViewItem emptyItem = new ListViewItem("");
                    emptyItem.SubItems.Add("Không có chi tiết đơn hàng");
                    listViewChiTietDonHang.Items.Add(emptyItem);
                    txbTongTien.Text = "0 đ";
                    return;
                }

                decimal tongTien = 0;
                foreach (var ct in chiTietList)
                {
                    ListViewItem lvi = new ListViewItem(ct.MaSanPham);
                    lvi.SubItems.Add(ct.TenSanPham);
                    lvi.SubItems.Add(ct.SoLuong.ToString());
                    lvi.SubItems.Add(string.Format("{0:N0} đ", ct.DonGia));
                    lvi.SubItems.Add(string.Format("{0:N0} đ", ct.ThanhTien));
                    lvi.Tag = ct;
                    listViewChiTietDonHang.Items.Add(lvi);
                    tongTien += ct.ThanhTien;
                }

                txbTongTien.Text = string.Format("{0:N0} đ", tongTien);
                listViewChiTietDonHang.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize);
            }
            catch (Exception ex)
            {
                LogHelper.LogLoi("LoadChiTietDonHang", ex.Message);
                listViewChiTietDonHang.Items.Clear();
                ListViewItem errItem = new ListViewItem("");
                errItem.SubItems.Add($"Lỗi: {ex.Message}");
                listViewChiTietDonHang.Items.Add(errItem);
            }
        }

        #endregion

        #region Sự kiện ListView

        private void listViewKhachHang_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listViewKhachHang.SelectedItems.Count > 0 && listViewKhachHang.SelectedItems[0].Tag != null)
            {
                var hd = listViewKhachHang.SelectedItems[0].Tag as HoaDonDTO;
                if (hd != null)
                {
                    LoadChiTietDonHang(hd.IDHoaDon);
                }
            }
        }

        private void listViewChiTietDonHang_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        #endregion

        #region Xuất Excel hóa đơn

        /// <summary>
        /// Xuất hóa đơn ra file Excel
        /// </summary>
        private void XuatHoaDonRaExcel(int idHoaDon, string maHoaDon)
        {
            try
            {
                // Lấy chi tiết hóa đơn
                var chiTietList = chiTietHoaDonBUS.LayTheoHoaDon(idHoaDon);
                if (chiTietList == null || chiTietList.Count == 0)
                {
                    MessageBox.Show("Không có dữ liệu để xuất hóa đơn!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Lấy thông tin hóa đơn
                var hoaDon = hoaDonBUS.LayTheoID(idHoaDon);
                if (hoaDon == null) return;

                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "Excel Files|*.xlsx";
                saveFileDialog.Title = "Lưu hóa đơn";
                saveFileDialog.FileName = $"HoaDon_{maHoaDon}_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    Excel.Application excelApp = null;
                    Excel.Workbook workbook = null;
                    Excel.Worksheet worksheet = null;

                    try
                    {
                        excelApp = new Excel.Application();
                        excelApp.DisplayAlerts = false;
                        workbook = excelApp.Workbooks.Add();
                        worksheet = (Excel.Worksheet)workbook.Worksheets[1];
                        worksheet.Name = $"HoaDon_{maHoaDon}";

                        // Header - JOLLIBEE VIETNAM
                        worksheet.Cells[1, 1] = "JOLLIBEE VIETNAM";
                        Excel.Range titleRange = worksheet.Range[worksheet.Cells[1, 1], worksheet.Cells[1, 6]];
                        titleRange.Merge();
                        titleRange.Font.Bold = true;
                        titleRange.Font.Size = 20;
                        titleRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                        // Header - HÓA ĐƠN BÁN HÀNG
                        worksheet.Cells[2, 1] = "HÓA ĐƠN BÁN HÀNG";
                        titleRange = worksheet.Range[worksheet.Cells[2, 1], worksheet.Cells[2, 6]];
                        titleRange.Merge();
                        titleRange.Font.Bold = true;
                        titleRange.Font.Size = 16;
                        titleRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                        // Thông tin hóa đơn
                        worksheet.Cells[3, 1] = $"Mã HD: {maHoaDon}";
                        worksheet.Cells[4, 1] = $"Ngày lập: {hoaDon.NgayLap:dd/MM/yyyy HH:mm}";
                        worksheet.Cells[5, 1] = $"Khách hàng: {hoaDon.TenKhachHang}";
                        worksheet.Cells[6, 1] = $"Nhân viên: {SessionManager.GetCurrentUserName()}";
                        worksheet.Cells[7, 1] = $"Loại đơn: Tự order (Online)";

                        // Header bảng chi tiết
                        int row = 9;
                        worksheet.Cells[row, 1] = "STT";
                        worksheet.Cells[row, 2] = "Mã SP";
                        worksheet.Cells[row, 3] = "Tên sản phẩm";
                        worksheet.Cells[row, 4] = "Số lượng";
                        worksheet.Cells[row, 5] = "Đơn giá (VNĐ)";
                        worksheet.Cells[row, 6] = "Thành tiền (VNĐ)";

                        Excel.Range headerRange = worksheet.Range[worksheet.Cells[row, 1], worksheet.Cells[row, 6]];
                        headerRange.Font.Bold = true;
                        headerRange.Interior.Color = System.Drawing.Color.LightGray.ToArgb();
                        headerRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                        headerRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                        // Xuất danh sách sản phẩm
                        int stt = 1;
                        row++;
                        decimal tongTien = 0;

                        foreach (var item in chiTietList)
                        {
                            worksheet.Cells[row, 1] = stt++;
                            worksheet.Cells[row, 2] = item.MaSanPham;
                            worksheet.Cells[row, 3] = item.TenSanPham;
                            worksheet.Cells[row, 4] = item.SoLuong;
                            worksheet.Cells[row, 5] = item.DonGia;
                            worksheet.Cells[row, 6] = item.ThanhTien;
                            tongTien += item.ThanhTien;
                            row++;
                        }

                        // Tổng cộng
                        row++;
                        worksheet.Cells[row, 4] = "TỔNG CỘNG:";
                        worksheet.Cells[row, 6] = tongTien;

                        Excel.Range totalRange = worksheet.Range[worksheet.Cells[row, 4], worksheet.Cells[row, 6]];
                        totalRange.Font.Bold = true;
                        totalRange.Interior.Color = System.Drawing.Color.LightYellow.ToArgb();
                        totalRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignRight;

                        // Định dạng số tiền
                        Excel.Range priceRange = worksheet.Range[worksheet.Cells[10, 5], worksheet.Cells[row, 6]];
                        priceRange.NumberFormat = "#,##0";

                        // Lời cảm ơn
                        row += 2;
                        worksheet.Cells[row, 1] = "Cảm ơn quý khách! Hẹn gặp lại!";
                        Excel.Range thanksRange = worksheet.Range[worksheet.Cells[row, 1], worksheet.Cells[row, 6]];
                        thanksRange.Merge();
                        thanksRange.Font.Italic = true;
                        thanksRange.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                        // Kẻ khung
                        Excel.Range dataRange = worksheet.Range[worksheet.Cells[9, 1], worksheet.Cells[row - 3, 6]];
                        dataRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;

                        worksheet.Columns.AutoFit();

                        // Lưu file
                        workbook.SaveAs(saveFileDialog.FileName);

                        LogHelper.LogNhanh($"Đã xuất hóa đơn {maHoaDon} ra Excel");

                        MessageBox.Show($"Xuất hóa đơn thành công!\nĐường dẫn: {saveFileDialog.FileName}",
                            "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Hỏi mở file
                        if (MessageBox.Show("Bạn có muốn mở file vừa xuất không?", "Thông báo",
                            MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            System.Diagnostics.Process.Start(saveFileDialog.FileName);
                        }
                    }
                    finally
                    {
                        if (workbook != null)
                        {
                            try { workbook.Close(false); System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook); } catch { }
                        }
                        if (excelApp != null)
                        {
                            try { excelApp.Quit(); System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp); } catch { }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.LogLoi("XuatHoaDonRaExcel", ex.Message);
                MessageBox.Show($"Lỗi xuất Excel: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Mở form chi tiết hóa đơn và xuất Excel
        /// </summary>
        private void MoFormChiTietHoaDon(int idHoaDon, string maHoaDon)
        {
            // Đóng form cũ nếu có
            if (formChiTietHoaDon != null && !formChiTietHoaDon.IsDisposed)
            {
                formChiTietHoaDon.Close();
            }

            // Mở form chi tiết hóa đơn
            formChiTietHoaDon = new chitiethoadon(idHoaDon, maHoaDon);
            formChiTietHoaDon.FormClosed += (s, args) => formChiTietHoaDon = null;
            formChiTietHoaDon.ShowDialog();
        }

        #endregion

        #region Xử lý xác nhận và từ chối

        private void btnxacnhan_Click(object sender, EventArgs e)
        {
            if (listViewKhachHang.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn đơn hàng cần xác nhận!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var hd = listViewKhachHang.SelectedItems[0].Tag as HoaDonDTO;
            if (hd == null) return;

            DialogResult dr = MessageBox.Show(
                $"Xác nhận đơn hàng #{hd.MaHoaDon}\n" +
                $"Khách hàng: {hd.TenKhachHang}\n" +
                $"Tổng tiền: {hd.TongTien:N0} đ\n\n" +
                $"Sau khi xác nhận, đơn hàng sẽ được chuyển sang thanh toán và xuất hóa đơn!\n\n" +
                $"Bạn có chắc chắn muốn xác nhận?",
                "Xác nhận đơn hàng",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {
                try
                {
                    bool ketQua = hoaDonBUS.XacNhanDonHang(hd.IDHoaDon);

                    if (ketQua)
                    {
                        // Ghi log
                        LogHelper.LogNhanh($"Nhân viên {SessionManager.GetCurrentUserName()} đã xác nhận đơn hàng #{hd.MaHoaDon}");

                        // 1. Mở form chi tiết hóa đơn
                        MoFormChiTietHoaDon(hd.IDHoaDon, hd.MaHoaDon);

                        // 2. Xuất Excel hóa đơn
                        XuatHoaDonRaExcel(hd.IDHoaDon, hd.MaHoaDon);

                        // 3. Refresh danh sách
                        LoadDanhSachDonCho();

                        // 4. Thông báo
                        ShowNotification($"Đã xác nhận và xuất hóa đơn #{hd.MaHoaDon}");
                    }
                    else
                    {
                        MessageBox.Show("Xác nhận đơn hàng thất bại!\nVui lòng thử lại.", "Lỗi",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnTuChoi_Click(object sender, EventArgs e)
        {
            if (listViewKhachHang.SelectedItems.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn đơn hàng cần từ chối!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var hd = listViewKhachHang.SelectedItems[0].Tag as HoaDonDTO;
            if (hd == null) return;

            Form frmLyDo = new Form();
            frmLyDo.Text = "Nhập lý do từ chối";
            frmLyDo.Size = new Size(450, 200);
            frmLyDo.StartPosition = FormStartPosition.CenterParent;
            frmLyDo.FormBorderStyle = FormBorderStyle.FixedDialog;
            frmLyDo.MaximizeBox = false;
            frmLyDo.MinimizeBox = false;

            Label lblLyDo = new Label()
            {
                Text = $"Lý do từ chối đơn hàng #{hd.MaHoaDon}:",
                Location = new Point(12, 20),
                Size = new Size(400, 25),
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };

            TextBox txtLyDo = new TextBox()
            {
                Location = new Point(12, 55),
                Size = new Size(410, 60),
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                Font = new Font("Segoe UI", 10)
            };

            Button btnXacNhan = new Button()
            {
                Text = "Xác nhận",
                Location = new Point(180, 125),
                Size = new Size(100, 35),
                BackColor = Color.FromArgb(231, 76, 60),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };

            Button btnHuy = new Button()
            {
                Text = "Hủy",
                Location = new Point(300, 125),
                Size = new Size(100, 35),
                BackColor = Color.FromArgb(52, 73, 94),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };

            btnXacNhan.Click += (s, ev) =>
            {
                string lyDo = txtLyDo.Text.Trim();
                if (string.IsNullOrWhiteSpace(lyDo))
                {
                    MessageBox.Show("Vui lòng nhập lý do từ chối!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                try
                {
                    bool ketQua = hoaDonBUS.TuChoiDonHang(hd.IDHoaDon, lyDo);

                    if (ketQua)
                    {
                        LogHelper.LogNhanh($"Nhân viên {SessionManager.GetCurrentUserName()} đã từ chối đơn hàng #{hd.MaHoaDon} - Lý do: {lyDo}");

                        MessageBox.Show($"Đã từ chối đơn hàng #{hd.MaHoaDon}!\nLý do: {lyDo}",
                            "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        LoadDanhSachDonCho();
                        ShowNotification($"Đã từ chối đơn hàng #{hd.MaHoaDon}");
                        frmLyDo.Close();
                    }
                    else
                    {
                        MessageBox.Show("Từ chối đơn hàng thất bại!\nVui lòng thử lại.", "Lỗi",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            };

            btnHuy.Click += (s, ev) => frmLyDo.Close();

            frmLyDo.Controls.AddRange(new Control[] { lblLyDo, txtLyDo, btnXacNhan, btnHuy });
            frmLyDo.ShowDialog();
        }

        #endregion

        #region Thông báo

        private void ShowNotification(string message)
        {
            notifyIcon.BalloonTipText = message;
            notifyIcon.ShowBalloonTip(3000);

            if (int.TryParse(txbSoDonCho.Text, out int soDon) && soDon > 0)
            {
                txbSoDonCho.BackColor = Color.LightPink;
                Timer flashTimer = new Timer();
                flashTimer.Interval = 500;
                int flashCount = 0;
                flashTimer.Tick += (s, e) =>
                {
                    flashCount++;
                    if (flashCount >= 6)
                    {
                        flashTimer.Stop();
                        txbSoDonCho.BackColor = Color.FromArgb(245, 245, 245);
                    }
                    else
                    {
                        txbSoDonCho.BackColor = flashCount % 2 == 0 ? Color.LightPink : Color.FromArgb(245, 245, 245);
                    }
                };
                flashTimer.Start();
            }
        }

        #endregion

        #region Thoát và đóng form

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muốn thoát?",
                "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dr == DialogResult.Yes)
            {
                CloseForm();
            }
        }

        private void CloseForm()
        {
            if (refreshTimer != null)
            {
                refreshTimer.Stop();
                refreshTimer.Dispose();
            }

            if (notifyIcon != null)
            {
                notifyIcon.Visible = false;
                notifyIcon.Dispose();
            }

            if (formChiTietHoaDon != null && !formChiTietHoaDon.IsDisposed)
            {
                formChiTietHoaDon.Close();
            }

            nhanvienbanhang frmBanHang = null;
            foreach (Form form in Application.OpenForms)
            {
                if (form is nhanvienbanhang && !form.IsDisposed)
                {
                    frmBanHang = form as nhanvienbanhang;
                    break;
                }
            }

            this.Close();

            if (frmBanHang != null && !frmBanHang.IsDisposed)
            {
                frmBanHang.Show();
                frmBanHang.BringToFront();
            }
            else
            {
                nhanvienbanhang frmMoi = new nhanvienbanhang();
                frmMoi.Show();
            }
        }

        private void Nhanvienxacnhan_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (refreshTimer != null)
            {
                refreshTimer.Stop();
                refreshTimer.Dispose();
            }
            if (notifyIcon != null)
            {
                notifyIcon.Visible = false;
                notifyIcon.Dispose();
            }
        }

        #endregion

        #region Các sự kiện khác

        private void panel5_Paint(object sender, PaintEventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void panel1_Paint(object sender, PaintEventArgs e) { }
        private void panel3_Paint(object sender, PaintEventArgs e) { }
        private void panel4_Paint(object sender, PaintEventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void txbTongTien_TextChanged(object sender, EventArgs e) { }
        private void panel2_Paint(object sender, PaintEventArgs e) { }
        private void txbSoDonCho_TextChanged(object sender, EventArgs e) { }

        #endregion
    }
}