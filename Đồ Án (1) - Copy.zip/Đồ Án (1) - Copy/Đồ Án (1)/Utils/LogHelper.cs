﻿// Utils/LogHelper.cs
using System;
using Đồ_Án__1_.BUS;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.Utils
{
    /// <summary>
    /// Helper class để ghi log nhanh chóng từ bất kỳ đâu trong ứng dụng
    /// Sử dụng: LogHelper.Log("Nội dung log");
    /// </summary>
    public static class LogHelper
    {
        private static readonly LichSuHoatDongBUS logBUS = new LichSuHoatDongBUS();
        private static bool _isEnabled = true;

        /// <summary>
        /// Bật/tắt ghi log (mặc định là bật)
        /// </summary>
        public static bool IsEnabled
        {
            get { return _isEnabled; }
            set { _isEnabled = value; }
        }

        #region Ghi log cơ bản

        /// <summary>
        /// Ghi log tổng quát
        /// </summary>
        public static void Log(string hanhDong, string doiTuong, int? idDoiTuong = null, string chiTiet = null)
        {
            if (!_isEnabled) return;
            logBUS.GhiLog(hanhDong, doiTuong, idDoiTuong, chiTiet);
        }

        /// <summary>
        /// Ghi log nhanh với nội dung đơn giản (tự động xác định loại log)
        /// </summary>
        public static void LogNhanh(string noiDung)
        {
            if (!_isEnabled) return;
            logBUS.GhiLog("GHI CHÚ", "HỆ THỐNG", null, noiDung);
        }

        #endregion

        #region Log cho Quản lý Sản phẩm

        /// <summary>
        /// Ghi log thêm sản phẩm
        /// </summary>
        public static void LogThemSanPham(int idSanPham, string tenSanPham, string maSanPham = "")
        {
            if (!_isEnabled) return;
            string chiTiet = $"Thêm sản phẩm: {tenSanPham}";
            if (!string.IsNullOrEmpty(maSanPham))
                chiTiet += $" (Mã: {maSanPham})";
            logBUS.GhiLog(HanhDongHeThong.THEM, DoiTuongHeThong.SAN_PHAM, idSanPham, chiTiet);
        }

        /// <summary>
        /// Ghi log sửa sản phẩm
        /// </summary>
        public static void LogSuaSanPham(int idSanPham, string tenSanPham, string thayDoi = "")
        {
            if (!_isEnabled) return;
            string chiTiet = $"Sửa sản phẩm: {tenSanPham}";
            if (!string.IsNullOrEmpty(thayDoi))
                chiTiet += $" - {thayDoi}";
            logBUS.GhiLog(HanhDongHeThong.SUA, DoiTuongHeThong.SAN_PHAM, idSanPham, chiTiet);
        }

        /// <summary>
        /// Ghi log xóa sản phẩm
        /// </summary>
        public static void LogXoaSanPham(int idSanPham, string tenSanPham)
        {
            if (!_isEnabled) return;
            logBUS.GhiLog(HanhDongHeThong.XOA, DoiTuongHeThong.SAN_PHAM, idSanPham, $"Xóa sản phẩm: {tenSanPham}");
        }

        /// <summary>
        /// Ghi log nhập kho sản phẩm
        /// </summary>
        public static void LogNhapKhoSanPham(int idSanPham, string tenSanPham, string maSanPham, int soLuong)
        {
            if (!_isEnabled) return;
            logBUS.GhiLogNhapKho(idSanPham, maSanPham, tenSanPham, soLuong);
        }

        #endregion

        #region Log cho Quản lý Nhân viên

        /// <summary>
        /// Ghi log thêm nhân viên
        /// </summary>
        public static void LogThemNhanVien(int idNhanVien, string hoTen, string tenDangNhap = "")
        {
            if (!_isEnabled) return;
            string chiTiet = $"Thêm nhân viên: {hoTen}";
            if (!string.IsNullOrEmpty(tenDangNhap))
                chiTiet += $" (TK: {tenDangNhap})";
            logBUS.GhiLog(HanhDongHeThong.THEM, DoiTuongHeThong.NHAN_VIEN, idNhanVien, chiTiet);
        }

        /// <summary>
        /// Ghi log sửa nhân viên
        /// </summary>
        public static void LogSuaNhanVien(int idNhanVien, string hoTen, string thayDoi = "")
        {
            if (!_isEnabled) return;
            string chiTiet = $"Sửa nhân viên: {hoTen}";
            if (!string.IsNullOrEmpty(thayDoi))
                chiTiet += $" - {thayDoi}";
            logBUS.GhiLog(HanhDongHeThong.SUA, DoiTuongHeThong.NHAN_VIEN, idNhanVien, chiTiet);
        }

        /// <summary>
        /// Ghi log khóa nhân viên
        /// </summary>
        public static void LogKhoaNhanVien(int idNhanVien, string hoTen)
        {
            if (!_isEnabled) return;
            logBUS.GhiLogKhoa(DoiTuongHeThong.NHAN_VIEN, idNhanVien, hoTen);
        }

        /// <summary>
        /// Ghi log mở khóa nhân viên
        /// </summary>
        public static void LogMoKhoaNhanVien(int idNhanVien, string hoTen)
        {
            if (!_isEnabled) return;
            logBUS.GhiLogMoKhoa(DoiTuongHeThong.NHAN_VIEN, idNhanVien, hoTen);
        }

        #endregion

        #region Log cho Bán hàng

        /// <summary>
        /// Ghi log thanh toán hóa đơn
        /// </summary>
        public static void LogThanhToan(int idHoaDon, string maHoaDon, decimal tongTien, string tenBan = null)
        {
            if (!_isEnabled) return;
            logBUS.GhiLogThanhToan(idHoaDon, maHoaDon, tongTien, tenBan);
        }

        /// <summary>
        /// Ghi log dọn bàn
        /// </summary>
        public static void LogDonBan(int idBan, string tenBan)
        {
            if (!_isEnabled) return;
            logBUS.GhiLogDonBan(idBan, tenBan);
        }

        /// <summary>
        /// Ghi log chuyển trạng thái bàn
        /// </summary>
        public static void LogChuyenBan(int idBan, string tenBan, int trangThaiMoi)
        {
            if (!_isEnabled) return;
            logBUS.GhiLogChuyenBan(idBan, tenBan, trangThaiMoi);
        }

        #endregion

        #region Log cho Tài khoản & Bảo mật

        /// <summary>
        /// Ghi log đăng nhập
        /// </summary>
        public static void LogDangNhap(string tenNguoiDung, int idNguoiDung)
        {
            if (!_isEnabled) return;
            logBUS.GhiLogDangNhap(tenNguoiDung, idNguoiDung);
        }

        /// <summary>
        /// Ghi log đăng xuất
        /// </summary>
        public static void LogDangXuat()
        {
            if (!_isEnabled) return;
            logBUS.GhiLogDangXuat();
        }

        /// <summary>
        /// Ghi log đổi mật khẩu
        /// </summary>
        public static void LogDoiMatKhau()
        {
            if (!_isEnabled) return;
            logBUS.GhiLogDoiMatKhau();
        }

        /// <summary>
        /// Ghi log cập nhật thông tin cá nhân
        /// </summary>
        public static void LogCapNhatThongTin(string thayDoi = "")
        {
            if (!_isEnabled) return;
            logBUS.GhiLogCapNhatThongTin(thayDoi);
        }

        #endregion

        #region Log cho Báo cáo & Thống kê

        /// <summary>
        /// Ghi log xem báo cáo
        /// </summary>
        public static void LogXemBaoCao(string loaiBaoCao, DateTime? tuNgay = null, DateTime? denNgay = null)
        {
            if (!_isEnabled) return;
            logBUS.GhiLogXemBaoCao(loaiBaoCao, tuNgay, denNgay);
        }

        /// <summary>
        /// Ghi log xuất Excel
        /// </summary>
        public static void LogXuatExcel(string loaiBaoCao)
        {
            if (!_isEnabled) return;
            logBUS.GhiLogXuatExcel(loaiBaoCao);
        }

        #endregion

        #region Log cho Hệ thống

        /// <summary>
        /// Ghi log lỗi hệ thống
        /// </summary>
        public static void LogLoi(string chucNang, string noiDungLoi)
        {
            if (!_isEnabled) return;
            logBUS.GhiLog("LỖI HỆ THỐNG", "HỆ THỐNG", null, $"{chucNang}: {noiDungLoi}");
        }

        /// <summary>
        /// Ghi log cảnh báo hệ thống
        /// </summary>
        public static void LogCanhBao(string chucNang, string noiDung)
        {
            if (!_isEnabled) return;
            logBUS.GhiLog("CẢNH BÁO", "HỆ THỐNG", null, $"{chucNang}: {noiDung}");
        }

        /// <summary>
        /// Ghi log khởi động hệ thống
        /// </summary>
        public static void LogKhoiDongHeThong()
        {
            if (!_isEnabled) return;
            logBUS.GhiLog("KHỞI ĐỘNG", "HỆ THỐNG", null, "Hệ thống Quản lý Jollibee đã khởi động");
        }

        /// <summary>
        /// Ghi log tắt hệ thống
        /// </summary>
        public static void LogTatHeThong()
        {
            if (!_isEnabled) return;
            logBUS.GhiLog("TẮT HỆ THỐNG", "HỆ THỐNG", null, "Hệ thống Quản lý Jollibee đã tắt");
        }

        #endregion
    }
}