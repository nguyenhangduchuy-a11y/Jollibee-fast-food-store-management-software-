﻿// Utils/SessionManager.cs
using System;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_.Utils
{
    public static class SessionManager
    {
        public static NguoiDungDTO NguoiDungHienTai { get; private set; }

        public static bool IsLoggedIn
        {
            get { return NguoiDungHienTai != null; }
        }

        public static bool IsAdmin
        {
            get { return NguoiDungHienTai != null && NguoiDungHienTai.VaiTro == 1; }
        }

        public static bool IsNhanVien
        {
            get { return NguoiDungHienTai != null && NguoiDungHienTai.VaiTro == 2; }
        }

        public static bool IsKhachHang
        {
            get { return NguoiDungHienTai != null && NguoiDungHienTai.VaiTro == 3; }
        }

        public static bool CanManageProducts
        {
            get { return IsAdmin; }
        }

        public static bool CanManageUsers
        {
            get { return IsAdmin; }
        }

        public static bool CanViewReports
        {
            get { return IsAdmin; }
        }

        public static bool CanSell
        {
            get { return IsAdmin || IsNhanVien; }
        }

        public static bool CanOrder
        {
            get { return IsKhachHang; }
        }

        public static void DangNhap(NguoiDungDTO nguoiDung)
        {
            if (nguoiDung == null)
                throw new ArgumentNullException("nguoiDung");

            NguoiDungHienTai = nguoiDung;
        }

        public static void DangXuat()
        {
            NguoiDungHienTai = null;
        }

        public static int GetCurrentUserId()
        {
            if (NguoiDungHienTai == null)
                throw new InvalidOperationException("Chưa đăng nhập.");

            return NguoiDungHienTai.IDNguoiDung;
        }

        public static string GetCurrentUserName()
        {
            if (NguoiDungHienTai == null)
                return "Chưa đăng nhập";

            return NguoiDungHienTai.HoTen;
        }
    }
}
