﻿using System;
using System.Windows.Forms;
using Đồ_Án__1_.BUS;
using Đồ_Án__1_.DTO;

namespace Đồ_Án__1_
{
    public partial class dangky : Form
    {
        private readonly NguoiDungBUS nguoiDungBUS = new NguoiDungBUS();
        private dangnhap loginForm;

        public dangky()
        {
            InitializeComponent();
            SetupPasswordChars();
        }

        public dangky(dangnhap loginForm) : this()
        {
            this.loginForm = loginForm;
        }

        private void SetupPasswordChars()
        {
            if (nhapmk != null)
            {
                nhapmk.PasswordChar = '*';
            }
            if (xacnhanmk != null)
            {
                xacnhanmk.PasswordChar = '*';
            }
        }

        private void vaodk_Click(object sender, EventArgs e)
        {
            try
            {
                string tenDangNhap = nhaptaikhoan.Text.Trim();
                string matKhau = nhapmk.Text;
                string xacNhanMatKhau = xacnhanmk.Text;

                // LƯU Ý: Vì form không có ô nhập họ tên, tôi sẽ tạo họ tên mặc định từ tên đăng nhập
                // Bạn nên thêm một TextBox để nhập họ tên vào form
                string hoTen = tenDangNhap; // Hoặc bạn có thể để giá trị mặc định

                // Kiểm tra các trường nhập
                if (string.IsNullOrWhiteSpace(tenDangNhap))
                {
                    MessageBox.Show("Vui lòng nhập tên đăng nhập!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    nhaptaikhoan.Focus();
                    return;
                }

                if (tenDangNhap.Length < 3)
                {
                    MessageBox.Show("Tên đăng nhập phải có ít nhất 3 ký tự!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    nhaptaikhoan.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(matKhau))
                {
                    MessageBox.Show("Vui lòng nhập mật khẩu!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    nhapmk.Focus();
                    return;
                }

                if (matKhau.Length < 6)
                {
                    MessageBox.Show("Mật khẩu phải có ít nhất 6 ký tự!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    nhapmk.Focus();
                    return;
                }

                if (string.IsNullOrWhiteSpace(xacNhanMatKhau))
                {
                    MessageBox.Show("Vui lòng xác nhận mật khẩu!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    xacnhanmk.Focus();
                    return;
                }

                if (matKhau != xacNhanMatKhau)
                {
                    MessageBox.Show("Mật khẩu xác nhận không khớp!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    nhapmk.Clear();
                    xacnhanmk.Clear();
                    nhapmk.Focus();
                    return;
                }

                // Gọi BUS để đăng ký (chỉ đăng ký tài khoản khách hàng - VaiTro = 3)
                int ketQua = nguoiDungBUS.DangKyKhachHang(tenDangNhap, matKhau, hoTen);

                if (ketQua > 0)
                {
                    MessageBox.Show("Đăng ký tài khoản thành công!\nVui lòng đăng nhập để tiếp tục.",
                        "Đăng ký thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Quay về form đăng nhập (không tạo mới)
                    if (loginForm != null)
                    {
                        loginForm.Show();
                    }
                    else
                    {
                        dangnhap login = new dangnhap();
                        login.Show();
                    }
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Đăng ký thất bại! Vui lòng thử lại sau.",
                        "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(ex.Message, "Đăng ký thất bại",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi hệ thống",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void thoat_Click(object sender, EventArgs e)
        {
            // Quay về form đăng nhập
            if (loginForm != null)
            {
                loginForm.Show();
            }
            else
            {
                dangnhap login = new dangnhap();
                login.Show();
            }
            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            // Hiển thị/ẩn mật khẩu
            if (nhapmk != null)
            {
                nhapmk.PasswordChar = checkBox1.Checked ? '\0' : '*';
            }
            if (xacnhanmk != null)
            {
                xacnhanmk.PasswordChar = checkBox1.Checked ? '\0' : '*';
            }
        }

        // Phím Enter để di chuyển giữa các ô
        private void nhaptaikhoan_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                nhapmk.Focus();
            }
        }

        private void nhapmk_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                xacnhanmk.Focus();
            }
        }

        private void xacnhanmk_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                vaodk_Click(sender, e);
            }
        }

        // Các phương thức trống giữ nguyên
        private void panel1_Paint(object sender, PaintEventArgs e) { }
        private void pictureBox1_Click(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void nhaptaikhoan_TextChanged(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void nhapmk_TextChanged(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void xacnhanmk_TextChanged(object sender, EventArgs e) { }
    }
}