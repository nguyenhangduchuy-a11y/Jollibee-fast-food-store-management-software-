﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Đồ_Án__1_.BUS;
using Đồ_Án__1_.DTO;
using Đồ_Án__1_.Utils;

namespace Đồ_Án__1_
{
    public partial class quanlyxuatfile : Form
    {
        // Đường dẫn đến thư mục chứa các file Excel
        private string folderPath = Application.StartupPath + @"\ExcelFiles\";
        private readonly ThongKeBUS thongKeBUS = new ThongKeBUS();

        // Singleton pattern - chỉ cho phép 1 instance duy nhất
        private static quanlyxuatfile instance = null;

        // Constructor private
        private quanlyxuatfile()
        {
            InitializeComponent();
            this.Load += Quanlyxuatfile_Load;
            this.FormClosing += Quanlyxuatfile_FormClosing;
        }

        // Lấy instance duy nhất
        public static quanlyxuatfile GetInstance()
        {
            if (instance == null || instance.IsDisposed)
            {
                instance = new quanlyxuatfile();
            }
            return instance;
        }

        // Hiển thị form (chỉ hiện, không tạo mới)
        public static void ShowForm()
        {
            GetInstance().Show();
            GetInstance().BringToFront();
        }

        private void Quanlyxuatfile_Load(object sender, EventArgs e)
        {
            // Tạo thư mục nếu chưa tồn tại
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }

            // Khởi tạo DateTimePicker
            dtpkFromDayTopSanPham.Value = DateTime.Today.AddDays(-30);
            dtpkToDayTopsanPham.Value = DateTime.Today;

            // Vẽ biểu đồ ngang TOP 5 sản phẩm bán chạy
            VeBieuDoNgangTop5();
        }

        private void Quanlyxuatfile_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Chỉ ẩn form, không đóng hoàn toàn
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                this.Hide();
            }
        }

        #region Vẽ biểu đồ ngang TOP 5 sản phẩm bán chạy

        private void VeBieuDoNgangTop5()
        {
            try
            {
                DateTime tuNgay = dtpkFromDayTopSanPham.Value.Date;
                DateTime denNgay = dtpkToDayTopsanPham.Value.Date;

                var topList = thongKeBUS.TopSanPhamBanChay(5);

                // Cấu hình ListBox để vẽ tùy chỉnh
                listBoxTopSanPham.DrawMode = DrawMode.OwnerDrawVariable;
                listBoxTopSanPham.MeasureItem += ListBoxTopSanPham_MeasureItem;
                listBoxTopSanPham.DrawItem += ListBoxTopSanPham_DrawItem;
                listBoxTopSanPham.Items.Clear();

                if (topList.Count == 0)
                {
                    listBoxTopSanPham.DrawMode = DrawMode.Normal;
                    listBoxTopSanPham.Items.Add("Chưa có dữ liệu bán hàng");
                    return;
                }

                int maxSoLuong = topList.Max(x => x.SoLuongBan);
                maxSoLuong = maxSoLuong == 0 ? 1 : maxSoLuong;

                // Thêm tiêu đề
                listBoxTopSanPham.Items.Add(new TopProductDisplayItem
                {
                    IsHeader = true,
                    TuNgay = tuNgay,
                    DenNgay = denNgay
                });

                // Thêm dữ liệu top 5
                int stt = 1;
                foreach (var item in topList)
                {
                    int phanTram = (int)((double)item.SoLuongBan / maxSoLuong * 100);

                    listBoxTopSanPham.Items.Add(new TopProductDisplayItem
                    {
                        STT = stt++,
                        MaSanPham = item.MaSanPham,
                        TenSanPham = item.TenSanPham,
                        SoLuongBan = item.SoLuongBan,
                        DoanhThu = item.DoanhThu,
                        PhanTram = phanTram,
                        IsHeader = false
                    });
                }
            }
            catch (Exception ex)
            {
                listBoxTopSanPham.DrawMode = DrawMode.Normal;
                listBoxTopSanPham.Items.Clear();
                listBoxTopSanPham.Items.Add($"Lỗi: {ex.Message}");
            }
        }

        private void ListBoxTopSanPham_MeasureItem(object sender, MeasureItemEventArgs e)
        {
            if (e.Index >= 0 && e.Index < listBoxTopSanPham.Items.Count)
            {
                var item = listBoxTopSanPham.Items[e.Index];
                if (item is TopProductDisplayItem topItem)
                {
                    if (topItem.IsHeader)
                        e.ItemHeight = 65;
                    else
                        e.ItemHeight = 40;
                }
                else
                {
                    e.ItemHeight = 25;
                }
            }
            else
            {
                e.ItemHeight = 25;
            }
        }

        private void ListBoxTopSanPham_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0 || e.Index >= listBoxTopSanPham.Items.Count) return;

            e.DrawBackground();

            var item = listBoxTopSanPham.Items[e.Index];

            if (item is TopProductDisplayItem topItem)
            {
                if (topItem.IsHeader)
                {
                    // Vẽ tiêu đề
                    using (Font titleFont = new Font("Segoe UI", 12, FontStyle.Bold))
                    using (Font subFont = new Font("Segoe UI", 9, FontStyle.Italic))
                    using (SolidBrush brush = new SolidBrush(Color.FromArgb(52, 73, 94)))
                    {
                        e.Graphics.DrawString("📊 TOP 5 SẢN PHẨM BÁN CHẠY", titleFont, brush, 10, e.Bounds.Y + 5);
                        e.Graphics.DrawString($"📅 {topItem.TuNgay:dd/MM/yyyy} - {topItem.DenNgay:dd/MM/yyyy}", subFont, brush, 10, e.Bounds.Y + 32);
                    }

                    // Vẽ đường kẻ
                    using (Pen pen = new Pen(Color.FromArgb(200, 200, 200)))
                    {
                        e.Graphics.DrawLine(pen, 10, e.Bounds.Y + 60, e.Bounds.Width - 10, e.Bounds.Y + 60);
                    }
                }
                else
                {
                    // Vẽ biểu đồ ngang
                    int barWidth = (int)((e.Bounds.Width - 160) * topItem.PhanTram / 100.0);
                    barWidth = Math.Max(barWidth, 5);

                    Rectangle barRect = new Rectangle(130, e.Bounds.Y + 8, barWidth, 22);

                    // Chọn màu theo thứ tự
                    Color barColor;
                    switch (topItem.STT)
                    {
                        case 1: barColor = Color.FromArgb(255, 193, 7); break;      // Vàng
                        case 2: barColor = Color.FromArgb(156, 39, 176); break;     // Tím
                        case 3: barColor = Color.FromArgb(33, 150, 243); break;     // Xanh dương
                        case 4: barColor = Color.FromArgb(76, 175, 80); break;      // Xanh lá
                        case 5: barColor = Color.FromArgb(244, 67, 54); break;      // Đỏ
                        default: barColor = Color.FromArgb(52, 152, 219); break;
                    }

                    using (SolidBrush barBrush = new SolidBrush(barColor))
                    using (SolidBrush textBrush = new SolidBrush(Color.FromArgb(44, 62, 80)))
                    using (Font textFont = new Font("Segoe UI", 9, FontStyle.Regular))
                    using (Font nameFont = new Font("Segoe UI", 9, FontStyle.Bold))
                    {
                        // STT
                        e.Graphics.DrawString($"{topItem.STT}.", textFont, textBrush, 5, e.Bounds.Y + 12);

                        // Tên sản phẩm
                        string tenSP = topItem.TenSanPham.Length > 20 ? topItem.TenSanPham.Substring(0, 17) + "..." : topItem.TenSanPham;
                        e.Graphics.DrawString($"{topItem.MaSanPham} - {tenSP}", nameFont, textBrush, 30, e.Bounds.Y + 12);

                        // Thanh biểu đồ
                        e.Graphics.FillRectangle(barBrush, barRect);

                        // Số lượng (hiển thị trên thanh)
                        using (SolidBrush whiteBrush = new SolidBrush(Color.White))
                        {
                            e.Graphics.DrawString($"{topItem.SoLuongBan}", textFont, whiteBrush, barRect.X + 5, e.Graphics.MeasureString($"{topItem.SoLuongBan}", textFont).Height > barRect.Height ? barRect.Y + 2 : barRect.Y + 10);
                        }

                        // Doanh thu
                        e.Graphics.DrawString($"{topItem.DoanhThu:N0}đ", textFont, textBrush, e.Bounds.Width - 90, e.Bounds.Y + 12);

                        // Phần trăm
                        e.Graphics.DrawString($"{topItem.PhanTram}%", textFont, textBrush, barRect.Right + 5, e.Bounds.Y + 12);
                    }
                }
            }

            e.DrawFocusRectangle();
        }

        #endregion

        #region Mở các file Excel có sẵn

        private void MoFileSanPham()
        {
            string filePath = Path.Combine(folderPath, "thông tin sản phẩm.xlsx");
            MoFileExcel(filePath);
        }

        private void MoFileHoaDon()
        {
            string filePath = Path.Combine(folderPath, "tổng hợp hóa đơn.xlsx");
            MoFileExcel(filePath);
        }

        private void MoFileDoanhThu()
        {
            string filePath = Path.Combine(folderPath, "Doanh Thu.xlsx");
            MoFileExcel(filePath);
        }

        private void MoFileHoaDonTheoNgay()
        {
            string filePath = Path.Combine(folderPath, "Hóa Đơn Trong Ngày.xlsx");
            MoFileExcel(filePath);
        }

        private void MoFileExcel(string filePath)
        {
            try
            {
                string fullPath = Path.GetFullPath(filePath);
                if (File.Exists(fullPath))
                {
                    System.Diagnostics.Process.Start(fullPath);
                    LogHelper.LogNhanh($"Đã mở file Excel: {Path.GetFileName(fullPath)}");
                }
                else
                {
                    MessageBox.Show($"Không tìm thấy file:\n{fullPath}\n\nVui lòng copy file vào:\n{folderPath}",
                        "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi mở file:\n{ex.Message}", "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        #endregion

        #region Sự kiện các nút - GIỮ LẠI CÁI _1 LÀM CHUẨN, XÓA CÁI KHÔNG CÓ _1

        private void btnSanPham_Click_1(object sender, EventArgs e)
        {
            MoFileSanPham();
        }

        private void btnHoaDon_Click_1(object sender, EventArgs e)
        {
            MoFileHoaDon();
        }

        private void btnDoanhThu_Click_1(object sender, EventArgs e)
        {
            MoFileDoanhThu();
        }

        private void btnHoaDonTheoNgay_Click_1(object sender, EventArgs e)
        {
            MoFileHoaDonTheoNgay();
        }

        private void btnLamMoiTopSanPham_Click(object sender, EventArgs e)
        {
            VeBieuDoNgangTop5();
        }

        private void dtpkFromDayTopSanPham_ValueChanged_1(object sender, EventArgs e)
        {
            if (dtpkFromDayTopSanPham.Value > dtpkToDayTopsanPham.Value)
            {
                dtpkToDayTopsanPham.Value = dtpkFromDayTopSanPham.Value;
            }
            VeBieuDoNgangTop5();
        }

        private void dtpkToDayTopsanPham_ValueChanged_1(object sender, EventArgs e)
        {
            if (dtpkToDayTopsanPham.Value < dtpkFromDayTopSanPham.Value)
            {
                dtpkFromDayTopSanPham.Value = dtpkToDayTopsanPham.Value;
            }
            VeBieuDoNgangTop5();
        }

        private void listBoxTopSanPham_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            // Có thể thêm code xem chi tiết khi chọn sản phẩm
        }

        #endregion

        #region Các sự kiện không dùng (giữ lại để tránh lỗi)

        private void label14_Click(object sender, EventArgs e) { }
        private void label15_Click(object sender, EventArgs e) { }
        private void label16_Click(object sender, EventArgs e) { }
        private void label17_Click(object sender, EventArgs e) { }
        private void label18_Click(object sender, EventArgs e) { }
        private void panel30_Paint(object sender, PaintEventArgs e) { }
        private void panel20_Paint(object sender, PaintEventArgs e) { }
        private void label14_Click_1(object sender, EventArgs e) { }
        private void label17_Click_1(object sender, EventArgs e) { }
        private void label18_Click_1(object sender, EventArgs e) { }

        // XÓA các sự kiện cũ không có _1
        // private void btnSanPham_Click(object sender, EventArgs e) { }
        // private void btnHoaDon_Click(object sender, EventArgs e) { }
        // private void btnDoanhThu_Click(object sender, EventArgs e) { }
        // private void btnHoaDonTheoNgay_Click(object sender, EventArgs e) { }
        // private void dtpkFromDayTopSanPham_ValueChanged(object sender, EventArgs e) { }
        // private void dtpkToDayTopsanPham_ValueChanged(object sender, EventArgs e) { }
        // private void listBoxTopSanPham_SelectedIndexChanged(object sender, EventArgs e) { }

        #endregion
    }

    // Class hỗ trợ hiển thị biểu đồ
    public class TopProductDisplayItem
    {
        public int STT { get; set; }
        public string MaSanPham { get; set; }
        public string TenSanPham { get; set; }
        public int SoLuongBan { get; set; }
        public decimal DoanhThu { get; set; }
        public int PhanTram { get; set; }
        public bool IsHeader { get; set; }
        public DateTime TuNgay { get; set; }
        public DateTime DenNgay { get; set; }

        public TopProductDisplayItem()
        {
            MaSanPham = string.Empty;
            TenSanPham = string.Empty;
        }
    }
}