﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Đồ_Án__1_.BUS;
using Đồ_Án__1_.DAL;
using Đồ_Án__1_.DTO;
using Đồ_Án__1_.Utils;
using Excel = Microsoft.Office.Interop.Excel;

namespace Đồ_Án__1_
{
    public partial class thongtinnhanvien : Form
    {
        private NguoiDungDTO nhanVienHienTai;
        private ThongKeDAL thongKeDAL = new ThongKeDAL();
        private HoaDonDAL hoaDonDAL = new HoaDonDAL();
        private NguoiDungBUS nguoiDungBUS = new NguoiDungBUS();

        public thongtinnhanvien()
        {
            InitializeComponent();
            this.Load += ThongTinNhanVien_Load;
        }

        private void ThongTinNhanVien_Load(object sender, EventArgs e)
        {
            if (SessionManager.IsLoggedIn)
            {
                int idNhanVien = SessionManager.GetCurrentUserId();
                nhanVienHienTai = nguoiDungBUS.LayTheoID(idNhanVien);

                if (nhanVienHienTai != null)
                {
                    txbTenDangNhap.Text = nhanVienHienTai.TenDangNhap;
                    txbHoTen.Text = nhanVienHienTai.HoTen;
                    txbNgayTao.Text = nhanVienHienTai.NgayTao.ToString("dd/MM/yyyy");
                    txbTrangThai.Text = nhanVienHienTai.KichHoat ? "Hoạt động" : "Đã khóa";
                }
            }

            dtpkFromday.Value = DateTime.Today.AddDays(-30);
            dtpkToday.Value = DateTime.Today;

            // Cấu hình ListView
            listViewRhongTinNhanVien.View = View.Details;
            listViewRhongTinNhanVien.FullRowSelect = true;
            listViewRhongTinNhanVien.GridLines = true;
            listViewRhongTinNhanVien.Columns.Clear();
            listViewRhongTinNhanVien.Columns.Add("Mã HD", 100);
            listViewRhongTinNhanVien.Columns.Add("Ngày lập", 120);
            listViewRhongTinNhanVien.Columns.Add("Loại đơn", 100);
            listViewRhongTinNhanVien.Columns.Add("Tổng tiền", 120);
            listViewRhongTinNhanVien.Columns.Add("Trạng thái", 100);

            // Load dữ liệu
            LoadThongKe();
            LoadLichSuDonHang();
        }

        private void LoadThongKe()
        {
            try
            {
                if (nhanVienHienTai == null) return;

                DateTime tuNgay = dtpkFromday.Value.Date;
                DateTime denNgay = dtpkToday.Value.Date;

                var thongKe = thongKeDAL.ThongKeNhanVien(nhanVienHienTai.IDNguoiDung, tuNgay, denNgay);

                txbSoDon.Text = thongKe.SoDonHoanThanh.ToString("N0");
                txbDoanhThu.Text = string.Format("{0:N0} đ", thongKe.TongDoanhThu);
                txbTrungBinhDon.Text = string.Format("{0:N0} đ", thongKe.TrungBinhDon);
            }
            catch (Exception ex)
            {
                txbSoDon.Text = "0";
                txbDoanhThu.Text = "0 đ";
                txbTrungBinhDon.Text = "0 đ";
            }
        }

        private void LoadLichSuDonHang()
        {
            try
            {
                if (nhanVienHienTai == null) return;

                DateTime tuNgay = DateTime.Today.AddDays(-30);
                DateTime denNgay = DateTime.Today;

                var danhSachHoaDon = hoaDonDAL.LayTheoNgay(tuNgay, denNgay);

                listViewRhongTinNhanVien.Items.Clear();

                foreach (var hd in danhSachHoaDon)
                {
                    if (hd.IDNhanVien == nhanVienHienTai.IDNguoiDung && hd.TrangThai == 1)
                    {
                        ListViewItem lvi = new ListViewItem(hd.MaHoaDon);
                        lvi.SubItems.Add(hd.NgayLap.ToString("dd/MM/yyyy HH:mm"));
                        lvi.SubItems.Add(hd.LoaiDon == 1 ? "Tại bàn" : (hd.LoaiDon == 2 ? "Mang về" : "Tự order"));
                        lvi.SubItems.Add(string.Format("{0:N0} đ", hd.TongTien));
                        lvi.SubItems.Add("Đã thanh toán");
                        listViewRhongTinNhanVien.Items.Add(lvi);
                    }
                }
            }
            catch (Exception ex)
            {
                listViewRhongTinNhanVien.Items.Clear();
                ListViewItem lvi = new ListViewItem("");
                lvi.SubItems.Add("Không có dữ liệu");
                listViewRhongTinNhanVien.Items.Add(lvi);
            }
        }

        private void btnHoTro_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "📞 LIÊN HỆ HỖ TRỢ\n\n" +
                "Hotline: 0338914324\n" +
                "Facebook: https://www.facebook.com/huy.minh.654180\n\n" +
                "Bấm OK để mở Facebook liên hệ.\n" +
                "Bấm Thoát để đóng cửa sổ này.",
                "Hỗ trợ",
                MessageBoxButtons.OKCancel,
                MessageBoxIcon.Question);

            if (result == DialogResult.OK)
            {
                try
                {
                    System.Diagnostics.Process.Start("https://www.facebook.com/huy.minh.654180");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Không thể mở Facebook: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dtpkFromday_ValueChanged(object sender, EventArgs e)
        {
            if (dtpkFromday.Value > dtpkToday.Value)
            {
                dtpkToday.Value = dtpkFromday.Value;
            }
            LoadThongKe();
        }

        private void dtpkToday_ValueChanged(object sender, EventArgs e)
        {
            if (dtpkToday.Value < dtpkFromday.Value)
            {
                dtpkFromday.Value = dtpkToday.Value;
            }
            LoadThongKe();
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            LoadThongKe();
            LoadLichSuDonHang();
        }

        private void btnXuatExcel_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "Excel Files|*.xlsx";
                saveFileDialog.Title = "Xuất thông tin nhân viên";
                saveFileDialog.FileName = $"ThongTinNhanVien_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    Excel.Application excelApp = new Excel.Application();
                    Excel.Workbook workbook = excelApp.Workbooks.Add();
                    Excel.Worksheet worksheet = workbook.Worksheets[1];
                    worksheet.Name = "ThongTinNhanVien";

                    worksheet.Cells[1, 1] = "JOLLIBEE VIETNAM";
                    Excel.Range titleRange = worksheet.Range[worksheet.Cells[1, 1], worksheet.Cells[1, 5]];
                    titleRange.Merge();
                    titleRange.Font.Bold = true;
                    titleRange.Font.Size = 16;

                    worksheet.Cells[2, 1] = "THÔNG TIN NHÂN VIÊN";
                    titleRange = worksheet.Range[worksheet.Cells[2, 1], worksheet.Cells[2, 5]];
                    titleRange.Merge();
                    titleRange.Font.Bold = true;
                    titleRange.Font.Size = 14;

                    int row = 4;
                    worksheet.Cells[row, 1] = "Tên đăng nhập:";
                    worksheet.Cells[row, 2] = txbTenDangNhap.Text;
                    row++;
                    worksheet.Cells[row, 1] = "Họ và tên:";
                    worksheet.Cells[row, 2] = txbHoTen.Text;
                    row++;
                    worksheet.Cells[row, 1] = "Ngày tạo:";
                    worksheet.Cells[row, 2] = txbNgayTao.Text;
                    row++;
                    worksheet.Cells[row, 1] = "Trạng thái:";
                    worksheet.Cells[row, 2] = txbTrangThai.Text;
                    row += 2;

                    worksheet.Cells[row, 1] = "THỐNG KÊ";
                    worksheet.Cells[row, 1].Font.Bold = true;
                    row++;
                    worksheet.Cells[row, 1] = "Số đơn:";
                    worksheet.Cells[row, 2] = txbSoDon.Text;
                    row++;
                    worksheet.Cells[row, 1] = "Doanh thu:";
                    worksheet.Cells[row, 2] = txbDoanhThu.Text;
                    row++;
                    worksheet.Cells[row, 1] = "Trung bình/đơn:";
                    worksheet.Cells[row, 2] = txbTrungBinhDon.Text;
                    row += 2;

                    worksheet.Cells[row, 1] = "LỊCH SỬ ĐƠN HÀNG";
                    worksheet.Cells[row, 1].Font.Bold = true;
                    row++;
                    worksheet.Cells[row, 1] = "Mã HD";
                    worksheet.Cells[row, 2] = "Ngày lập";
                    worksheet.Cells[row, 3] = "Loại đơn";
                    worksheet.Cells[row, 4] = "Tổng tiền";
                    worksheet.Cells[row, 5] = "Trạng thái";

                    row++;
                    foreach (ListViewItem item in listViewRhongTinNhanVien.Items)
                    {
                        if (item.SubItems.Count >= 5 && item.SubItems[1].Text != "Không có dữ liệu")
                        {
                            worksheet.Cells[row, 1] = item.Text;
                            worksheet.Cells[row, 2] = item.SubItems[1].Text;
                            worksheet.Cells[row, 3] = item.SubItems[2].Text;
                            worksheet.Cells[row, 4] = item.SubItems[3].Text;
                            worksheet.Cells[row, 5] = item.SubItems[4].Text;
                            row++;
                        }
                    }

                    worksheet.Columns.AutoFit();
                    workbook.SaveAs(saveFileDialog.FileName);
                    workbook.Close();
                    excelApp.Quit();

                    MessageBox.Show($"Xuất file thành công!\nĐường dẫn: {saveFileDialog.FileName}", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi xuất Excel: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Các sự kiện khác giữ nguyên
        private void panel1_Paint(object sender, PaintEventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void panel2_Paint(object sender, PaintEventArgs e) { }
        private void panel3_Paint(object sender, PaintEventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void label5_Click(object sender, EventArgs e) { }
        private void txbTenDangNhap_TextChanged(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void txbHoTen_TextChanged(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void txbNgayTao_TextChanged(object sender, EventArgs e) { }
        private void label8_Click(object sender, EventArgs e) { }
        private void txbTrangThai_TextChanged(object sender, EventArgs e) { }
        private void panel5_Paint(object sender, PaintEventArgs e) { }
        private void label9_Click(object sender, EventArgs e) { }
        private void txbSoDon_TextChanged(object sender, EventArgs e) { }
        private void label10_Click(object sender, EventArgs e) { }
        private void txbDoanhThu_TextChanged(object sender, EventArgs e) { }
        private void label11_Click(object sender, EventArgs e) { }
        private void txbTrungBinhDon_TextChanged(object sender, EventArgs e) { }
        private void panel4_Paint(object sender, PaintEventArgs e) { }
        private void listViewRhongTinNhanVien_SelectedIndexChanged(object sender, EventArgs e) { }
        private void panel6_Paint(object sender, PaintEventArgs e) { }
    }
}